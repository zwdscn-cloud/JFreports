// Cesium配置文件
// 设置Cesium Ion访问令牌
window.CESIUM_ION_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJhMGY0MDZmMy1iMjYxLTQxZGQtODNlMC0xMTU0MWYzODA2ZDQiLCJpZCI6ODAwNzIsImlhdCI6MTY0NDg1MjI3M30.sLYxZ-k3L5U2Z5B1SkYErwkSNFJg5oDGrEYlxyrXrpU";

// 设置Bing Maps密钥（可选）
window.BING_MAPS_KEY = "your_bing_maps_key_here";
