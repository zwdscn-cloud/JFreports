'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface LoadingScreenProps {
  isLoading: boolean;
  progress?: number;
  onComplete?: () => void;
  children: React.ReactNode;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({
  isLoading,
  progress = 0,
  onComplete,
  children
}) => {
  const [isVisible, setIsVisible] = useState(isLoading);

  useEffect(() => {
    if (!isLoading && progress >= 100) {
      // 延迟一点时间让动画完成
      const timer = setTimeout(() => {
        setIsVisible(false);
        onComplete?.();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isLoading, progress, onComplete]);

  return (
    <div className="relative w-full h-full">
      {/* 主要内容 */}
      <motion.div
        className="w-full h-full"
        animate={{
          filter: isLoading ? 'blur(8px)' : 'blur(0px)',
          opacity: isLoading ? 0.9 : 1,
        }}
        transition={{
          duration: 0.8,
          ease: "easeInOut"
        }}
      >
        {children}
      </motion.div>

      {/* 加载遮罩层 */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            className="absolute inset-0 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center z-50"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* 加载动画 */}
            <div className="flex flex-col items-center space-y-8">
              {/* 旋转的加载图标 */}
              <motion.div
                className="w-16 h-16 border-4 border-gray-200 border-t-blue-600 rounded-full"
                animate={{ rotate: 360 }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
              
              {/* 进度条 */}
              <div className="w-80 max-w-sm">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>加载中...</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                  />
                </div>
              </div>

              {/* 加载文本 */}
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <h2 className="text-xl font-semibold text-gray-800 mb-2">
                  正在加载应用
                </h2>
                <p className="text-gray-600">
                  请稍候，我们正在为您准备最佳体验
                </p>
              </motion.div>

              {/* 加载步骤指示器 */}
              <motion.div
                className="flex space-x-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                {[0, 1, 2].map((step) => (
                  <motion.div
                    key={step}
                    className={`w-2 h-2 rounded-full ${
                      progress > (step + 1) * 33 ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                    animate={{
                      scale: progress > (step + 1) * 33 ? [1, 1.2, 1] : 1,
                    }}
                    transition={{
                      duration: 0.3,
                      repeat: progress > (step + 1) * 33 ? Infinity : 0,
                      repeatDelay: 0.5
                    }}
                  />
                ))}
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// 使用示例的 Hook
export const useLoadingSimulation = (duration: number = 3000) => {
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    let timeout: NodeJS.Timeout | null = null;
    
    const startTime = Date.now();
    interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min((elapsed / duration) * 100, 100);
      
      setProgress(newProgress);
      
      if (newProgress >= 100) {
        if (interval) {
          clearInterval(interval);
          interval = null;
        }
        timeout = setTimeout(() => {
          setIsLoading(false);
        }, 300);
      }
    }, 50);

    return () => {
      if (interval) {
        clearInterval(interval);
      }
      if (timeout) {
        clearTimeout(timeout);
      }
    };
  }, [duration]);

  return { isLoading, progress };
};
