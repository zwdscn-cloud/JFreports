"use client"

import React, { useRef, useState, useCallback, useEffect } from 'react'
import * as THREE from 'three'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Slider } from '@/components/ui/slider'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Video, Play, Square, Download, Settings } from 'lucide-react'
import { getFFmpegRecorder, RecordingOptions } from '@/lib/ffmpeg-recorder'

interface ThreeDVideoRecorderProps {
  canvasRef: React.RefObject<THREE.WebGLRenderer | null>
  isOpen: boolean
  onClose: () => void
}

export function ThreeDVideoRecorder({ canvasRef, isOpen, onClose }: ThreeDVideoRecorderProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [recordingOptions, setRecordingOptions] = useState<RecordingOptions>({
    width: 1920,
    height: 1080,
    frameRate: 30,
    duration: 10,
    quality: 'medium'
  })
  
  const recorderRef = useRef(getFFmpegRecorder())
  const animationFrameRef = useRef<number | null>(null)
  const recordingStartTimeRef = useRef<number>(0)

  // 初始化FFmpeg
  useEffect(() => {
    if (isOpen) {
      initializeFFmpeg()
    }
  }, [isOpen])

  const initializeFFmpeg = async () => {
    try {
      await recorderRef.current.initialize()
      console.log('FFmpeg initialized for 3D recording')
    } catch (error) {
      console.error('Failed to initialize FFmpeg:', error)
    }
  }

  const startRecording = useCallback(async () => {
    if (!canvasRef.current) {
      alert('3D渲染器未找到')
      return
    }

    const canvas = canvasRef.current.domElement
    if (!canvas) {
      alert('Canvas元素未找到')
      return
    }

    try {
      setIsRecording(true)
      setProgress(0)
      recordingStartTimeRef.current = performance.now()
      
      // 开始录制
      recorderRef.current.startRecording()
      
      // 开始帧捕获循环
      const captureFrame = () => {
        if (!isRecording || !canvasRef.current) return
        
        const elapsed = performance.now() - recordingStartTimeRef.current
        const progressPercent = Math.min((elapsed / (recordingOptions.duration * 1000)) * 100, 100)
        setProgress(progressPercent)
        
        // 添加帧到录制器
        recorderRef.current.addFrame(canvas)
        
        // 检查是否达到录制时长
        if (elapsed >= recordingOptions.duration * 1000) {
          stopRecording()
          return
        }
        
        // 继续下一帧
        animationFrameRef.current = requestAnimationFrame(captureFrame)
      }
      
      captureFrame()
    } catch (error) {
      console.error('Failed to start recording:', error)
      setIsRecording(false)
      alert('录制启动失败: ' + error.message)
    }
  }, [canvasRef, isRecording, recordingOptions.duration])

  const stopRecording = useCallback(async () => {
    if (!isRecording) return
    
    setIsRecording(false)
    setIsProcessing(true)
    setProgress(0)
    
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }
    
    try {
      console.log('Processing recording...')
      setProgress(10)
      
      // 停止录制并处理视频
      const videoBlob = await recorderRef.current.stopRecording(recordingOptions)
      
      setProgress(90)
      
      // 创建下载链接
      const url = URL.createObjectURL(videoBlob)
      const a = document.createElement('a')
      a.href = url
      a.download = `3d-recording-${new Date().toISOString().replace(/[:.]/g, '-')}.mp4`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
      
      setProgress(100)
      console.log('Video exported successfully')
      
      // 延迟关闭对话框
      setTimeout(() => {
        setIsProcessing(false)
        setProgress(0)
        onClose()
      }, 1000)
      
    } catch (error) {
      console.error('Failed to process recording:', error)
      setIsProcessing(false)
      setProgress(0)
      alert('视频处理失败: ' + error.message)
    }
  }, [isRecording, recordingOptions, onClose])

  const handleQualityChange = (quality: string) => {
    setRecordingOptions(prev => ({
      ...prev,
      quality: quality as 'low' | 'medium' | 'high'
    }))
  }

  const handleResolutionChange = (resolution: string) => {
    const [width, height] = resolution.split('x').map(Number)
    setRecordingOptions(prev => ({
      ...prev,
      width,
      height
    }))
  }

  const handleFrameRateChange = (value: number[]) => {
    setRecordingOptions(prev => ({
      ...prev,
      frameRate: value[0]
    }))
  }

  const handleDurationChange = (value: number[]) => {
    setRecordingOptions(prev => ({
      ...prev,
      duration: value[0]
    }))
  }

  // 清理资源
  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [])

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5" />
            3D场景录屏
          </DialogTitle>
          <DialogDescription>
            录制3D场景的动画并导出为MP4视频
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* 录制设置 */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <Label className="text-sm font-medium">录制设置</Label>
            </div>
            
            {/* 分辨率选择 */}
            <div className="space-y-2">
              <Label className="text-sm">分辨率</Label>
              <Select value={`${recordingOptions.width}x${recordingOptions.height}`} onValueChange={handleResolutionChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1920x1080">1920×1080 (Full HD)</SelectItem>
                  <SelectItem value="1280x720">1280×720 (HD)</SelectItem>
                  <SelectItem value="854x480">854×480 (SD)</SelectItem>
                  <SelectItem value="640x360">640×360 (Low)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 帧率设置 */}
            <div className="space-y-2">
              <Label className="text-sm">帧率: {recordingOptions.frameRate} FPS</Label>
              <Slider
                value={[recordingOptions.frameRate]}
                onValueChange={handleFrameRateChange}
                min={15}
                max={60}
                step={5}
                className="w-full"
              />
            </div>

            {/* 录制时长 */}
            <div className="space-y-2">
              <Label className="text-sm">录制时长: {recordingOptions.duration} 秒</Label>
              <Slider
                value={[recordingOptions.duration]}
                onValueChange={handleDurationChange}
                min={5}
                max={60}
                step={5}
                className="w-full"
              />
            </div>

            {/* 质量设置 */}
            <div className="space-y-2">
              <Label className="text-sm">视频质量</Label>
              <Select value={recordingOptions.quality} onValueChange={handleQualityChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">低质量 (快速编码)</SelectItem>
                  <SelectItem value="medium">中等质量 (平衡)</SelectItem>
                  <SelectItem value="high">高质量 (慢速编码)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 录制状态 */}
          {isRecording && (
            <div className="space-y-2">
              <Label className="text-sm">录制进度</Label>
              <Progress value={progress} className="w-full" />
              <p className="text-xs text-muted-foreground">
                已录制 {Math.round(progress)}% - {recorderRef.current.getFrameCount()} 帧
              </p>
            </div>
          )}

          {/* 处理状态 */}
          {isProcessing && (
            <div className="space-y-2">
              <Label className="text-sm">处理中...</Label>
              <Progress value={progress} className="w-full" />
              <p className="text-xs text-muted-foreground">
                正在编码视频，请稍候...
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isRecording || isProcessing}>
            取消
          </Button>
          
          {!isRecording && !isProcessing && (
            <Button onClick={startRecording} className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-2" />
              开始录制
            </Button>
          )}
          
          {isRecording && (
            <Button onClick={stopRecording} className="bg-red-600 hover:bg-red-700">
              <Square className="w-4 h-4 mr-2" />
              停止录制
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
