"use client"

import type React from "react"
import { useState, useCallback, useMemo } from "react"

import { Button } from "@/components/ui/button"
import { Save, FolderOpen, Undo, Redo, Play, Pause, Square, Video, Settings, User, Bell, Palette, Sun, Moon, Trash2, Presentation, Info, Maximize, Minimize, RotateCcw } from "lucide-react"
import { useSound } from "@/hooks/use-sound"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { ColorThemeSelector } from "@/components/color-theme-selector"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { SettingsPanel } from "@/components/settings-panel"

interface DashboardToolbarProps {
  activeTheme: string
  onThemeChange: (theme: string) => void
  onSave?: (fileName?: string) => void
  onLoad?: (file: File) => void
  onClear?: () => void
  isDarkMode?: boolean
  onDarkModeToggle?: () => void
  // 播放控制相关
  onPlay?: () => void
  onPause?: () => void
  onStop?: () => void
  onStartRecording?: () => void
  onStopRecording?: () => void
  isPlaying?: boolean
  isRecording?: boolean
  // 发布功能相关
  onPublish?: () => void
  // 全屏功能相关
  isFullscreen?: boolean
  onToggleFullscreen?: () => void
}

export function DashboardToolbar({
  activeTheme,
  onThemeChange,
  onSave,
  onLoad,
  onClear,
  isDarkMode = false,
  onDarkModeToggle,
  // 播放控制相关
  onPlay,
  onPause,
  onStop,
  onStartRecording,
  onStopRecording,
  isPlaying = false,
  isRecording = false,
  // 发布功能相关
  onPublish,
  // 全屏功能相关
  isFullscreen = false,
  onToggleFullscreen,
}: DashboardToolbarProps) {
  const [showClearDialog, setShowClearDialog] = useState(false)
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [saveFileName, setSaveFileName] = useState("")
  const [showAboutDialog, setShowAboutDialog] = useState(false)
  const [showSettingsDialog, setShowSettingsDialog] = useState(false)
  const { playSuccess, playError, playSpecial } = useSound()

  // 生成默认文件名 - 使用useCallback避免无限循环
  const getDefaultFileName = useCallback(() => {
    const now = new Date()
    const dateStr = now.toISOString().split("T")[0]
    return `dashboard-${dateStr}`
  }, [])

  // 处理文件加载 - 使用useCallback避免无限循环
  const handleFileLoad = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && onLoad) {
      onLoad(file)
    }
    event.target.value = ""
  }, [onLoad])

  // 处理保存按钮点击 - 使用useCallback避免无限循环
  const handleSaveClick = useCallback(() => {
    setSaveFileName(getDefaultFileName())
    setShowSaveDialog(true)
  }, [getDefaultFileName])

  // 处理清除按钮点击 - 使用useCallback避免无限循环
  const handleClearClick = useCallback(() => {
    setShowClearDialog(true)
  }, [])

  // 处理暗色模式切换 - 使用useCallback避免无限循环
  const handleDarkModeToggle = useCallback(() => {
    if (onDarkModeToggle) {
      onDarkModeToggle()
    }
  }, [onDarkModeToggle])

  // 处理页面刷新 - 使用useCallback避免无限循环
  const handleRefresh = useCallback(() => {
    playSuccess() // 播放成功音效
    window.location.reload() // 刷新页面
  }, [playSuccess])

  const themeText = useMemo(() => isDarkMode ? "黑夜" : "白天", [isDarkMode])

  // 处理取消清除对话框
  const handleCancelClear = useCallback(() => {
    setShowClearDialog(false)
  }, [])

  // 处理确认清除
  const handleConfirmClear = useCallback(() => {
    onClear?.()
    setShowClearDialog(false)
    playError() // 清除操作播放错误音效
  }, [onClear, playError])

  // 处理取消保存对话框
  const handleCancelSave = useCallback(() => {
    setShowSaveDialog(false)
    setSaveFileName("")
  }, [])

  // 处理确认保存
  const handleConfirmSave = useCallback(() => {
    const fileName = saveFileName.trim() || getDefaultFileName()
    onSave?.(fileName)
    setShowSaveDialog(false)
    setSaveFileName("")
    playSuccess() // 保存操作播放成功音效
  }, [saveFileName, getDefaultFileName, onSave, playSuccess])

  // 处理保存文件名输入
  const handleSaveFileNameChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSaveFileName(e.target.value)
  }, [])

  // 处理保存文件名键盘事件
  const handleSaveFileNameKeyDown = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const fileName = saveFileName.trim() || getDefaultFileName()
      onSave?.(fileName)
      setShowSaveDialog(false)
      setSaveFileName("")
    }
  }, [saveFileName, getDefaultFileName, onSave])

  return (
    <div className="h-12 bg-card border-b border-border flex items-center justify-between px-4 shadow-lg shadow-black/10 dark:shadow-black/50 dark:shadow-2xl">
      {/* Left Section */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1">
          <div className="w-6 h-6 bg-blue-500 rounded flex items-center justify-center text-white text-xs font-bold shadow-md shadow-blue-500/30">
            JF
          </div>
          <span className="text-sm font-medium">微孪数据</span>
        </div>

        <div className="h-4 w-px bg-border mx-2" />

        {/* 配色主题选择器 */}
        <Tooltip>
              <TooltipTrigger asChild>
                <div className="relative">
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileLoad}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    id="load-file"
                  />
                  <Button variant="ghost" size="sm" className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out" asChild>
                    <label htmlFor="load-file" className="cursor-pointer">
                      <FolderOpen className="w-4 h-4 mr-1" />
                      打开
                    </label>
                  </Button>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>打开保存的仪表板文件</p>
              </TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out" onClick={handleSaveClick}>
                  <Save className="w-4 h-4 mr-1" />
                  保存
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>保存当前仪表板</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleClearClick}
                  className="text-foreground hover:text-white hover:bg-red-600 dark:hover:bg-red-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  清除
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>清除画布上的所有内容</p>
              </TooltipContent>
            </Tooltip>

            <div className="h-4 w-px bg-border mx-2" />

            {/* 刷新按钮 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleRefresh}
                  className="text-foreground hover:text-white hover:bg-blue-600 dark:hover:bg-blue-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-blue-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <RotateCcw className="w-4 h-4 mr-1" />
                  刷新
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>刷新页面</p>
              </TooltipContent>
            </Tooltip>

            <div className="h-4 w-px bg-border mx-2" />

            {/* 播放控制按钮 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={onPlay}
                  disabled={isPlaying}
                  className="text-foreground hover:text-white hover:bg-green-600 dark:hover:bg-green-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-green-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <Play className="w-4 h-4 mr-1" />
                  播放
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>播放3D组件动画</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={onPause}
                  disabled={!isPlaying}
                  className="text-foreground hover:text-white hover:bg-yellow-600 dark:hover:bg-yellow-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-yellow-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <Pause className="w-4 h-4 mr-1" />
                  暂停
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>暂停动画播放</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={onStop}
                  className="text-foreground hover:text-white hover:bg-red-600 dark:hover:bg-red-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-red-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <Square className="w-4 h-4 mr-1" />
                  停止
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>停止动画并恢复原始状态</p>
              </TooltipContent>
            </Tooltip>

            <div className="h-4 w-px bg-border mx-2" />

            {/* 录屏控制按钮 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={isRecording ? onStopRecording : onStartRecording}
                  className={`${isRecording ? "text-foreground hover:text-white hover:bg-red-600 dark:hover:bg-red-600" : "text-foreground hover:text-white hover:bg-blue-600 dark:hover:bg-blue-600"} transition-all duration-300 hover:scale-105 hover:shadow-xl ${isRecording ? "hover:shadow-red-500/25" : "hover:shadow-blue-500/25"} group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out`}
                >
                  <Video className="w-4 h-4 mr-1" />
                  {isRecording ? "停止录屏" : "录屏"}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{isRecording ? "停止录屏并下载视频" : "开始录屏画布区域"}</p>
              </TooltipContent>
            </Tooltip>

            <div className="h-4 w-px bg-border mx-2" />

            {/* 发布按钮 */}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => {
                    playSpecial()
                    onPublish?.()
                  }}
                  className="text-foreground hover:text-white hover:bg-purple-600 dark:hover:bg-purple-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-purple-500/25 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
                >
                  <Presentation className="w-4 h-4 mr-1" />
                  发布
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>进入全屏展示模式，自动播放3D动画</p>
              </TooltipContent>
            </Tooltip>
      </div>


      {/* Right Section */}
      <div className="flex items-center gap-2">


        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
              onClick={onToggleFullscreen}
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{isFullscreen ? "退出全屏" : "进入全屏"}</p>
          </TooltipContent>
        </Tooltip>
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
              onClick={() => setShowSettingsDialog(true)}
            >
              <Settings className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>系统设置</p>
          </TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="sm" className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out">
              <Bell className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>通知中心</p>
          </TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="ghost" size="sm" className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out">
              <User className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>用户中心</p>
          </TooltipContent>
        </Tooltip>
        
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="sm" 
              className="shadow-sm hover:shadow-md dark:shadow-md dark:hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-accent/20 group overflow-hidden relative before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/10 before:to-transparent before:translate-x-[-100%] hover:before:translate-x-[100%] before:transition-transform before:duration-500 before:ease-out"
              onClick={() => setShowAboutDialog(true)}
            >
              <Info className="w-4 h-4" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>关于</p>
          </TooltipContent>
        </Tooltip>

        <div className="h-4 w-px bg-border mx-2" />

        <div className="text-xs text-muted-foreground">95.5%</div>

        {/* 明暗主题切换 - 放在最右边 */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleDarkModeToggle}
              className="flex items-center gap-3 px-3"
            >
              <div className="relative">
                <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100 top-0 left-0" />
              </div>
              <span className="text-xs font-medium">
                {themeText}
              </span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>切换明暗主题</p>
          </TooltipContent>
        </Tooltip>
      </div>

      {/* 清除确认弹窗 */}
      <Dialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-600" />
              确认清除画布
            </DialogTitle>
            <DialogDescription>
              此操作将删除画布上的所有图表和内容，且无法撤销。您确定要继续吗？
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={handleCancelClear}
            >
              取消
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleConfirmClear}
            >
              确认清除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 保存对话框 */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Save className="w-5 h-5 text-blue-600" />
              保存仪表板
            </DialogTitle>
            <DialogDescription>
              请输入文件名，文件将保存为JSON格式
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="save-filename" className="text-sm font-medium">
              文件名
            </Label>
            <Input
              id="save-filename"
              placeholder={getDefaultFileName()}
              value={saveFileName}
              onChange={handleSaveFileNameChange}
              onKeyDown={handleSaveFileNameKeyDown}
              className="mt-2"
              autoFocus
            />
            <p className="text-xs text-muted-foreground mt-1">
              建议文件名：{getDefaultFileName()}.json
            </p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={handleCancelSave}
            >
              取消
            </Button>
            <Button 
              onClick={handleConfirmSave}
            >
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 关于对话框 */}
      <Dialog open={showAboutDialog} onOpenChange={setShowAboutDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Info className="w-5 h-5 text-blue-600" />
              关于 微孪数据
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                JF
              </div>
              <h3 className="text-lg font-semibold mb-2">微孪数据</h3>
              <p className="text-sm text-muted-foreground mb-4">
                专业的孪生数据展示平台
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold">©</span>
                </div>
                <div>
                  <p className="font-medium">版权所有</p>
                  <p className="text-sm text-muted-foreground">微凡</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                  <span className="text-xs">📧</span>
                </div>
                <div>
                  <p className="font-medium">联系邮箱</p>
                  <p className="text-sm text-muted-foreground">593790175@qq.com</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                  <span className="text-xs">📍</span>
                </div>
                <div>
                  <p className="font-medium">联系地址</p>
                  <p className="text-sm text-muted-foreground">南京市江宁区秣周东路12号</p>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowAboutDialog(false)}>
              确定
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 系统设置面板 */}
      <SettingsPanel
        isOpen={showSettingsDialog}
        onClose={() => setShowSettingsDialog(false)}
        onExport={(format) => {
          console.log(`导出格式: ${format}`)
          // 这里可以添加实际的导出逻辑
        }}
        onImport={(file) => {
          console.log(`导入文件: ${file.name}`)
          // 这里可以添加实际的导入逻辑
        }}
        onClearCache={() => {
          console.log('清除缓存')
          // 这里可以添加实际的清除缓存逻辑
        }}
        onResetSettings={() => {
          console.log('重置设置')
          // 这里可以添加实际的重置设置逻辑
        }}
      />
    </div>
  )
}
