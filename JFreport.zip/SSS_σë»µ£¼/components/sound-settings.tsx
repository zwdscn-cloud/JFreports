"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Volume2, VolumeX, Music, Settings } from "lucide-react"
import { useSound } from "@/hooks/use-sound"

interface SoundSettingsProps {
  className?: string
}

export function SoundSettings({ className }: SoundSettingsProps) {
  const { playButtonClick, playMenuClick, playSuccess, playError, playHover, playSpecial, setSoundEnabled, setVolume } = useSound()
  const [isEnabled, setIsEnabled] = useState(true)
  const [volume, setVolumeState] = useState(30)

  // 从localStorage加载设置
  useEffect(() => {
    const savedEnabled = localStorage.getItem('soundEnabled')
    const savedVolume = localStorage.getItem('soundVolume')
    
    if (savedEnabled !== null) {
      const enabled = savedEnabled === 'true'
      setIsEnabled(enabled)
      setSoundEnabled(enabled)
    }
    
    if (savedVolume !== null) {
      const vol = parseInt(savedVolume)
      setVolumeState(vol)
      setVolume(vol / 100)
    }
  }, [setSoundEnabled, setVolume])

  // 切换音效开关
  const handleToggleSound = (enabled: boolean) => {
    setIsEnabled(enabled)
    setSoundEnabled(enabled)
    localStorage.setItem('soundEnabled', enabled.toString())
    
    if (enabled) {
      playSuccess()
    }
  }

  // 调整音量
  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0]
    setVolumeState(newVolume)
    setVolume(newVolume / 100)
    localStorage.setItem('soundVolume', newVolume.toString())
    
    if (isEnabled) {
      playHover()
    }
  }

  // 测试音效
  const testSounds = [
    { name: "按钮点击", action: playButtonClick },
    { name: "菜单点击", action: playMenuClick },
    { name: "成功音效", action: playSuccess },
    { name: "错误音效", action: playError },
    { name: "悬停音效", action: playHover },
    { name: "特殊音效", action: playSpecial },
  ]

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="w-5 h-5" />
          音效设置
        </CardTitle>
        <CardDescription>
          自定义应用中的音效体验
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* 音效开关 */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="sound-enabled" className="text-sm font-medium">
              启用音效
            </Label>
            <p className="text-xs text-muted-foreground">
              开启或关闭所有音效
            </p>
          </div>
          <Switch
            id="sound-enabled"
            checked={isEnabled}
            onCheckedChange={handleToggleSound}
          />
        </div>

        {/* 音量控制 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">
              音量
            </Label>
            <div className="flex items-center gap-2">
              <VolumeX className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">{volume}%</span>
              <Volume2 className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
          <Slider
            value={[volume]}
            onValueChange={handleVolumeChange}
            max={100}
            min={0}
            step={5}
            className="w-full"
            disabled={!isEnabled}
          />
        </div>

        {/* 音效测试 */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">
            音效测试
          </Label>
          <div className="grid grid-cols-2 gap-2">
            {testSounds.map((sound, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={sound.action}
                disabled={!isEnabled}
                className="justify-start"
              >
                <Settings className="w-3 h-3 mr-2" />
                {sound.name}
              </Button>
            ))}
          </div>
        </div>

        {/* 音效说明 */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p>• 按钮点击：清脆的布灵声</p>
          <p>• 菜单点击：稍微低一点的布灵声</p>
          <p>• 成功音效：上升的布灵声</p>
          <p>• 错误音效：下降的布灵声</p>
          <p>• 悬停音效：轻微的布灵声</p>
          <p>• 特殊音效：多音调布灵声</p>
        </div>
      </CardContent>
    </Card>
  )
}
