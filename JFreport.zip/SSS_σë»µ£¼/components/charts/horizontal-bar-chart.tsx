"use client"

import { useRef, useEffect, useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface HorizontalBarChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  showLegend?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

export function HorizontalBarChart({
  data,
  title,
  showLegend = true,
  showGrid = true,
  showTooltip = true,
  transparent = true,
  colors = ["#8b5cf6"],
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor,
}: HorizontalBarChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { playHover } = useSound()

  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  // 绘制水平柱状图
  const drawChart = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // 设置画布尺寸
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * window.devicePixelRatio
    canvas.height = rect.height * window.devicePixelRatio
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio)

    // 清空画布
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // 获取画布实际尺寸
    const width = rect.width
    const height = rect.height

    // 计算数据最大值
    const maxValue = Math.max(...data.map(item => item.value))
    const minValue = 0

    // 设置边距
    const margin = { top: 20, right: 60, bottom: 40, left: 100 }
    const chartWidth = width - margin.left - margin.right
    const chartHeight = height - margin.top - margin.bottom

    // 计算每个柱子的高度和间距
    const barHeight = chartHeight / data.length * 0.8
    const barSpacing = chartHeight / data.length * 0.2

    // 绘制网格线
    if (showGrid) {
      ctx.strokeStyle = transparent ? "#374151" : "#e5e7eb"
      ctx.lineWidth = 1
      ctx.setLineDash([3, 3])
      
      // 绘制垂直网格线
      for (let i = 0; i <= 10; i++) {
        const x = margin.left + (chartWidth / 10) * i
        ctx.beginPath()
        ctx.moveTo(x, margin.top)
        ctx.lineTo(x, margin.top + chartHeight)
        ctx.stroke()
      }
      
      ctx.setLineDash([])
    }

    // 绘制X轴
    ctx.strokeStyle = transparent ? "#374151" : "#e5e7eb"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(margin.left, margin.top + chartHeight)
    ctx.lineTo(margin.left + chartWidth, margin.top + chartHeight)
    ctx.stroke()

    // 绘制Y轴
    ctx.beginPath()
    ctx.moveTo(margin.left, margin.top)
    ctx.lineTo(margin.left, margin.top + chartHeight)
    ctx.stroke()

    // 绘制X轴标签
    ctx.fillStyle = axisTextColor || textColors?.axis || (transparent ? "#fff" : "#666")
    ctx.font = `${axisFontSize || 12}px Arial`
    ctx.textAlign = "center"
    for (let i = 0; i <= 10; i++) {
      const x = margin.left + (chartWidth / 10) * i
      const value = (maxValue / 10) * i
      ctx.fillText(value.toFixed(0), x, margin.top + chartHeight + 20)
    }

    // 绘制柱子和标签
    data.forEach((item, index) => {
      const barY = margin.top + (chartHeight / data.length) * index + barSpacing / 2
      const barWidth = (item.value / maxValue) * chartWidth
      
      // 绘制柱子（横向矩形）
      ctx.fillStyle = colors[0] || "#8b5cf6"
      ctx.fillRect(margin.left, barY, barWidth, barHeight)
      
      // 绘制Y轴标签（区域名称）
      ctx.fillStyle = axisTextColor || textColors?.axis || (transparent ? "#fff" : "#666")
      ctx.font = `${axisFontSize || 12}px Arial`
      ctx.textAlign = "right"
      ctx.fillText(item.name, margin.left - 10, barY + barHeight / 2 + 4)
      
      // 绘制数值标签
      ctx.fillStyle = "#fff"
      ctx.font = `bold ${chartFontSize || 12}px Arial`
      ctx.textAlign = "left"
      const labelX = margin.left + barWidth + 5
      const labelY = barY + barHeight / 2 + 4
      ctx.fillText(item.value.toString(), labelX, labelY)
    })

    // 绘制标题
    if (title && !transparent) {
      ctx.fillStyle = titleTextColor || textColors?.title || "#333"
      ctx.font = `bold ${titleFontSize || 18}px Arial`
      ctx.textAlign = "left"
      ctx.fillText(title, margin.left, 20)
    }

    // 绘制图例
    if (showLegend) {
      const legendX = width - 100
      const legendY = height - 30
      
      // 图例颜色块
      ctx.fillStyle = colors[0] || "#8b5cf6"
      ctx.fillRect(legendX, legendY - 10, 15, 10)
    }
  }, [data, title, showLegend, showGrid, transparent, colors, textColors, titleFontSize, titleTextColor, axisFontSize, axisTextColor, legendFontSize, legendTextColor, chartFontSize, chartTextColor])

  useEffect(() => {
    drawChart()
  }, [drawChart])

  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333"),
            fontSize: `${titleFontSize || 18}px`
          }}
        >
          {title}
        </div>
      )}
      
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ width: '100%', height: '100%' }}
      />
    </div>
  )
}