"use client"

import {
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { PurpleGradientDefs } from "./gradient-defs"
import { useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface BarChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  showLegend?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

export function BarChart({
  data,
  title,
  showLegend = true,
  showGrid = true,
  showTooltip = true,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: BarChartProps) {
  const { playHover } = useSound()
  
  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333"),
            fontSize: `${titleFontSize || 18}px`
          }}
        >
          {title}
        </div>
      )}
      <ResponsiveContainer width="100%" height={transparent ? "100%" : "100%"}>
        <RechartsBarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <PurpleGradientDefs />
          {showGrid && (
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke={transparent ? "rgba(255,255,255,0.2)" : "#666"} 
              vertical={false} 
            />
          )}
          <XAxis
            dataKey="name"
            stroke={axisTextColor || textColors?.axis || (transparent ? "#fff" : colors[0])}
            fontSize={axisFontSize || 12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke={axisTextColor || textColors?.axis || (transparent ? "#fff" : colors[0])} 
            fontSize={axisFontSize || 12} 
            tickLine={false} 
            axisLine={false} 
          />
          {showTooltip && (
            <Tooltip
              contentStyle={{
                backgroundColor: transparent ? "rgba(15, 23, 42, 0.9)" : "#fff",
                border: transparent ? "1px solid rgba(255, 255, 255, 0.2)" : "1px solid #ddd",
                borderRadius: "8px",
                color: tooltipTextColor || textColors?.tooltip || (transparent ? "#fff" : "#333"),
                fontSize: `${tooltipFontSize || 12}px`,
              }}
            />
          )}
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontSize: `${legendFontSize || 12}px`,
                color: legendTextColor || textColors?.legend || (transparent ? "#fff" : colors[0]),
              }}
            />
          )}
          <Bar
            dataKey="value"
            fill="url(#purple-gradient-primary)"
            name="数值"
            radius={[4, 4, 0, 0]}
          />
        </RechartsBarChart>
      </ResponsiveContainer>
    </div>
  )
}