"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Upload, ImageIcon } from "lucide-react"
import { useSound } from "@/hooks/use-sound"


interface ImageComponentProps {
  width: number
  height: number
  imageUrl?: string
  alt?: string
  onUrlChange?: (url: string) => void
  isViewMode?: boolean
  // 边框设置
  showBorder?: boolean
  borderWidth?: number
  borderColor?: string
}

export function ImageComponent({
  width,
  height,
  imageUrl = "",
  alt = "图片",
  onUrlChange,
  isViewMode = false,
  showBorder = false,
  borderWidth = 1,
  borderColor = "#e5e7eb",
}: ImageComponentProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [hasError, setHasError] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [previousImageUrl, setPreviousImageUrl] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { playHover } = useSound()

  const handleImageLoad = () => {
    setIsLoading(false)
    setHasError(false)
  }

  const handleImageError = () => {
    setIsLoading(false)
    setHasError(true)
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  // 跟踪图片URL变化，清理之前的图片
  useEffect(() => {
    if (imageUrl && previousImageUrl && imageUrl !== previousImageUrl) {
      // 如果当前图片是base64数据且与之前的图片不同，清理之前的图片
      if (previousImageUrl.startsWith('data:image/')) {
        console.log('自动清理之前的图片数据')
        // 清理base64数据，释放内存
        // 由于base64数据是字符串，JavaScript的垃圾回收会自动处理
        // 但我们可以强制触发垃圾回收（如果浏览器支持）
        if (window.gc) {
          window.gc()
        }
      }
    }
    if (imageUrl) {
      setPreviousImageUrl(imageUrl)
    }
  }, [imageUrl, previousImageUrl])

  // 组件卸载时清理资源
  useEffect(() => {
    return () => {
      // 组件卸载时清理图片数据
      if (imageUrl && imageUrl.startsWith('data:image/')) {
        console.log('组件卸载，清理图片数据')
      }
    }
  }, [imageUrl])

  const handleFileUpload = (file: File) => {
    // 检查文件类型
    if (!file.type.startsWith('image/')) {
      alert('请选择图片文件')
      return
    }

    // 检查文件大小 (限制为10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('图片文件大小不能超过10MB')
      return
    }

    setIsUploading(true)
    setIsLoading(true)

    // 创建FileReader来读取文件
    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      if (result && onUrlChange) {
        // 如果有之前的图片，显示替换提示
        if (imageUrl && imageUrl.startsWith('data:image/')) {
          console.log('正在替换之前的图片...')
        }
        
        // 上传新图片，自动替换之前的图片
        onUrlChange(result)
        setIsUploading(false)
        setIsLoading(false)
        console.log('新图片上传成功，已自动替换之前的图片')
      }
    }
    reader.onerror = () => {
      setIsUploading(false)
      setIsLoading(false)
      setHasError(true)
    }
    reader.readAsDataURL(file)
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div
      className="w-full h-full bg-white overflow-hidden flex items-center justify-center relative group cursor-move"
      style={{
        border: showBorder ? `${borderWidth}px solid ${borderColor}` : 'none'
      }}
      onMouseEnter={handleMouseEnter}
      onClick={!imageUrl ? handleUploadClick : undefined}
    >
      {imageUrl ? (
        <img
          src={imageUrl || "/placeholder.svg"}
          alt={alt}
          className="w-full h-full object-cover"
          onLoad={handleImageLoad}
          onError={handleImageError}
        />
      ) : (
        <div className="flex flex-col items-center justify-center text-gray-400 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
          </svg>
          <span className="text-sm">点击上传图片</span>
        </div>
      )}

      {/* 上传按钮 - 只在非查看模式下显示 */}
      {!isViewMode && (
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <Button 
            size="sm" 
            variant="secondary" 
            className="shadow-lg"
            onClick={handleUploadClick}
            disabled={isUploading}
          >
            <Upload className="w-4 h-4 mr-1" />
            {isUploading ? "上传中..." : "上传"}
          </Button>
        </div>
      )}

      {/* 隐藏的文件输入 */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />

      {hasError && (
        <div className="flex flex-col items-center justify-center text-red-400 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span className="text-sm">图片加载失败</span>
        </div>
      )}
          </div>
  )
}
