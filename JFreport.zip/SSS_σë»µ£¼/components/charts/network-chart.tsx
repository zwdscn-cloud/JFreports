"use client"

import { useEffect, useRef, useState } from "react"
import { ResponsiveContainer } from "recharts"
import { getThemeById, applyThemeToChart } from "@/lib/color-themes"

interface NetworkNode {
  id: string
  name: string
  value?: number
  group?: string
  size?: number
}

interface NetworkLink {
  source: string
  target: string
  value?: number
  type?: string
}

interface NetworkChartProps {
  data?: {
    nodes: NetworkNode[]
    links: NetworkLink[]
  }
  width?: number
  height?: number
  colors?: string[]
  title?: string
  themeId?: string
  transparent?: boolean
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

const defaultData = {
  nodes: [
    { id: "1", name: "节点1" },
    { id: "2", name: "节点2" },
    { id: "3", name: "节点3" },
    { id: "4", name: "节点4" },
  ],
  links: [
    { source: "1", target: "2" },
    { source: "2", target: "3" },
    { source: "3", target: "4" },
    { source: "4", target: "1" },
  ],
}

export function NetworkChart({
  data = defaultData,
  width = 400,
  height = 300,
  colors,
  title = "关系图",
  themeId = "DA001",
  transparent = false,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: NetworkChartProps) {
  const theme = getThemeById(themeId)
  const chartColors = colors || (theme ? applyThemeToChart(theme, "network") : ["#FFA500", "#00D4FF"])
  const svgRef = useRef<SVGSVGElement>(null)
  const [nodePositions, setNodePositions] = useState<Map<string, { x: number; y: number }>>(new Map())
  const [hoveredNode, setHoveredNode] = useState<string | null>(null)
  const [hoveredLink, setHoveredLink] = useState<number | null>(null)

  useEffect(() => {
    if (!data?.nodes?.length) return

    const positions = new Map<string, { x: number; y: number }>()
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) * 0.3

    data.nodes.forEach((node, index) => {
      const angle = (index / data.nodes.length) * 2 * Math.PI
      const x = centerX + radius * Math.cos(angle)
      const y = centerY + radius * Math.sin(angle)
      positions.set(node.id, { x, y })
    })

    for (let iteration = 0; iteration < 50; iteration++) {
      const newPositions = new Map(positions)
      
      data.nodes.forEach((node1) => {
        const pos1 = positions.get(node1.id)!
        let fx = 0, fy = 0
        
        data.nodes.forEach((node2) => {
          if (node1.id === node2.id) return
          const pos2 = positions.get(node2.id)!
          const dx = pos1.x - pos2.x
          const dy = pos1.y - pos2.y
          const distance = Math.sqrt(dx * dx + dy * dy)
          if (distance > 0) {
            const force = 1000 / (distance * distance)
            fx += (dx / distance) * force
            fy += (dy / distance) * force
          }
        })
        
        data.links?.forEach((link) => {
          if (link.source === node1.id) {
            const targetPos = positions.get(link.target)
            if (targetPos) {
              const dx = targetPos.x - pos1.x
              const dy = targetPos.y - pos1.y
              const distance = Math.sqrt(dx * dx + dy * dy)
              if (distance > 0) {
                const force = distance * 0.01
                fx += (dx / distance) * force
                fy += (dy / distance) * force
              }
            }
          }
        })
        
        const newX = Math.max(50, Math.min(width - 50, pos1.x + fx * 0.1))
        const newY = Math.max(50, Math.min(height - 50, pos1.y + fy * 0.1))
        newPositions.set(node1.id, { x: newX, y: newY })
      })
      
      positions.clear()
      newPositions.forEach((pos, id) => positions.set(id, pos))
    }
    
    setNodePositions(positions)
  }, [data?.nodes, data?.links, width, height])

  const getNodeColor = (node: NetworkNode) => {
    if (node.group) {
      const groups = Array.from(new Set(data?.nodes?.map(n => n.group).filter(Boolean) || []))
      const groupIndex = groups.indexOf(node.group)
      return chartColors[groupIndex % chartColors.length]
    }
    return chartColors[0]
  }

  const getNodeSize = (node: NetworkNode) => {
    return node.size || Math.max(10, Math.min(30, (node.value || 1) * 2))
  }

  const getLinkColor = (link: NetworkLink) => {
    if (link.type === 'strong') return '#ff6b6b'
    if (link.type === 'weak') return '#4ecdc4'
    return '#95a5a6'
  }

  const containerClasses = [
    "w-full h-full",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-4"
  ].filter(Boolean).join(" ")

  return (
    <div className={containerClasses}>
      {title && !transparent && (
        <div className="mb-2">
          <h3 
            className="font-semibold tracking-tight drop-shadow-sm"
            style={{ 
              fontSize: `${titleFontSize || 14}px`,
              color: titleTextColor || textColors?.title || (transparent ? "#ffffff" : "#333333")
            }}
          >
            {title}
          </h3>
        </div>
      )}
      
      <div className="h-full w-full relative">
        {!data || !data.nodes || data.nodes.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="text-sm mb-2" style={{ color: chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#666666") }}>
                暂无数据
              </div>
              <div className="text-xs" style={{ color: chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#999999") }}>
                请在属性面板中添加节点和连接数据
              </div>
            </div>
          </div>
        ) : (
          <>
            <svg
              ref={svgRef}
              width="100%"
              height="100%"
              viewBox={`0 0 ${width} ${height}`}
              className="absolute inset-0"
            >
              {data?.links?.map((link, index) => {
                const sourcePos = nodePositions.get(link.source)
                const targetPos = nodePositions.get(link.target)
                
                if (!sourcePos || !targetPos) return null
                
                const sourceSize = getNodeSize(data?.nodes?.find(n => n.id === link.source) || { id: link.source, name: '', value: 1 })
                const targetSize = getNodeSize(data?.nodes?.find(n => n.id === link.target) || { id: link.target, name: '', value: 1 })
                
                const dx = targetPos.x - sourcePos.x
                const dy = targetPos.y - sourcePos.y
                const distance = Math.sqrt(dx * dx + dy * dy)
                
                if (distance === 0) return null
                
                const sourceRadius = sourceSize / 2
                const targetRadius = targetSize / 2
                
                const startX = sourcePos.x + (dx / distance) * sourceRadius
                const startY = sourcePos.y + (dy / distance) * sourceRadius
                const endX = targetPos.x - (dx / distance) * targetRadius
                const endY = targetPos.y - (dy / distance) * targetRadius
                
                return (
                  <g key={`link-${index}`}>
                    <line
                      x1={startX}
                      y1={startY}
                      x2={endX}
                      y2={endY}
                      stroke={getLinkColor(link)}
                      strokeWidth={Math.max(1, (link.value || 1) * 0.5)}
                      opacity={hoveredLink === index ? 1 : 0.6}
                      onMouseEnter={() => setHoveredLink(index)}
                      onMouseLeave={() => setHoveredLink(null)}
                      style={{ cursor: 'pointer' }}
                    />
                    {link.value && link.value > 1 && (
                      <text
                        x={(startX + endX) / 2}
                        y={(startY + endY) / 2}
                        textAnchor="middle"
                        dy="-5"
                        fontSize={chartFontSize || 10}
                        fill={chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#333333")}
                        className="pointer-events-none"
                      >
                        {link.value}
                      </text>
                    )}
                  </g>
                )
              })}
              
              {data?.nodes?.map((node) => {
                const pos = nodePositions.get(node.id)
                if (!pos) return null
                
                const size = getNodeSize(node)
                const color = getNodeColor(node)
                const isHovered = hoveredNode === node.id
                
                return (
                  <g key={node.id}>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r={size}
                      fill={color}
                      stroke={isHovered ? "#ffffff" : "rgba(255,255,255,0.3)"}
                      strokeWidth={isHovered ? 3 : 1}
                      opacity={isHovered ? 1 : 0.8}
                      onMouseEnter={() => setHoveredNode(node.id)}
                      onMouseLeave={() => setHoveredNode(null)}
                      style={{ cursor: 'pointer' }}
                    />
                    
                    <text
                      x={pos.x}
                      y={pos.y + size + 15}
                      textAnchor="middle"
                      fontSize={chartFontSize || 12}
                      fill={chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#333333")}
                      fontWeight="500"
                      className="pointer-events-none"
                    >
                      {node.name}
                    </text>
                    
                    {node.value && node.value > 1 && (
                      <text
                        x={pos.x}
                        y={pos.y}
                        textAnchor="middle"
                        dy="0.35em"
                        fontSize={Math.max(8, (chartFontSize || 12) * 0.8)}
                        fill={chartTextColor || textColors?.label || "#ffffff"}
                        fontWeight="bold"
                        className="pointer-events-none"
                      >
                        {node.value}
                      </text>
                    )}
                  </g>
                )
              })}
            </svg>
            
            {data?.nodes?.some(n => n.group) && (
              <div className="absolute bottom-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
                <div className="text-xs font-medium mb-2" style={{ color: legendTextColor || textColors?.legend || "#ffffff" }}>
                  分组图例
                </div>
                <div className="space-y-1">
                  {Array.from(new Set(data?.nodes?.map(n => n.group).filter(Boolean) || [])).map((group, index) => (
                    <div key={group} className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: chartColors[index % chartColors.length] }}
                      />
                      <span 
                        className="text-xs"
                        style={{ color: legendTextColor || textColors?.legend || "#ffffff" }}
                      >
                        {group}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
} 