"use client"

import React from "react"

interface WordCloudChartProps {
	words?: Array<{ text: string; value: number }>
	width?: number
	height?: number
	title?: string
	transparent?: boolean
}

const defaultWords = [
	{ text: "数据", value: 60 },
	{ text: "分析", value: 40 },
	{ text: "可视化", value: 30 },
	{ text: "报表", value: 25 },
	{ text: "BI", value: 20 },
]

export function WordCloudChart({ words = defaultWords, width = 400, height = 300, title = "词云图", transparent = false }: WordCloudChartProps) {
	const containerClasses = transparent ? "w-full h-full" : "w-full h-full bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
	return (
		<div className={containerClasses}>
			{title && !transparent && <h3 className="text-sm font-semibold text-white mb-2">{title}</h3>}
			<div className="w-full h-full relative">
				{words.map((w, i) => (
					<span key={i} className="absolute" style={{ left: `${(i * 23) % 80}%`, top: `${(i * 17) % 70}%`, fontSize: `${12 + w.value / 3}px`, color: `hsl(${(i * 57) % 360} 70% 60%)` }}>
						{w.text}
					</span>
				))}
			</div>
		</div>
	)
}


