// 紫色渐变颜色（用于不支持渐变的图表库）
export const PURPLE_GRADIENT_COLORS = [
  "#8b5cf6", // 紫色
  "#a855f7", // 紫色变体
  "#c084fc", // 浅紫色
  "#d8b4fe", // 更浅紫色
  "#e9d5ff", // 极浅紫色
  "#f3e8ff", // 最浅紫色
  "#8b5cf6", // 循环回到紫色
  "#a855f7",
  "#c084fc",
  "#d8b4fe"
]

// 统一的图表颜色主题
export const CHART_COLORS = {
  // 主要颜色方案 - 紫色渐变系
  primary: [
    "linear-gradient(135deg, #8b5cf6 0%, #a855f7 50%, #c084fc 100%)",
    "linear-gradient(135deg, #a855f7 0%, #c084fc 50%, #d8b4fe 100%)",
    "linear-gradient(135deg, #c084fc 0%, #d8b4fe 50%, #e9d5ff 100%)",
    "linear-gradient(135deg, #8b5cf6 0%, #c084fc 50%, #e9d5ff 100%)",
    "linear-gradient(135deg, #a855f7 0%, #d8b4fe 50%, #f3e8ff 100%)"
  ],
  
  // 备用颜色方案 - 紫色渐变变体
  secondary: [
    "linear-gradient(135deg, #6b21a8 0%, #8b5cf6 50%, #a855f7 100%)",
    "linear-gradient(135deg, #8b5cf6 0%, #a855f7 50%, #c084fc 100%)",
    "linear-gradient(135deg, #a855f7 0%, #c084fc 50%, #d8b4fe 100%)",
    "linear-gradient(135deg, #c084fc 0%, #d8b4fe 50%, #e9d5ff 100%)",
    "linear-gradient(135deg, #6b21a8 0%, #a855f7 50%, #c084fc 100%)"
  ],
  
  // 灰度方案
  grayscale: ["#6b7280", "#9ca3af", "#d1d5db", "#e5e7eb", "#f3f4f6"],
  
  // 暖色方案
  warm: ["#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16"],
  
  // 冷色方案 - 紫色渐变
  cool: [
    "linear-gradient(135deg, #8b5cf6 0%, #a855f7 50%, #c084fc 100%)",
    "linear-gradient(135deg, #a855f7 0%, #c084fc 50%, #d8b4fe 100%)",
    "linear-gradient(135deg, #c084fc 0%, #d8b4fe 50%, #e9d5ff 100%)",
    "linear-gradient(135deg, #8b5cf6 0%, #c084fc 50%, #e9d5ff 100%)",
    "linear-gradient(135deg, #a855f7 0%, #d8b4fe 50%, #f3e8ff 100%)"
  ],
}

// 默认颜色方案 - 使用紫色渐变颜色
export const DEFAULT_CHART_COLORS = PURPLE_GRADIENT_COLORS

// 根据图表类型获取颜色
export const getChartColors = (chartType: string, customColors?: string[]) => {
  if (customColors && customColors.length > 0) {
    return customColors
  }
  
  switch (chartType) {
    case "bar":
    case "line":
    case "area":
    case "pie":
    case "funnel":
    case "radar":
    case "scatter":
    case "histogram":
    case "boxplot":
    case "waterfall":
    case "timeline":
    case "combo":
    default:
      return DEFAULT_CHART_COLORS
  }
}

// 获取单个颜色
export const getChartColor = (index: number, customColors?: string[]) => {
  const colors = customColors || DEFAULT_CHART_COLORS
  return colors[index % colors.length]
}

// 获取紫色渐变颜色
export const getPurpleColor = (index: number) => {
  return PURPLE_GRADIENT_COLORS[index % PURPLE_GRADIENT_COLORS.length]
}
