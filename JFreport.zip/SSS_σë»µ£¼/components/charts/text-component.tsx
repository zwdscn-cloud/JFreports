"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface TextComponentProps {
  width?: number
  height?: number
  content?: string
  fontSize?: number
  fontWeight?: string
  textAlign?: string
  textColor?: string
  backgroundColor?: string
  transparent?: boolean
  isViewMode?: boolean
  onContentChange?: (content: string) => void
}

export function TextComponent({
  width = 400,
  height = 200,
  content = "点击编辑文本内容",
  fontSize = 14,
  fontWeight = "normal",
  textAlign = "left",
  textColor = "#000000",
  backgroundColor = "#ffffff",
  transparent = false,
  isViewMode = false,
  onContentChange
}: TextComponentProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editContent, setEditContent] = useState(content)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  useEffect(() => {
    setEditContent(content)
  }, [content])

  const handleDoubleClick = () => {
    if (isViewMode) return
    setIsEditing(true)
    setTimeout(() => {
      textareaRef.current?.focus()
      textareaRef.current?.select()
    }, 0)
  }

  const handleSave = () => {
    setIsEditing(false)
    onContentChange?.(editContent)
  }

  const handleCancel = () => {
    setIsEditing(false)
    setEditContent(content)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && e.ctrlKey) {
      handleSave()
    } else if (e.key === 'Escape') {
      handleCancel()
    }
  }

  if (isEditing) {
    return (
      <div 
        className="w-full h-full flex flex-col p-2 border-2 border-blue-500 rounded"
        style={{ 
          width: `${width}px`, 
          height: `${height}px`,
          backgroundColor: transparent ? 'transparent' : backgroundColor
        }}
      >
        <div className="flex-1 mb-2">
          <Label htmlFor="text-content" className="text-xs">文本内容</Label>
          <Textarea
            id="text-content"
            value={editContent}
            onChange={(e) => setEditContent(e.target.value)}
            onKeyDown={handleKeyDown}
            className="h-full text-sm resize-none"
            placeholder="输入文本内容..."
            style={{ fontSize: `${fontSize}px` }}
          />
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={handleSave} className="flex-1">
            保存 (Ctrl+Enter)
          </Button>
          <Button size="sm" variant="outline" onClick={handleCancel}>
            取消 (Esc)
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div 
      className="w-full h-full flex items-start justify-start p-2 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
      style={{ 
        width: `${width}px`, 
        height: `${height}px`,
        backgroundColor: transparent ? 'transparent' : backgroundColor,
        boxSizing: 'border-box'
      }}
      onDoubleClick={handleDoubleClick}
    >
      <div
        className="w-full h-full flex items-start justify-start"
        style={{
          fontSize: `${fontSize}px`,
          fontWeight: fontWeight,
          color: textColor,
          textAlign: textAlign as 'left' | 'center' | 'right',
          lineHeight: '1.5',
          width: '100%',
          wordBreak: 'break-word',
          overflowWrap: 'break-word',
          maxWidth: '100%',
          overflow: 'hidden'
        }}
      >
        {editContent || "双击编辑文本内容"}
      </div>
    </div>
  )
}
