"use client"

import { useState, useRef } from "react"

interface AudioComponentProps {
  width: number
  height: number
  audioUrl?: string
  autoplay?: boolean
  controls?: boolean
  onUrlChange?: (url: string) => void
  isViewMode?: boolean
}

export function AudioComponent({
  width,
  height,
  audioUrl = "",
  autoplay = false,
  controls = true,
  onUrlChange,
  isViewMode = false,
}: AudioComponentProps) {
  const [hasError, setHasError] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const audioRef = useRef<HTMLAudioElement>(null)

  const handleAudioError = () => {
    setHasError(true)
  }

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  return (
    <div
      className="w-full h-full bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg border border-gray-200 overflow-hidden flex items-center justify-center"
    >
      {audioUrl ? (
        <div className="flex flex-col items-center justify-center p-4">
          <audio
            ref={audioRef}
            src={audioUrl}
            controls={controls}
            autoPlay={autoplay}
            onError={handleAudioError}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            className="w-full max-w-xs"
          >
            您的浏览器不支持音频播放
          </audio>

          {!controls && (
            <button
              onClick={togglePlay}
              className="mt-4 p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-shadow"
            >
              {isPlaying ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1.01M15 10h1.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              )}
            </button>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center text-gray-600 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"
            />
          </svg>
          <span className="text-sm">请在属性面板设置音频URL</span>
        </div>
      )}

      {hasError && (
        <div className="flex flex-col items-center justify-center text-red-400 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span className="text-sm">音频加载失败</span>
        </div>
      )}
    </div>
  )
}
