"use client"

import { useState } from "react"


interface VideoComponentProps {
  width: number
  height: number
  videoUrl?: string
  autoplay?: boolean
  controls?: boolean
  muted?: boolean
  onUrlChange?: (url: string) => void
  isViewMode?: boolean
  // 边框设置
  showBorder?: boolean
  borderWidth?: number
  borderColor?: string
}

export function VideoComponent({
  width,
  height,
  videoUrl = "",
  autoplay = false,
  controls = true,
  muted = false,
  onUrlChange,
  isViewMode = false,
  showBorder = true,
  borderWidth = 1,
  borderColor = "#e5e7eb",
}: VideoComponentProps) {
  const [hasError, setHasError] = useState(false)

  const handleVideoError = () => {
    setHasError(true)
  }

  return (
    <div
      className="w-full h-full bg-black rounded-lg overflow-hidden flex items-center justify-center"
      style={{
        border: showBorder ? `${borderWidth}px solid ${borderColor}` : 'none'
      }}
    >
      {videoUrl ? (
        <video
          src={videoUrl}
          className="w-full h-full object-cover"
          controls={controls}
          autoPlay={autoplay}
          muted={muted}
          onError={handleVideoError}
        >
          您的浏览器不支持视频播放
        </video>
      ) : (
        <div className="flex flex-col items-center justify-center text-gray-400 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1.01M15 10h1.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11l-3-3-3 3" />
          </svg>
          <span className="text-sm">请在属性面板设置视频URL</span>
        </div>
      )}

      {hasError && (
        <div className="flex flex-col items-center justify-center text-red-400 p-4">
          <svg className="w-12 h-12 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span className="text-sm">视频加载失败</span>
        </div>
      )}
          </div>
  )
}
