"use client"

import React, { useMemo } from "react"
import type { SankeyData, SankeyNode, SankeyLink } from "@/components/chart-data-editors/sankey-editor"

interface SankeyChartProps {
  width?: number
  height?: number
  title?: string
  transparent?: boolean
  data?: SankeyData
}

interface SankeyLayout {
  nodes: (SankeyNode & { x: number; y: number; width: number; height: number })[]
  links: (SankeyLink & { path: string; width: number })[]
}

export function SankeyChart({ 
  width = 400, 
  height = 300, 
  title = "桑基图", 
  transparent = false,
  data 
}: SankeyChartProps) {
  const containerClasses = transparent ? "w-full h-full" : "w-full h-full bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-4"
  
  // 调试信息
  console.log("[SankeyChart] 接收到的数据:", data)

  // 获取节点深度
  const getNodeDepth = (nodeId: string, data: SankeyData): number => {
    const visited = new Set<string>()
    const queue: { id: string; depth: number }[] = []
    
    // 找到源头节点
    const sourceNodes = data.nodes.filter(node => 
      !data.links.some(link => link.target === node.id)
    )
    
    sourceNodes.forEach(node => queue.push({ id: node.id, depth: 0 }))
    
    while (queue.length > 0) {
      const { id, depth } = queue.shift()!
      if (visited.has(id)) continue
      visited.add(id)
      
      if (id === nodeId) return depth
      
      // 找到所有以当前节点为源的连接
      data.links
        .filter(link => link.source === id)
        .forEach(link => {
          queue.push({ id: link.target, depth: depth + 1 })
        })
    }
    
    return 0
  }

  // 获取最大深度
  const getMaxDepth = (data: SankeyData): number => {
    let maxDepth = 0
    data.nodes.forEach(node => {
      maxDepth = Math.max(maxDepth, getNodeDepth(node.id, data))
    })
    return maxDepth + 1
  }

  // 生成桑基图连接路径
  const generateSankeyPath = (
    source: any, 
    target: any, 
    value: number, 
    data: SankeyData
  ): string => {
    const sourceX = source.x + source.width
    const sourceY = source.y + source.height / 2
    const targetX = target.x
    const targetY = target.y + target.height / 2
    
    const midX1 = sourceX + (targetX - sourceX) * 0.25
    const midX2 = sourceX + (targetX - sourceX) * 0.75
    
    return `M ${sourceX} ${sourceY} C ${midX1} ${sourceY} ${midX2} ${targetY} ${targetX} ${targetY}`
  }

  // 桑基图布局计算
  const sankeyLayout = useMemo((): SankeyLayout => {
    console.log("[SankeyChart] 计算布局，数据:", data)
    if (!data || !data.nodes || !data.links) {
      console.log("[SankeyChart] 数据无效，返回空布局")
      return { nodes: [], links: [] }
    }

    // 计算实际需要的宽度和高度
    const maxDepth = getMaxDepth(data)
    const maxNodesInDepth = Math.max(...Array.from({ length: maxDepth }, (_, depth) => 
      data.nodes.filter(n => getNodeDepth(n.id, data) === depth).length
    ))
    
    const requiredWidth = maxDepth * 120 + (maxDepth - 1) * 40 + 80 // 节点宽度 + 列间距 + 边距
    const requiredHeight = maxNodesInDepth * 50 + (maxNodesInDepth - 1) * 20 + 80 // 节点高度 + 行间距 + 边距
    
    const chartWidth = Math.max(width - 40, requiredWidth)
    const chartHeight = Math.max(height - 60, requiredHeight)
    const nodeHeight = 30
    const nodeSpacing = 20
    const columnSpacing = chartWidth / (Math.max(1, maxDepth - 1))

    // 计算节点位置
    const nodes = data.nodes.map((node, index) => {
      const depth = getNodeDepth(node.id, data)
      const x = depth * columnSpacing + 20 // 添加左边距，避免被遮盖
      
      // 计算同一深度节点的垂直位置，确保不重叠且居中
      const sameDepthNodes = data.nodes.filter(n => getNodeDepth(n.id, data) === depth)
      const sameDepthIndex = sameDepthNodes.findIndex(n => n.id === node.id)
      const totalSameDepth = sameDepthNodes.length
      
      // 计算垂直间距，确保节点不重叠
      const minVerticalSpacing = nodeHeight + nodeSpacing
      const totalVerticalHeight = totalSameDepth * minVerticalSpacing - nodeSpacing
      const startY = (chartHeight - totalVerticalHeight) / 2
      const y = startY + sameDepthIndex * minVerticalSpacing
      
      return {
        ...node,
        x,
        y,
        width: 80,
        height: nodeHeight
      }
    })

    // 计算连接路径
    const links = data.links.map(link => {
      const sourceNode = nodes.find(n => n.id === link.source)
      const targetNode = nodes.find(n => n.id === link.target)
      
      if (!sourceNode || !targetNode) {
        return { ...link, path: "", width: 0 }
      }

      const path = generateSankeyPath(sourceNode, targetNode, link.value, data)
      const width = Math.max(2, Math.sqrt(link.value) * 0.5)

      return { ...link, path, width }
    })

    return { nodes, links }
  }, [data, width, height])

  // 检查数据有效性
  const hasValidData = data && 
    data.nodes && 
    Array.isArray(data.nodes) && 
    data.nodes.length > 0 &&
    data.links &&
    Array.isArray(data.links)

  if (!hasValidData) {
    return (
      <div className={containerClasses}>
        {title && !transparent && <h3 className="text-sm font-semibold text-white mb-2">{title}</h3>}
        <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
          {!data ? "请添加桑基图数据" : 
           !data.nodes || data.nodes.length === 0 ? "请先添加节点" :
           !data.links || data.links.length === 0 ? "请添加节点连接" :
           "数据格式错误"}
        </div>
      </div>
    )
  }

  return (
    <div className={containerClasses}>
      {title && !transparent && <h3 className="text-sm font-semibold text-white mb-2">{title}</h3>}
      <div className="w-full h-full">
        <svg 
          width="100%" 
          height="100%" 
          viewBox={`0 0 ${Math.max(width, sankeyLayout.nodes.length > 0 ? Math.max(...sankeyLayout.nodes.map(n => n.x + n.width)) + 40 : width)} ${Math.max(height, sankeyLayout.nodes.length > 0 ? Math.max(...sankeyLayout.nodes.map(n => n.y + n.height)) + 40 : height)}`}
          className="w-full h-full" 
          style={{ overflow: 'visible' }}
        >
          <defs>
            <linearGradient id="sankeyGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.8" />
            </linearGradient>
          </defs>
          
          {/* 绘制连接 */}
          {sankeyLayout.links.map((link, index) => (
            <g key={index}>
              <path
                d={link.path}
                stroke="url(#sankeyGradient)"
                strokeWidth={link.width}
                fill="none"
                opacity="0.6"
              />
              <path
                d={link.path}
                stroke="url(#sankeyGradient)"
                strokeWidth={link.width}
                fill="none"
                opacity="0.3"
                filter="blur(2)"
              />
            </g>
          ))}
          
          {/* 绘制节点 */}
          {sankeyLayout.nodes.map((node, index) => (
            <g key={node.id}>
              <rect
                x={node.x}
                y={node.y}
                width={node.width}
                height={node.height}
                rx="4"
                fill="#1e293b"
                stroke="#475569"
                strokeWidth="1"
              />
              <text
                x={node.x + node.width / 2}
                y={node.y + node.height / 2 + 4}
                textAnchor="middle"
                fontSize="12"
                fill="#f8fafc"
                fontWeight="500"
              >
                {node.name}
              </text>
              {node.category && (
                <text
                  x={node.x + node.width / 2}
                  y={node.y + node.height / 2 + 18}
                  textAnchor="middle"
                  fontSize="10"
                  fill="#94a3b8"
                >
                  {node.category}
                </text>
              )}
            </g>
          ))}
        </svg>
      </div>
    </div>
  )
}


