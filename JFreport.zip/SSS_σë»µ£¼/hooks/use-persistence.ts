'use client'

import { useState, useEffect, useCallback } from 'react'

interface DashboardData {
  canvasElements: any[]
  selectedElement: string | null
  activeTheme: string
  isDarkMode: boolean
  canvasSettings: {
    width: number
    height: number
    backgroundColor: string
  }
}

const STORAGE_KEY = '微孪数据-dashboard-data'

export function usePersistence() {
  const [isLoaded, setIsLoaded] = useState(false)

  // 保存数据到本地存储
  const saveData = useCallback((data: Partial<DashboardData>) => {
    try {
      const existingData = localStorage.getItem(STORAGE_KEY)
      const currentData = existingData ? JSON.parse(existingData) : {}
      const newData = { ...currentData, ...data }
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData))
    } catch (error) {
      console.warn('Failed to save data to localStorage:', error)
    }
  }, [])

  // 从本地存储加载数据
  const loadData = useCallback((): Partial<DashboardData> => {
    try {
      const data = localStorage.getItem(STORAGE_KEY)
      return data ? JSON.parse(data) : {}
    } catch (error) {
      console.warn('Failed to load data from localStorage:', error)
      return {}
    }
  }, [])

  // 清除所有数据
  const clearData = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY)
    } catch (error) {
      console.warn('Failed to clear data from localStorage:', error)
    }
  }, [])

  // 页面卸载时保存数据
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      // 提示用户数据已自动保存
      e.preventDefault()
      e.returnValue = '您的数据已自动保存，确定要离开吗？'
      return '您的数据已自动保存，确定要离开吗？'
    }

    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload)
    }
  }, [])

  return {
    isLoaded,
    saveData,
    loadData,
    clearData
  }
}
