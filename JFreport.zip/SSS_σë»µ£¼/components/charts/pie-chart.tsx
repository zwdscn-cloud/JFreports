"use client"

import {
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  Sector,
} from "recharts"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { PurpleGradientDefs } from "./gradient-defs"
import { useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface PieChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  showLegend?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

const renderActiveShape = (props: any, transparent: boolean) => {
  const RADIAN = Math.PI / 180
  const { cx, cy, midAngle, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props
  const sin = Math.sin(-RADIAN * midAngle)
  const cos = Math.cos(-RADIAN * midAngle)
  const sx = cx + (outerRadius + 10) * cos
  const sy = cy + (outerRadius + 10) * sin
  const mx = cx + (outerRadius + 30) * cos
  const my = cy + (outerRadius + 30) * sin
  const ex = mx + (cos >= 0 ? 1 : -1) * 22
  const ey = my
  const textAnchor = cos >= 0 ? 'start' : 'end'

  return (
    <g>
      <text x={cx} y={cy} dy={8} textAnchor="middle" fill={transparent ? "#fff" : "#8b5cf6"} fontSize={14} fontWeight="bold">
        {payload.name}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" strokeWidth={2} />
      <circle cx={sx} cy={sy} r={2} fill={fill} stroke="none" />
             <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill={transparent ? "#fff" : "#8b5cf6"} fontSize={12}>
         {`${payload.name} ${(percent * 100).toFixed(0)}%`}
       </text>
    </g>
  )
}

export function PieChart({
  data,
  title,
  showLegend = true,
  showTooltip = true,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: PieChartProps) {
  const { playHover } = useSound()
  
  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333"),
            fontSize: `${titleFontSize || 18}px`
          }}
        >
          {title}
        </div>
      )}
      <div className="flex items-center justify-center w-full h-full">
        <ResponsiveContainer width="100%" height={transparent ? "100%" : "100%"}>
          <RechartsPieChart>
          <PurpleGradientDefs />
                     <Pie
             data={data}
             cx="50%"
             cy="50%"
             labelLine={true}
             label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
             outerRadius={80}
             fill="#8884d8"
             dataKey="value"
             activeShape={(props) => renderActiveShape(props, transparent)}
           >
            {data.map((entry, index) => {
              const gradientIds = ['purple-gradient-primary', 'purple-gradient-secondary', 'purple-gradient-tertiary', 'purple-gradient-quaternary', 'purple-gradient-quinary']
              return (
                <Cell key={`cell-${index}`} fill={`url(#${gradientIds[index % gradientIds.length]})`} />
              )
            })}
          </Pie>
          {showTooltip && (
            <Tooltip
              contentStyle={{
                backgroundColor: transparent ? "rgba(15, 23, 42, 0.9)" : "#fff",
                border: transparent ? "1px solid rgba(255, 255, 255, 0.2)" : "1px solid #ddd",
                borderRadius: "8px",
                color: tooltipTextColor || textColors?.tooltip || (transparent ? "#fff" : "#333"),
                fontSize: `${tooltipFontSize || 12}px`,
              }}
              formatter={(value: any, name: any) => [value, name]}
            />
          )}
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontSize: `${legendFontSize || 12}px`,
                color: legendTextColor || textColors?.legend || (transparent ? "#fff" : "#8b5cf6"),
              }}
              formatter={(value, entry, index) => (
                <span style={{ 
                  color: legendTextColor || textColors?.legend || (transparent ? "#fff" : "#8b5cf6"),
                  fontSize: `${legendFontSize || 12}px`
                }}>
                  {data[index]?.name || value} - {data[index]?.value || 0}
                </span>
              )}
            />
          )}
        </RechartsPieChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}