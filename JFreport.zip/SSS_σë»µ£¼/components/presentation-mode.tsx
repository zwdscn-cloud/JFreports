"use client"

import React, { useState, useEffect, useCallback, useRef } from 'react'
import { ChartElement } from '@/components/chart-element'
import { Button } from '@/components/ui/button'
import { X, Play, Pause, Square, RotateCcw } from 'lucide-react'

interface CanvasElement {
  id: string
  type: string
  x: number
  y: number
  width: number
  height: number
  title?: string
  content?: string
  headingLevel?: string
  level?: number
  zIndex?: number
  data?: any[] | { nodes: any[], links: any[] }
  tableData?: {
    headers: string[]
    rows: string[][]
  }
  textColor?: string
  backgroundColor?: string
  fontSize?: number
  fontWeight?: string
  textAlign?: string
  opacity?: number
  showLegend?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  animation?: boolean
  themeId?: string
  imageUrl?: string
  alt?: string
  videoUrl?: string
  autoplay?: boolean
  controls?: boolean
  muted?: boolean
  audioUrl?: string
  transparent?: boolean
  isPreviewing?: boolean
  positionLocked?: boolean
  visible?: boolean
}

interface PresentationModeProps {
  canvasElements: CanvasElement[]
  canvasSettings?: {
    width: number
    height: number
    backgroundColor: string
  }
  onClose: () => void
}

export function PresentationMode({ canvasElements, canvasSettings, onClose }: PresentationModeProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentCycle, setCurrentCycle] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const animationTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const cycleTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const presentationElementsRef = useRef<CanvasElement[]>([])

  // 更新画布元素引用
  useEffect(() => {
    presentationElementsRef.current = canvasElements
  }, [canvasElements])

  // 开始自动播放循环
  const startAutoPlay = useCallback(() => {
    if (isPlaying) return

    setIsPlaying(true)
    setCurrentCycle(0)
    setIsAnimating(true)

    // 开始第一个循环
    startAnimationCycle()
  }, [isPlaying])

  // 停止自动播放
  const stopAutoPlay = useCallback(() => {
    console.log('演示模式：停止所有动画')
    
    setIsPlaying(false)
    setIsAnimating(false)
    setCurrentCycle(0)

    // 清理所有定时器
    if (animationTimeoutRef.current) {
      clearTimeout(animationTimeoutRef.current)
      animationTimeoutRef.current = null
    }
    if (cycleTimeoutRef.current) {
      clearTimeout(cycleTimeoutRef.current)
      cycleTimeoutRef.current = null
    }

    // 立即停止所有3D组件动画并恢复到初始状态
    stopAllAnimations()
    
    // 延迟一点时间确保所有动画都停止了
    setTimeout(() => {
      console.log('演示模式：所有动画已停止，恢复到初始状态')
    }, 100)
  }, [])

  // 暂停/恢复播放
  const togglePlayPause = useCallback(() => {
    if (isPlaying) {
      setIsPlaying(false)
      // 清理定时器但不重置状态
      if (animationTimeoutRef.current) {
        clearTimeout(animationTimeoutRef.current)
        animationTimeoutRef.current = null
      }
      if (cycleTimeoutRef.current) {
        clearTimeout(cycleTimeoutRef.current)
        cycleTimeoutRef.current = null
      }
    } else {
      setIsPlaying(true)
      // 继续当前循环
      startAnimationCycle()
    }
  }, [isPlaying])

  // 开始动画循环
  const startAnimationCycle = useCallback(() => {
    if (!isPlaying) return

    // 触发所有3D组件的视角切换动画
    triggerViewAnimations()

    // 等待视角动画循环播放一段时间后，触发爆炸动画
    animationTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        triggerExplodeAnimations()
        
        // 等待爆炸动画完成后，恢复模型并开始下一个循环
        cycleTimeoutRef.current = setTimeout(() => {
          if (isPlaying) {
            restoreAllModels()
            
            // 等待恢复完成后，开始下一个循环
            setTimeout(() => {
              if (isPlaying) {
                setCurrentCycle(prev => prev + 1)
                startAnimationCycle()
              }
            }, 2000) // 2秒间隔，给用户更多时间观看
          }
        }, 3000) // 爆炸动画持续3秒
      }
    }, 15000) // 视角动画循环播放15秒，让用户充分观看各个视角
  }, [isPlaying])

  // 触发所有3D组件的视角切换动画
  const triggerViewAnimations = useCallback(() => {
    const elements = presentationElementsRef.current
    console.log('演示模式：触发视角动画，找到3D组件数量:', elements.filter(el => el.type === '3d-model').length)
    
    elements.forEach(element => {
      if (element.type === '3d-model' && element.data) {
        console.log('演示模式：发送视角动画事件给组件', element.id)
        // 通过DOM事件来通知3D组件开始视角动画
        window.dispatchEvent(new CustomEvent('presentation-view-animation', {
          detail: { 
            elementId: element.id,
            viewAnimationEnabled: true
          }
        }))
      }
    })
  }, [])

  // 触发所有3D组件的爆炸动画
  const triggerExplodeAnimations = useCallback(() => {
    const elements = presentationElementsRef.current
    elements.forEach(element => {
      if (element.type === '3d-model' && element.data) {
        window.dispatchEvent(new CustomEvent('presentation-explode-animation', {
          detail: { elementId: element.id }
        }))
      }
    })
  }, [])

  // 恢复所有模型
  const restoreAllModels = useCallback(() => {
    const elements = presentationElementsRef.current
    elements.forEach(element => {
      if (element.type === '3d-model' && element.data) {
        window.dispatchEvent(new CustomEvent('presentation-restore-model', {
          detail: { elementId: element.id }
        }))
      }
    })
  }, [])

  // 停止所有动画
  const stopAllAnimations = useCallback(() => {
    const elements = presentationElementsRef.current
    console.log('演示模式：停止所有3D组件动画，组件数量:', elements.filter(el => el.type === '3d-model').length)
    
    elements.forEach(element => {
      if (element.type === '3d-model' && element.data) {
        console.log('演示模式：停止组件动画', element.id)
        window.dispatchEvent(new CustomEvent('presentation-stop-animation', {
          detail: { elementId: element.id }
        }))
      }
    })
  }, [])

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      if (animationTimeoutRef.current) {
        clearTimeout(animationTimeoutRef.current)
      }
      if (cycleTimeoutRef.current) {
        clearTimeout(cycleTimeoutRef.current)
      }
    }
  }, [])

  // 键盘快捷键
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'Escape':
          onClose()
          break
        case ' ':
          e.preventDefault()
          togglePlayPause()
          break
        case 's':
          if (e.ctrlKey || e.metaKey) {
            e.preventDefault()
            stopAutoPlay()
          }
          break
      }
    }

    document.addEventListener('keydown', handleKeyPress)
    return () => document.removeEventListener('keydown', handleKeyPress)
  }, [onClose, togglePlayPause, stopAutoPlay])

  // 自动开始播放
  useEffect(() => {
    // 延迟1秒后自动开始播放
    const autoStartTimer = setTimeout(() => {
      startAutoPlay()
    }, 1000)

    return () => clearTimeout(autoStartTimer)
  }, [startAutoPlay])

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* 全屏画布 */}
      <div 
        className="w-full h-full relative overflow-hidden"
        style={{
          backgroundColor: canvasSettings?.backgroundColor || "#000000"
        }}
      >
        {/* 画布内容 */}
        <div 
          className="relative w-full h-full"
          style={{
            minHeight: canvasSettings?.height || 2000,
            minWidth: canvasSettings?.width || 2000,
            transform: 'scale(1)',
            transformOrigin: 'center center'
          }}
        >
          {canvasElements
            .filter(element => element.visible !== false)
            .map((element) => (
              <ChartElement
                key={element.id}
                element={element}
                isSelected={false}
                isMultiSelected={false}
                onSelect={() => {}}
                onUpdate={() => {}}
                onDelete={() => {}}
                onCopy={() => {}}
                onElementReorder={() => {}}
                canvasElements={canvasElements}
                isViewMode={true}
                isPresentationMode={true}
                canvasBackgroundColor={canvasSettings?.backgroundColor || "#000000"}
              />
            ))}
        </div>

        {/* 控制面板 */}
        <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 backdrop-blur-sm rounded-lg p-2">
          {/* 播放控制 */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={togglePlayPause}
              className="text-white hover:bg-white/20"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={stopAutoPlay}
              className="text-white hover:bg-white/20"
            >
              <Square className="w-4 h-4" />
            </Button>
          </div>

          {/* 分隔线 */}
          <div className="w-px h-6 bg-white/30" />

          {/* 循环计数 */}
          <div className="text-white text-sm">
            循环: {currentCycle}
          </div>

          {/* 分隔线 */}
          <div className="w-px h-6 bg-white/30" />

          {/* 关闭按钮 */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-white hover:bg-white/20"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* 状态指示器 */}
        {isAnimating && (
          <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg p-3">
            <div className="flex items-center gap-2 text-white">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm">
                {isPlaying ? '自动播放中...' : '已暂停'}
              </span>
            </div>
          </div>
        )}

        {/* 快捷键提示 */}
        <div className="absolute bottom-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-3 text-white text-xs">
          <div className="space-y-1">
            <div>空格键: 播放/暂停</div>
            <div>ESC: 退出</div>
            <div>Ctrl+S: 停止</div>
          </div>
        </div>
      </div>
    </div>
  )
}
