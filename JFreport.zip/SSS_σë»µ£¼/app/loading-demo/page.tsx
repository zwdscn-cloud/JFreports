'use client';

import React, { useState } from 'react';
import { LoadingScreen, useLoadingSimulation } from '@/components/loading-screen';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function LoadingDemo() {
  const [showDemo, setShowDemo] = useState(false);
  const { isLoading, progress } = useLoadingSimulation(4000); // 4秒加载时间

  const handleStartDemo = () => {
    setShowDemo(true);
    // 重置加载状态
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            加载动画演示
          </h1>
          <p className="text-lg text-gray-600">
            体验模糊到清晰的加载过渡效果
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>功能特性</CardTitle>
            <CardDescription>
              这个加载动画包含以下特性：
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm">
              <li>• <strong>模糊到清晰过渡</strong>：页面从模糊状态逐渐变清晰</li>
              <li>• <strong>进度条显示</strong>：实时显示加载进度百分比</li>
              <li>• <strong>旋转加载图标</strong>：视觉反馈的旋转动画</li>
              <li>• <strong>步骤指示器</strong>：显示加载的不同阶段</li>
              <li>• <strong>平滑过渡</strong>：使用 Framer Motion 实现流畅动画</li>
            </ul>
          </CardContent>
        </Card>

        <div className="text-center">
          <Button 
            onClick={handleStartDemo}
            size="lg"
            className="bg-blue-600 hover:bg-blue-700"
          >
            开始演示加载动画
          </Button>
        </div>

        {showDemo && (
          <LoadingScreen isLoading={isLoading} progress={progress}>
            <div className="mt-8">
              <Card>
                <CardHeader>
                  <CardTitle>主要内容区域</CardTitle>
                  <CardDescription>
                    这是被加载动画覆盖的主要内容。在加载过程中，这个区域会显示为模糊状态。
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-white rounded-lg shadow">
                      <h3 className="font-semibold mb-2">功能模块 1</h3>
                      <p className="text-sm text-gray-600">
                        这里可以放置各种功能模块，在加载时会被模糊处理。
                      </p>
                    </div>
                    <div className="p-4 bg-white rounded-lg shadow">
                      <h3 className="font-semibold mb-2">功能模块 2</h3>
                      <p className="text-sm text-gray-600">
                        加载完成后，所有内容都会变得清晰可见。
                      </p>
                    </div>
                    <div className="p-4 bg-white rounded-lg shadow">
                      <h3 className="font-semibold mb-2">功能模块 3</h3>
                      <p className="text-sm text-gray-600">
                        用户体验流畅，视觉效果专业。
                      </p>
                    </div>
                    <div className="p-4 bg-white rounded-lg shadow">
                      <h3 className="font-semibold mb-2">功能模块 4</h3>
                      <p className="text-sm text-gray-600">
                        支持自定义加载时间和进度显示。
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </LoadingScreen>
        )}
      </div>
    </div>
  );
}
