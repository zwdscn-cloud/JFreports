"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"

interface NumberInputProps {
  id?: string
  value: number
  onChange: (value: number) => void
  className?: string
  min?: number
  max?: number
  placeholder?: string
}

export function NumberInput({ 
  id, 
  value, 
  onChange, 
  className, 
  min, 
  max, 
  placeholder 
}: NumberInputProps) {
  const [localValue, setLocalValue] = useState(value.toString())

  // 当外部值变化时，更新本地值
  useEffect(() => {
    setLocalValue(value.toString())
  }, [value])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const numValue = Number.parseInt(localValue)
      if (!isNaN(numValue)) {
        // 检查范围限制
        let finalValue = numValue
        if (min !== undefined && numValue < min) finalValue = min
        if (max !== undefined && numValue > max) finalValue = max
        
        onChange(finalValue)
        setLocalValue(finalValue.toString())
      } else {
        // 如果输入无效，恢复到原值
        setLocalValue(value.toString())
      }
    }
  }

  const handleBlur = () => {
    const numValue = Number.parseInt(localValue)
    if (!isNaN(numValue)) {
      // 检查范围限制
      let finalValue = numValue
      if (min !== undefined && numValue < min) finalValue = min
      if (max !== undefined && numValue > max) finalValue = max
      
      onChange(finalValue)
      setLocalValue(finalValue.toString())
    } else {
      // 如果输入无效，恢复到原值
      setLocalValue(value.toString())
    }
  }

  return (
    <Input
      id={id}
      type="number"
      value={localValue}
      onChange={(e) => setLocalValue(e.target.value)}
      onKeyDown={handleKeyDown}
      onBlur={handleBlur}
      className={className}
      min={min}
      max={max}
      placeholder={placeholder}
    />
  )
}
