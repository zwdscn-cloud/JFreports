"use client"

import { useState, useCallback } from "react"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { useSound } from "@/hooks/use-sound"

interface FunnelChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  showLegend?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  scale?: number // 缩放比例，默认为1
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

export function FunnelChart({
  data,
  title,
  showLegend = true,
  showTooltip = true,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  scale = 1,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: FunnelChartProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)
  const { playHover } = useSound()



  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 计算缩放后的尺寸
  const scaledHeight = 50 * scale // 基础高度50px
  const scaledFontSize = 13 * scale // 基础字体13px
  const scaledTitleFontSize = 14 * scale // 标题字体14px
  const scaledLegendFontSize = 12 * scale // 图例字体12px
  const scaledMargin = 6 * scale // 基础间距6px

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            fontSize: `${titleFontSize || scaledTitleFontSize}px`,
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333")
          }}
        >
          {title}
        </div>
      )}
      
      <div className="flex flex-col items-center justify-center w-full h-full relative">
        {data.map((item, index) => {
          // 计算漏斗形状的宽度 - 使用更自然的递减曲线
          const maxWidth = 85 // 最大宽度85%
          const minWidth = 25 // 最小宽度25%
          const progress = index / (data.length - 1)
          const width = maxWidth - (progress * progress * (maxWidth - minWidth))
          
          // 计算高度 - 使用更合理的比例
          const baseHeight = 70 * scale
          const segmentHeight = Math.max(35 * scale, baseHeight - (index * 8 * scale))
          
          // 计算下一段的宽度，用于创建更自然的过渡
          const nextWidth = index < data.length - 1 
            ? maxWidth - (((index + 1) / (data.length - 1)) * ((index + 1) / (data.length - 1)) * (maxWidth - minWidth))
            : minWidth
          
          // 计算所有数值标签的固定X轴位置（红色框子区域）
          const fixedValueX = 100 - 8 // 所有数值标签的固定X轴位置
          
          return (
            <div
              key={item.name}
              className="relative flex items-center justify-center"
              style={{ 
                width: `${width}%`,
                height: `${segmentHeight}px`,
                marginBottom: index === data.length - 1 ? 0 : `${scaledMargin}px`
              }}
              onMouseEnter={() => setHoveredIndex(index)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* 漏斗段 - 使用SVG创建更美观的梯形 */}
              <svg
                width="100%"
                height="100%"
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                className="absolute inset-0"
              >
                <defs>
                  {/* 扁平化纯色填充 */}
                </defs>
                
                {/* 漏斗段路径 - 扁平化设计 */}
                <path
                  d={`
                    M ${(100 - width) / 2},5 
                    L ${(100 + width) / 2},5 
                    L ${(100 + nextWidth) / 2},95 
                    L ${(100 - nextWidth) / 2},95 
                    Z
                  `}
                  fill={colors[index % colors.length]}
                  stroke={colors[index % colors.length]}
                  strokeWidth="1"
                  opacity={hoveredIndex === index ? 0.8 : 1}
                  className="transition-opacity duration-300 ease-in-out"
                />
              </svg>

              {/* 文字在正中间，数值在中间往右8px */}
              <div className="relative z-10 flex items-center justify-center w-full h-full">
                {/* 文字在正中间 */}
                <span 
                  className="font-semibold text-center px-3 py-1"
                  style={{ 
                    fontSize: `${chartFontSize || scaledFontSize}px`,
                    color: chartTextColor || "#ffffff",
                    textShadow: "2px 2px 4px rgba(0,0,0,0.7)",
                    fontWeight: "600"
                  }}
                >
                  {item.name}
                </span>
                
                {/* 数值在中间往右40% + 30px */}
                <div 
                  className="absolute"
                  style={{ 
                    left: 'calc(50% + 40% + 30px)',
                    top: '50%',
                    transform: 'translateY(-50%)'
                  }}
                >
                  <div 
                    className="text-xs font-semibold"
                    style={{ 
                      fontSize: `${scaledFontSize * 0.8}px`,
                      color: colors[index % colors.length],
                      fontWeight: "600",
                      textAlign: 'center'
                    }}
                  >
                    {item.value}
                  </div>
                </div>
              </div>
            </div>
          )
        })}

      </div>
    </div>
  )
}