"use client"

import React, { useCallback, useRef, useEffect, useState } from 'react'
import { useOptimizedCanvas } from '@/hooks/use-optimized-canvas'

interface OptimizedCanvasProps {
  children: React.ReactNode
  className?: string
  style?: React.CSSProperties
  onZoomChange?: (zoom: number) => void
  onOffsetChange?: (offset: { x: number; y: number }) => void
  initialZoom?: number
  initialOffset?: { x: number; y: number }
}

export function OptimizedCanvas({
  children,
  className = '',
  style = {},
  onZoomChange,
  onOffsetChange,
  initialZoom = 100,
  initialOffset = { x: 0, y: 0 }
}: OptimizedCanvasProps) {
  const {
    zoom,
    offset,
    isPanning,
    canvasRef,
    getCanvasCoordinates,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleWheel
  } = useOptimizedCanvas({
    initialZoom,
    initialOffset,
    onZoomChange,
    onOffsetChange
  })

  // 优化的样式计算
  const canvasStyle = {
    ...style,
    transform: `scale(${zoom / 100}) translate(${offset.x / (zoom / 100)}px, ${offset.y / (zoom / 100)}px)`,
    transformOrigin: '0 0',
    cursor: isPanning ? 'grabbing' : 'grab',
    transition: isPanning ? 'none' : 'transform 0.1s ease-out'
  }

  return (
    <div
      ref={canvasRef}
      className={`relative ${className}`}
      style={canvasStyle}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onWheel={handleWheel}
    >
      {children}
    </div>
  )
}

// 高性能的缩放控制器
export function OptimizedZoomControls({
  zoom,
  onZoomIn,
  onZoomOut,
  onReset,
  className = ''
}: {
  zoom: number
  onZoomIn: () => void
  onZoomOut: () => void
  onReset: () => void
  className?: string
}) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <button
        onClick={onZoomOut}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded transition-colors"
        title="缩小"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
        </svg>
      </button>
      
      <span className="text-sm min-w-12 text-center font-mono">
        {Math.round(zoom)}%
      </span>
      
      <button
        onClick={onZoomIn}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded transition-colors"
        title="放大"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
      </button>
      
      <button
        onClick={onReset}
        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded transition-colors"
        title="重置缩放"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
      </button>
    </div>
  )
}
