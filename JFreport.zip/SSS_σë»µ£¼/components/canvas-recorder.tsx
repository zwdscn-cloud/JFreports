'use client';

import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Video, Play, Square, Download, Settings, Monitor, Camera } from 'lucide-react';
// RecordRTC 将在客户端动态导入

interface CanvasRecorderProps {
  canvasRef: React.RefObject<HTMLDivElement>;
  isOpen: boolean;
  onClose: () => void;
  canvasWidth?: number;
  canvasHeight?: number;
  onRecordingStateChange?: (isRecording: boolean) => void;
}

export function CanvasRecorder({ 
  canvasRef, 
  isOpen, 
  onClose, 
  canvasWidth = 1920, 
  canvasHeight = 1080,
  onRecordingStateChange
}: CanvasRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [recordingOptions, setRecordingOptions] = useState({
    width: canvasWidth,
    height: canvasHeight,
    frameRate: 30,
    quality: 'high' as 'low' | 'medium' | 'high',
    format: 'mp4' as 'webm' | 'mp4',
    resolution: '1x' as '0.5x' | '1x' | '1.5x' | '2x' | '4k'
  });

  // 当画布尺寸变化时，更新录制选项
  useEffect(() => {
    setRecordingOptions(prev => ({
      ...prev,
      width: canvasWidth,
      height: canvasHeight
    }));
  }, [canvasWidth, canvasHeight]);

  // 计算实际录制分辨率
  const getRecordingResolution = useCallback((baseWidth: number, baseHeight: number, resolution: string) => {
    const resolutionMap = {
      '0.5x': 0.5,
      '1x': 1,
      '1.5x': 1.5,
      '2x': 2,
      '4k': 4
    };
    
    const scale = resolutionMap[resolution as keyof typeof resolutionMap] || 1;
    
    // 对于4K，使用固定的4K分辨率
    if (resolution === '4k') {
      return { width: 3840, height: 2160 };
    }
    
    return {
      width: Math.round(baseWidth * scale),
      height: Math.round(baseHeight * scale)
    };
  }, []);
  
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  // 清理资源
  const cleanup = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (recorderRef.current) {
      // MediaRecorder 不需要 destroy 方法，只需要停止即可
      if ('stop' in recorderRef.current && recorderRef.current.state !== 'inactive') {
        (recorderRef.current as MediaRecorder).stop();
      }
      recorderRef.current = null;
    }
  }, []);

  // 组件卸载时清理
  useEffect(() => {
    return cleanup;
  }, [cleanup]);

  // 开始录屏
  const startRecording = useCallback(async () => {
    try {
      setIsProcessing(true);
      setProgress(0);

      // 获取画布元素
      const canvasElement = canvasRef.current;
      if (!canvasElement) {
        throw new Error('画布元素未找到');
      }

      console.log('画布元素信息:', {
        element: canvasElement,
        tagName: canvasElement.tagName,
        className: canvasElement.className,
        clientWidth: canvasElement.clientWidth,
        clientHeight: canvasElement.clientHeight,
        children: canvasElement.children.length,
        canvasElements: canvasElement.querySelectorAll('canvas').length,
        innerHTML: canvasElement.innerHTML.substring(0, 500) + '...'
      });
      
      // 详细检查所有子元素
      console.log('画布子元素详情:');
      for (let i = 0; i < canvasElement.children.length; i++) {
        const child = canvasElement.children[i];
        console.log(`子元素 ${i}:`, {
          tagName: child.tagName,
          className: child.className,
          id: child.id,
          children: child.children.length,
          canvasCount: child.querySelectorAll('canvas').length
        });
      }
      
      // 检查是否有Three.js Canvas
      const allCanvases = canvasElement.querySelectorAll('canvas');
      console.log(`总共找到 ${allCanvases.length} 个Canvas元素`);
      
      allCanvases.forEach((canvas, index) => {
        console.log(`Canvas ${index}:`, {
          width: canvas.width,
          height: canvas.height,
          clientWidth: canvas.clientWidth,
          clientHeight: canvas.clientHeight,
          parentElement: canvas.parentElement?.tagName,
          parentClassName: canvas.parentElement?.className
        });
      });

      // 检查浏览器环境
      if (typeof window === 'undefined') {
        throw new Error('录屏功能需要在浏览器环境中运行');
      }

      // 使用 Canvas 录制方式，直接录制画布内容
      console.log('使用 Canvas 录制方式...');
      
      // 检查浏览器支持 MediaRecorder
      if (!window.MediaRecorder) {
        throw new Error('您的浏览器不支持 MediaRecorder API，请使用Chrome、Firefox或Edge浏览器');
      }

      // 获取画布的实际尺寸
      const actualWidth = canvasElement.clientWidth || canvasWidth;
      const actualHeight = canvasElement.clientHeight || canvasHeight;
      
      // 计算录制分辨率
      const recordingResolution = getRecordingResolution(actualWidth, actualHeight, recordingOptions.resolution);
      
      console.log('画布实际尺寸:', {
        clientWidth: canvasElement.clientWidth,
        clientHeight: canvasElement.clientHeight,
        canvasWidth: canvasWidth,
        canvasHeight: canvasHeight,
        actualWidth: actualWidth,
        actualHeight: actualHeight,
        recordingResolution: recordingResolution,
        resolutionScale: recordingOptions.resolution
      });

      // 创建离屏 Canvas 用于录制，使用计算出的录制分辨率
      const offscreenCanvas = document.createElement('canvas');
      offscreenCanvas.width = recordingResolution.width;
      offscreenCanvas.height = recordingResolution.height;
      const ctx = offscreenCanvas.getContext('2d');
      
      if (!ctx) {
        throw new Error('无法创建 Canvas 上下文');
      }

      console.log('离屏 Canvas 创建成功:', offscreenCanvas);

      // 创建 MediaStream 用于录制
      const stream = offscreenCanvas.captureStream(recordingOptions.frameRate);
      console.log('Canvas 流创建成功:', stream);

      // 创建录制器，优先使用MP4格式
      let mimeType = 'video/webm'; // 默认格式
      
      // 检查浏览器支持的格式
      if (recordingOptions.format === 'mp4') {
        if (MediaRecorder.isTypeSupported('video/mp4; codecs=h264')) {
          mimeType = 'video/mp4; codecs=h264';
        } else if (MediaRecorder.isTypeSupported('video/mp4')) {
          mimeType = 'video/mp4';
        } else {
          console.warn('浏览器不支持MP4格式，使用WebM格式');
          mimeType = 'video/webm';
        }
      } else {
        mimeType = 'video/webm';
      }
      
      console.log('使用录制格式:', mimeType);
      
      // 根据分辨率和质量计算比特率
      const getBitrate = (quality: string, resolution: string, width: number, height: number) => {
        const baseBitrate = quality === 'high' ? 2500000 : 
                           quality === 'medium' ? 1500000 : 1000000;
        
        // 根据分辨率调整比特率
        const pixelCount = width * height;
        const basePixelCount = 1920 * 1080; // 1080p基准
        const resolutionMultiplier = pixelCount / basePixelCount;
        
        return Math.round(baseBitrate * resolutionMultiplier);
      };
      
      const bitrate = getBitrate(recordingOptions.quality, recordingOptions.resolution, recordingResolution.width, recordingResolution.height);
      
      console.log('录制设置:', {
        resolution: recordingResolution,
        quality: recordingOptions.quality,
        bitrate: bitrate,
        mimeType: mimeType
      });
      
      const recorder = new MediaRecorder(stream, {
        mimeType: mimeType,
        videoBitsPerSecond: bitrate
      });

      console.log('MediaRecorder 实例创建成功:', recorder);

      // 存储录制数据
      const recordedChunks: Blob[] = [];
      
      recorder.ondataavailable = (event) => {
        console.log('收到录制数据:', event.data.size, 'bytes');
        if (event.data.size > 0) {
          recordedChunks.push(event.data);
          console.log('当前录制块数量:', recordedChunks.length);
        }
      };

      recorder.onstop = () => {
        console.log('录制停止，处理数据...');
        console.log('录制块总数:', recordedChunks.length);
        console.log('录制块大小:', recordedChunks.map(chunk => chunk.size));
        
        if (recordedChunks.length === 0) {
          console.error('没有录制到任何数据！');
          alert('录制失败：没有录制到任何数据。请检查画布内容是否正确显示。');
          return;
        }
        
        // 根据实际使用的MIME类型确定文件类型
        const actualMimeType = recordedChunks[0].type;
        const fileExtension = actualMimeType.includes('mp4') ? 'mp4' : 'webm';
        
        const blob = new Blob(recordedChunks, { 
          type: actualMimeType
        });
        
        console.log('生成的视频文件:', {
          size: blob.size,
          type: blob.type,
          fileExtension: fileExtension,
          chunks: recordedChunks.length
        });
        
        if (blob.size === 0) {
          console.error('生成的视频文件大小为0！');
          alert('录制失败：生成的视频文件为空。');
          return;
        }
        
        setRecordedBlob(blob);
        
        // 自动下载视频
        try {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `3d-canvas-recording-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.${fileExtension}`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          console.log(`视频下载完成: ${fileExtension} 格式`);
        } catch (error) {
          console.error('下载视频失败:', error);
          alert('录制完成，但下载失败。请手动保存视频文件。');
        }
      };

      streamRef.current = stream;
      recorderRef.current = recorder;

      // 开始录制
      console.log('开始录制，MediaRecorder 状态:', recorder.state);
      recorder.start(1000); // 每秒收集一次数据
      console.log('录制启动后状态:', recorder.state);
      
      setIsRecording(true);
      setIsProcessing(false);
      setRecordingTime(0);
      startTimeRef.current = Date.now();
      
      console.log('录制已启动，开始捕获画布内容...');
      
      // 通知父组件录屏状态变化
      onRecordingStateChange?.(true);
      
      // 自动关闭录屏对话框
      onClose();

      // 开始计时和画布捕获
      timerRef.current = setInterval(() => {
        setRecordingTime(Math.floor((Date.now() - startTimeRef.current) / 1000));
        
        // 捕获画布内容
        if (canvasElement && ctx) {
          try {
            // 清空离屏Canvas
            ctx.clearRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
            
            // 设置白色背景
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
            
            // 查找所有Canvas元素
            const allCanvases = canvasElement.querySelectorAll('canvas');
            console.log(`录制帧 ${Math.floor((Date.now() - startTimeRef.current) / 1000)}s: 找到 ${allCanvases.length} 个Canvas元素`);
            
            if (allCanvases.length > 0) {
              // 按面积排序，优先捕获最大的Canvas
              const canvasesWithArea = Array.from(allCanvases).map(canvas => ({
                canvas,
                area: canvas.width * canvas.height,
                width: canvas.width,
                height: canvas.height
              })).filter(item => item.area > 0).sort((a, b) => b.area - a.area);
              
              console.log('Canvas元素信息:', canvasesWithArea.map(item => ({
                area: item.area,
                width: item.width,
                height: item.height
              })));
              
              if (canvasesWithArea.length > 0) {
                // 使用最大的Canvas作为主要内容
                const mainCanvas = canvasesWithArea[0].canvas;
                
                // 计算缩放比例以适应离屏Canvas
                const scaleX = offscreenCanvas.width / mainCanvas.width;
                const scaleY = offscreenCanvas.height / mainCanvas.height;
                const scale = Math.min(scaleX, scaleY);
                
                const scaledWidth = mainCanvas.width * scale;
                const scaledHeight = mainCanvas.height * scale;
                const offsetX = (offscreenCanvas.width - scaledWidth) / 2;
                const offsetY = (offscreenCanvas.height - scaledHeight) / 2;
                
                // 绘制主Canvas，使用高分辨率
                ctx.imageSmoothingEnabled = true;
                ctx.imageSmoothingQuality = 'high';
                ctx.drawImage(mainCanvas, offsetX, offsetY, scaledWidth, scaledHeight);
                
                // 如果有其他Canvas，也尝试绘制（作为叠加层）
                for (let i = 1; i < Math.min(canvasesWithArea.length, 3); i++) {
                  const overlayCanvas = canvasesWithArea[i].canvas;
                  if (overlayCanvas.width > 0 && overlayCanvas.height > 0) {
                    const overlayScaleX = offscreenCanvas.width / overlayCanvas.width;
                    const overlayScaleY = offscreenCanvas.height / overlayCanvas.height;
                    const overlayScale = Math.min(overlayScaleX, overlayScaleY);
                    
                    const overlayScaledWidth = overlayCanvas.width * overlayScale;
                    const overlayScaledHeight = overlayCanvas.height * overlayScale;
                    const overlayOffsetX = (offscreenCanvas.width - overlayScaledWidth) / 2;
                    const overlayOffsetY = (offscreenCanvas.height - overlayScaledHeight) / 2;
                    
                    ctx.drawImage(overlayCanvas, overlayOffsetX, overlayOffsetY, overlayScaledWidth, overlayScaledHeight);
                  }
                }
                
                // 每5秒输出一次成功日志
                if (Math.floor((Date.now() - startTimeRef.current) / 1000) % 5 === 0) {
                  console.log('Canvas内容捕获成功，主Canvas尺寸:', mainCanvas.width, 'x', mainCanvas.height);
                }
              } else {
                // 没有有效的Canvas，显示等待信息
                ctx.fillStyle = '#000000';
                ctx.font = '16px Arial';
                ctx.fillText('Waiting for Canvas content...', 20, 30);
                ctx.fillText(`Time: ${Math.floor((Date.now() - startTimeRef.current) / 1000)}s`, 20, 50);
                ctx.fillText('Found ' + allCanvases.length + ' canvas elements', 20, 70);
              }
            } else {
              // 没有找到Canvas，显示错误信息
              ctx.fillStyle = '#000000';
              ctx.font = '16px Arial';
              ctx.fillText('No Canvas elements found!', 20, 30);
              ctx.fillText(`Time: ${Math.floor((Date.now() - startTimeRef.current) / 1000)}s`, 20, 50);
              ctx.fillText('Please add components to canvas', 20, 70);
              
              console.warn('未找到Canvas元素，请确保画布上有组件');
            }
            
          } catch (error) {
            console.error('Canvas捕获失败:', error);
            
            // 显示错误状态
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
            ctx.fillStyle = '#ff0000';
            ctx.font = '16px Arial';
            ctx.fillText('Capture Error!', 20, 30);
            ctx.fillText(`Time: ${Math.floor((Date.now() - startTimeRef.current) / 1000)}s`, 20, 50);
            ctx.fillText('Error: ' + (error as Error).message, 20, 70);
          }
        } else {
          console.warn('画布元素或上下文不可用');
        }
      }, 1000 / recordingOptions.frameRate); // 根据帧率设置捕获间隔

    } catch (error) {
      console.error('录屏启动失败:', error);
      console.error('错误详情:', {
        error: error,
        errorType: typeof error,
        errorString: String(error),
        message: (error as Error)?.message,
        stack: (error as Error)?.stack,
        canvasElement: canvasRef.current,
        recordingOptions
      });
      setIsProcessing(false);
      const errorMessage = (error as Error)?.message || String(error) || '未知错误';
      alert('录屏启动失败: ' + errorMessage);
    }
  }, [canvasRef, recordingOptions, cleanup]);

  // 停止录屏
  const stopRecording = useCallback(() => {
    if (!recorderRef.current || !isRecording) return;

    console.log('停止录屏...');
    setIsRecording(false);
    setIsProcessing(true);
    setProgress(50);
    
    // 通知父组件录屏状态变化
    onRecordingStateChange?.(false);

    // 停止 MediaRecorder
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      recorderRef.current.stop();
    }

    // 清理定时器
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    setProgress(100);
    setIsProcessing(false);
    cleanup();
  }, [isRecording, cleanup]);

  // 格式化时间
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <>
      {/* 浮动录屏控制按钮 */}
      {isRecording && (
        <div className="fixed top-4 right-4 z-50 bg-red-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-3">
          <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
          <span className="text-sm font-medium">正在录屏: {formatTime(recordingTime)}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={stopRecording}
            className="text-white hover:bg-red-600 h-6 px-2"
          >
            <Square className="w-3 h-3 mr-1" />
            停止
          </Button>
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Monitor className="w-5 h-5 text-blue-600" />
              画布录屏
            </DialogTitle>
            <DialogDescription>
              录制画布上的所有组件内容（包括3D组件、图表组件等）并导出为视频文件
            </DialogDescription>
          </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* 录制设置 */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">录制设置</Label>
            
            <div className="space-y-3">
              <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-700">
                <div className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400">
                  <Monitor className="w-4 h-4" />
                  <span>录制分辨率: {getRecordingResolution(recordingOptions.width, recordingOptions.height, recordingOptions.resolution).width} × {getRecordingResolution(recordingOptions.width, recordingOptions.height, recordingOptions.resolution).height}</span>
                </div>
                <div className="text-xs text-blue-500 dark:text-blue-300 mt-1">
                  基础尺寸: {recordingOptions.width} × {recordingOptions.height} | 缩放: {recordingOptions.resolution}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-xs">帧率</Label>
                <Select
                  value={recordingOptions.frameRate.toString()}
                  onValueChange={(value) => {
                    setRecordingOptions(prev => ({ ...prev, frameRate: parseInt(value) }));
                  }}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="60">60 FPS</SelectItem>
                    <SelectItem value="30">30 FPS</SelectItem>
                    <SelectItem value="24">24 FPS</SelectItem>
                    <SelectItem value="15">15 FPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs">分辨率</Label>
                <Select
                  value={recordingOptions.resolution}
                  onValueChange={(value) => {
                    setRecordingOptions(prev => ({ ...prev, resolution: value as any }));
                  }}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0.5x">0.5x (低质量)</SelectItem>
                    <SelectItem value="1x">1x (标准)</SelectItem>
                    <SelectItem value="1.5x">1.5x (高质量)</SelectItem>
                    <SelectItem value="2x">2x (超高清)</SelectItem>
                    <SelectItem value="4k">4K (3840×2160)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-xs">质量</Label>
                <Select
                  value={recordingOptions.quality}
                  onValueChange={(value: 'low' | 'medium' | 'high') => {
                    setRecordingOptions(prev => ({ ...prev, quality: value }));
                  }}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">高质量</SelectItem>
                    <SelectItem value="medium">中等质量</SelectItem>
                    <SelectItem value="low">低质量</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label className="text-xs">格式</Label>
                <Select
                  value={recordingOptions.format}
                  onValueChange={(value: 'webm' | 'mp4') => {
                    setRecordingOptions(prev => ({ ...prev, format: value }));
                  }}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="webm">WebM</SelectItem>
                    <SelectItem value="mp4">MP4</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* 录制状态 */}
          {isRecording && (
            <div className="space-y-2 p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-700">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-red-600 dark:text-red-400">
                  正在录制: {formatTime(recordingTime)}
                </span>
              </div>
              <p className="text-xs text-red-600 dark:text-red-400">
                点击停止按钮或关闭共享窗口来结束录制
              </p>
            </div>
          )}

          {/* 处理进度 */}
          {isProcessing && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>处理中...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>
        
        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={onClose} disabled={isRecording || isProcessing}>
            取消
          </Button>
          
          {!isRecording && !isProcessing && (
            <Button onClick={startRecording} className="bg-red-600 hover:bg-red-700">
              <Camera className="w-4 h-4 mr-2" />
              开始录屏
            </Button>
          )}
          
          {isRecording && (
            <div className="flex items-center gap-2 text-sm text-red-600 dark:text-red-400">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span>录屏中... 使用右上角按钮停止</span>
            </div>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
    </>
  );
}
