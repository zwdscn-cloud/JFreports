"use client"

import React, { useState, useRef, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Monitor, Square, Maximize2 } from 'lucide-react'

interface ScreenRecordingSelectorProps {
  isOpen: boolean
  onClose: () => void
  onSelectArea: (area: { x: number, y: number, width: number, height: number }) => void
  onSelectFullScreen: () => void
}

export function ScreenRecordingSelector({ 
  isOpen, 
  onClose, 
  onSelectArea, 
  onSelectFullScreen 
}: ScreenRecordingSelectorProps) {
  const [isSelecting, setIsSelecting] = useState(false)
  const [selection, setSelection] = useState<{ x: number, y: number, width: number, height: number } | null>(null)
  const [startPos, setStartPos] = useState<{ x: number, y: number } | null>(null)
  const [showOverlay, setShowOverlay] = useState(false)
  const overlayRef = useRef<HTMLDivElement>(null)

  // 重置选择状态
  const resetSelection = useCallback(() => {
    setSelection(null)
    setStartPos(null)
    setIsSelecting(false)
  }, [])

  // 关闭对话框时重置
  useEffect(() => {
    if (!isOpen) {
      resetSelection()
    }
  }, [isOpen, resetSelection])

  // 开始选择区域
  const handleStartSelection = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    // 关闭对话框并显示覆盖层
    setShowOverlay(true)
    setIsSelecting(true)
    setStartPos({ x: e.clientX, y: e.clientY })
    setSelection({ x: e.clientX, y: e.clientY, width: 0, height: 0 })
  }, [])

  // 更新选择区域
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isSelecting || !startPos) return

    const currentX = e.clientX
    const currentY = e.clientY
    
    const x = Math.min(startPos.x, currentX)
    const y = Math.min(startPos.y, currentY)
    const width = Math.abs(currentX - startPos.x)
    const height = Math.abs(currentY - startPos.y)

    setSelection({ x, y, width, height })
  }, [isSelecting, startPos])

  // 结束选择
  const handleMouseUp = useCallback(() => {
    if (isSelecting) {
      setIsSelecting(false)
      // 如果选择了有效区域，自动确认
      if (selection && selection.width > 10 && selection.height > 10) {
        onSelectArea(selection)
        setShowOverlay(false)
        onClose()
      }
    }
  }, [isSelecting, selection, onSelectArea, onClose])

  // 添加全局鼠标事件监听
  useEffect(() => {
    if (isSelecting) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove)
        document.removeEventListener('mouseup', handleMouseUp)
      }
    }
  }, [isSelecting, handleMouseMove, handleMouseUp])

  // 确认选择区域
  const handleConfirmSelection = useCallback(() => {
    if (selection && selection.width > 10 && selection.height > 10) {
      onSelectArea(selection)
      setShowOverlay(false)
      onClose()
    }
  }, [selection, onSelectArea, onClose])

  // 选择整个屏幕
  const handleSelectFullScreen = useCallback(() => {
    setShowOverlay(false)
    onSelectFullScreen()
    onClose()
  }, [onSelectFullScreen, onClose])

  return (
    <>
      <Dialog open={isOpen && !showOverlay} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>选择录屏区域</DialogTitle>
            <DialogDescription>
              选择您要录制的屏幕区域，或者选择整个屏幕
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* 选择区域按钮 */}
            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start"
                onClick={handleStartSelection}
                disabled={isSelecting}
              >
                <Square className="w-4 h-4 mr-2" />
                选择特定区域
              </Button>
              
              <div className="text-sm text-muted-foreground p-2 bg-muted rounded">
                点击按钮后，请在屏幕上拖拽选择录屏区域
              </div>
            </div>

            {/* 选择整个屏幕按钮 */}
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={handleSelectFullScreen}
            >
              <Maximize2 className="w-4 h-4 mr-2" />
              选择整个屏幕
            </Button>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={onClose}>
              取消
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 选择区域覆盖层 */}
      {showOverlay && (
        <SelectionOverlay 
          selection={selection} 
          isSelecting={isSelecting}
          onCancel={() => {
            setShowOverlay(false)
            resetSelection()
          }}
        />
      )}
    </>
  )
}

// 选择区域覆盖层组件
interface SelectionOverlayProps {
  selection: { x: number, y: number, width: number, height: number } | null
  isSelecting: boolean
  onCancel: () => void
}

export function SelectionOverlay({ selection, isSelecting, onCancel }: SelectionOverlayProps) {
  // 处理ESC键取消选择
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onCancel()
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [onCancel])

  if (!selection || (!isSelecting && selection.width === 0 && selection.height === 0)) {
    return null
  }

  return (
    <div
      className="fixed inset-0 pointer-events-auto z-50"
      style={{
        background: 'rgba(0, 0, 0, 0.4)'
      }}
    >
      {/* 选择区域 */}
      <div
        className="absolute border-2 border-blue-500 bg-blue-500 bg-opacity-20"
        style={{
          left: selection.x,
          top: selection.y,
          width: selection.width,
          height: selection.height,
        }}
      >
        {/* 选择区域信息 */}
        {selection.width > 10 && selection.height > 10 && (
          <div className="absolute -top-8 left-0 bg-blue-500 text-white px-2 py-1 rounded text-sm whitespace-nowrap">
            {Math.round(selection.width)} × {Math.round(selection.height)} 像素
          </div>
        )}
      </div>

      {/* 提示信息 */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white px-4 py-2 rounded-lg">
        <div className="text-center">
          <div className="font-medium">选择录屏区域</div>
          <div className="text-sm text-gray-300 mt-1">
            拖拽鼠标选择区域，按ESC取消
          </div>
        </div>
      </div>

      {/* 取消按钮 */}
      <button
        onClick={onCancel}
        className="absolute top-4 right-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors"
      >
        取消
      </button>
    </div>
  )
}
