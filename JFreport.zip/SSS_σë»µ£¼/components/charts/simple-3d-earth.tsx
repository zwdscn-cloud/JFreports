"use client"

import React, { useRef, useEffect, useCallback, useState } from "react"
import { useSound } from "@/hooks/use-sound"

interface Simple3DEarthProps {
  data?: Array<{
    name: string
    longitude: number
    latitude: number
    height?: number
    value?: number
    color?: string
  }>
  title?: string
  showLegend?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  textColors?: {
    title?: string
    legend?: string
    tooltip?: string
  }
  titleFontSize?: number
  titleTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  width?: number
  height?: number
  onDataChange?: (data: any) => void
  isViewMode?: boolean
}

export function Simple3DEarth({
  data = [],
  title,
  showLegend = true,
  showTooltip = true,
  transparent = false,
  colors = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ef4444"],
  textColors,
  titleFontSize = 18,
  titleTextColor,
  legendFontSize = 12,
  legendTextColor,
  tooltipFontSize = 12,
  tooltipTextColor,
  width = 800,
  height = 600,
  onDataChange,
  isViewMode = false,
}: Simple3DEarthProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { playHover } = useSound()
  const [hoveredPoint, setHoveredPoint] = useState<any>(null)
  const [rotation, setRotation] = useState(0)

  // 处理鼠标进入
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  // 绘制3D地球
  const drawEarth = useCallback((ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(canvas.width, canvas.height) * 0.3

    // 清除画布
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // 绘制地球
    const gradient = ctx.createRadialGradient(centerX - radius * 0.3, centerY - radius * 0.3, 0, centerX, centerY, radius)
    gradient.addColorStop(0, '#4a90e2')
    gradient.addColorStop(0.7, '#2c5aa0')
    gradient.addColorStop(1, '#1a365d')

    ctx.save()
    ctx.translate(centerX, centerY)
    ctx.rotate(rotation)
    ctx.translate(-centerX, -centerY)

    // 绘制地球主体
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
    ctx.fillStyle = gradient
    ctx.fill()

    // 绘制地球轮廓
    ctx.strokeStyle = '#1a365d'
    ctx.lineWidth = 2
    ctx.stroke()

    // 绘制大陆轮廓（简化版）
    ctx.strokeStyle = '#2c5aa0'
    ctx.lineWidth = 1
    ctx.beginPath()
    
    // 绘制一些简化的大陆轮廓
    const continents = [
      // 北美洲
      { start: -0.8, end: -0.2, y: -0.3 },
      // 南美洲  
      { start: -0.7, end: -0.3, y: 0.2 },
      // 欧洲
      { start: -0.1, end: 0.3, y: -0.2 },
      // 非洲
      { start: -0.1, end: 0.3, y: 0.1 },
      // 亚洲
      { start: 0.2, end: 0.8, y: -0.1 },
      // 澳洲
      { start: 0.6, end: 0.9, y: 0.3 }
    ]

    continents.forEach(continent => {
      const startAngle = continent.start * Math.PI
      const endAngle = continent.end * Math.PI
      const y = continent.y * radius
      
      ctx.beginPath()
      ctx.arc(centerX, centerY + y, radius * 0.8, startAngle, endAngle)
      ctx.stroke()
    })

    ctx.restore()

    // 绘制数据点
    data.forEach((item, index) => {
      const color = item.color || colors[index % colors.length]
      
      // 将经纬度转换为画布坐标
      const x = centerX + (item.longitude / 180) * radius * 0.8
      const y = centerY - (item.latitude / 90) * radius * 0.8
      
      // 绘制数据点
      ctx.beginPath()
      ctx.arc(x, y, 8, 0, Math.PI * 2)
      ctx.fillStyle = color
      ctx.fill()
      ctx.strokeStyle = '#fff'
      ctx.lineWidth = 2
      ctx.stroke()

      // 绘制标签
      ctx.fillStyle = textColors?.title || (transparent ? "#fff" : "#333")
      ctx.font = `${legendFontSize}px Arial`
      ctx.textAlign = 'center'
      ctx.fillText(item.name, x, y - 15)
    })
  }, [data, colors, rotation, textColors, transparent, legendFontSize])

  // 处理鼠标移动
  const handleMouseMove = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !showTooltip) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    // 检查是否悬停在数据点上
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(canvas.width, canvas.height) * 0.3

    let foundPoint = null
    data.forEach((item) => {
      const pointX = centerX + (item.longitude / 180) * radius * 0.8
      const pointY = centerY - (item.latitude / 90) * radius * 0.8
      
      if (Math.sqrt((x - pointX) ** 2 + (y - pointY) ** 2) < 15) {
        foundPoint = item
      }
    })

    setHoveredPoint(foundPoint)
  }, [data, showTooltip])

  // 处理点击
  const handleClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const radius = Math.min(canvas.width, canvas.height) * 0.3

    data.forEach((item) => {
      const pointX = centerX + (item.longitude / 180) * radius * 0.8
      const pointY = centerY - (item.latitude / 90) * radius * 0.8
      
      if (Math.sqrt((x - pointX) ** 2 + (y - pointY) ** 2) < 15) {
        if (onDataChange) {
          onDataChange(item)
        }
      }
    })
  }, [data, onDataChange])

  // 动画循环
  useEffect(() => {
    const animate = () => {
      setRotation(prev => prev + 0.005)
      requestAnimationFrame(animate)
    }
    animate()
  }, [])

  // 绘制效果
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    drawEarth(ctx, canvas)
  }, [drawEarth])

  const containerClasses = `w-full h-full ${transparent ? "" : "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"} cursor-move`

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div
          className="font-medium mb-4"
          style={{
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333"),
            fontSize: `${titleFontSize}px`
          }}
        >
          {title}
        </div>
      )}
      
      <div className="relative w-full h-full">
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className="w-full h-full rounded-lg"
          onMouseMove={handleMouseMove}
          onClick={handleClick}
        />
        
        {showTooltip && hoveredPoint && (
          <div
            className="absolute top-4 right-4 bg-black/80 text-white p-3 rounded-lg shadow-lg z-10"
            style={{
              fontSize: `${tooltipFontSize}px`,
              color: tooltipTextColor || "#fff"
            }}
          >
            <div className="font-semibold">{hoveredPoint.name}</div>
            <div className="text-sm opacity-80">
              经度: {hoveredPoint.longitude.toFixed(2)}°
            </div>
            <div className="text-sm opacity-80">
              纬度: {hoveredPoint.latitude.toFixed(2)}°
            </div>
            {hoveredPoint.value && (
              <div className="text-sm opacity-80">
                数值: {hoveredPoint.value}
              </div>
            )}
          </div>
        )}

        {showLegend && data.length > 0 && (
          <div
            className="absolute bottom-4 left-4 bg-black/80 text-white p-3 rounded-lg shadow-lg"
            style={{
              fontSize: `${legendFontSize}px`,
              color: legendTextColor || "#fff"
            }}
          >
            <div className="font-semibold mb-2">数据点</div>
            {data.map((item, index) => (
              <div key={index} className="flex items-center gap-2 mb-1">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color || colors[index % colors.length] }}
                />
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
