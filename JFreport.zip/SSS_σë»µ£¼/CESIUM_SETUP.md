# Cesium 3D地球组件配置说明

## 🚀 快速开始

### 1. 安装Cesium依赖

```bash
npm install cesium
```

### 2. 配置Next.js

在 `next.config.mjs` 中添加Cesium配置：

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  webpack: (config) => {
    config.resolve.alias = {
      ...config.resolve.alias,
      cesium: 'cesium/Source/Cesium.js',
    }
    return config
  },
  transpilePackages: ['cesium'],
  experimental: {
    esmExternals: 'loose',
  },
}

export default nextConfig
```

### 3. 配置Cesium资源

在 `public` 目录下创建 `cesium` 文件夹，并添加以下文件：

```
public/
  cesium/
    skybox/
      px.jpg  # 天空盒正面
      nx.jpg  # 天空盒背面
      py.jpg  # 天空盒顶面
      ny.jpg  # 天空盒底面
      pz.jpg  # 天空盒右面
      nz.jpg  # 天空盒左面
```

### 4. 环境变量配置

创建 `.env.local` 文件：

```env
# Cesium Ion Token
NEXT_PUBLIC_CESIUM_ION_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJhMGY0MDZmMy1iMjYxLTQxZGQtODNlMC0xMTU0MWYzODA2ZDQiLCJpZCI6ODAwNzIsImlhdCI6MTY0NDg1MjI3M30.sLYxZ-k3L5U2Z5B1SkYErwkSNFJg5oDGrEYlxyrXrpU

# Bing Maps Key (可选)
NEXT_PUBLIC_BING_MAPS_KEY=your_bing_maps_key_here
```

**注意**: Token已经直接配置在 `lib/cesium-config.ts` 文件中，无需额外配置环境变量。

## 🎯 组件使用

### 基础3D地球组件

```tsx
import { CesiumSimple } from "@/components/charts/cesium-simple"

<CesiumSimple
  data={[
    { name: "北京", longitude: 116.4, latitude: 39.9, value: 100 },
    { name: "上海", longitude: 121.5, latitude: 31.2, value: 95 },
  ]}
  title="全球城市分布"
  showLegend={true}
  showTooltip={true}
  transparent={false}
  width={800}
  height={600}
/>
```

### 数据可视化组件

```tsx
import { CesiumDataVisualization } from "@/components/charts/cesium-data-visualization"

<CesiumDataVisualization
  data={data}
  visualizationType="heatmap"
  aggregationOptions={{
    enableClustering: true,
    clusteringPixelRange: 80,
  }}
  threeDOptions={{
    enable3D: true,
    buildingHeight: 100,
  }}
/>
```

### 时间轴组件

```tsx
import { CesiumTimeline } from "@/components/charts/cesium-timeline"

<CesiumTimeline
  data={timelineData}
  timeOptions={{
    enableTime: true,
    startTime: "2024-01-01T00:00:00Z",
    endTime: "2024-12-31T23:59:59Z",
  }}
  animationOptions={{
    enableAnimation: true,
    animationDuration: 2.0,
  }}
/>
```

## 🔧 配置选项

### 相机控制
- `longitude`: 经度
- `latitude`: 纬度  
- `height`: 高度
- `heading`: 航向角
- `pitch`: 俯仰角
- `roll`: 翻滚角

### 可视化类型
- `points`: 点可视化
- `heatmap`: 热力图
- `clusters`: 聚类
- `timeline`: 时间轴
- `trajectory`: 轨迹
- `3d-buildings`: 3D建筑

### 样式选项
- `baseMapStyle`: 底图样式 (satellite, street, terrain, hybrid)
- `dataVisualizationStyle`: 数据可视化样式
- `colorScheme`: 配色方案 (viridis, plasma, inferno, magma)

## 📝 注意事项

1. **Token配置**: 确保Cesium Ion Token有效且有足够的配额
2. **资源文件**: 天空盒图片需要手动添加到public/cesium/skybox/目录
3. **性能优化**: 大数据量时建议启用聚类功能
4. **浏览器兼容**: 需要支持WebGL的现代浏览器

## 🐛 常见问题

### Q: 组件显示空白
A: 检查Cesium Ion Token是否正确配置，确保网络连接正常

### Q: 天空盒不显示
A: 确保public/cesium/skybox/目录下有对应的图片文件

### Q: 性能问题
A: 启用数据聚类，减少同时显示的数据点数量

## 📚 更多资源

- [Cesium官方文档](https://cesium.com/learn/)
- [Cesium Ion平台](https://ion.cesium.com/)
- [Next.js配置指南](https://nextjs.org/docs)
