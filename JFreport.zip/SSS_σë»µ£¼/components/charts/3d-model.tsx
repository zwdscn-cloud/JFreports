'use client';

import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import * as THREE from 'three';
import { GLTFLoader, GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { BokehPass } from 'three/examples/jsm/postprocessing/BokehPass.js';
import { FilmPass } from 'three/examples/jsm/postprocessing/FilmPass.js';
import { ColorCorrectionShader } from 'three/examples/jsm/shaders/ColorCorrectionShader.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { FXAAShader } from 'three/examples/jsm/shaders/FXAAShader.js';

// 暗角效果shader
const VignetteShader = {
  uniforms: {
    'tDiffuse': { value: null },
    'offset': { value: 1.0 },
    'darkness': { value: 1.0 }
  },
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: `
    uniform sampler2D tDiffuse;
    uniform float offset;
    uniform float darkness;
    varying vec2 vUv;
    void main() {
      vec4 texel = texture2D(tDiffuse, vUv);
      vec2 uv = (vUv - vec2(0.5)) * vec2(offset);
      float vignette = 1.0 - dot(uv, uv) * darkness;
      gl_FragColor = vec4(texel.rgb * vignette, texel.a);
    }
  `
};
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Camera, Lightbulb, Eye, Save, RotateCcw, Plus, Trash2, Play, Video } from 'lucide-react';
import { useCameraState } from '@/components/camera-state-context';
import { ThreeDVideoRecorder } from '@/components/3d-video-recorder';



interface EnvironmentPreset {
  id: string;
  name: string;
  ambientIntensity: number;
  ambientColor: string;
  directionalIntensity: number;
  directionalColor: string;
}

interface ViewPreset {
  id: string;
  name: string;
  position: { x: number; y: number; z: number };
  rotation: { x: number; y: number; z: number };
  fov: number;
  target?: { x: number; y: number; z: number }; // 相机目标点
  description?: string;
  createdAt?: string;
}

interface PostProcessingSettings {
  // 景深效果
  depthOfField?: {
    enabled: boolean;
    focus: number; // 焦点距离
    aperture: number; // 光圈大小
    maxblur: number; // 最大模糊
  };
  // 噪点效果
  film?: {
    enabled: boolean;
    noiseIntensity: number; // 噪点强度
    scanlinesIntensity: number; // 扫描线强度
    scanlinesCount: number; // 扫描线数量
    grayscale: boolean; // 灰度模式
  };
  // 色彩调整
  colorCorrection?: {
    enabled: boolean;
    brightness: number; // 亮度
    contrast: number; // 对比度
    saturation: number; // 饱和度
    hue: number; // 色相
    gamma: number; // 伽马值
  };
  // 抗锯齿
  fxaa?: {
    enabled: boolean;
  };
  // 暗角效果
  vignette?: {
    enabled: boolean;
    offset: number; // 暗角偏移
    darkness: number; // 暗角强度
  };
}

interface ThreeDModelProps {
  data?: {
    modelUrl?: string;
    environmentPreset?: string;
    ambientIntensity?: number;
    ambientColor?: string;
    directionalIntensity?: number;
    directionalColor?: string;
    viewPresets?: ViewPreset[];
    currentView?: string;
    // 视角动画播放设置
    viewAnimationEnabled?: boolean;
    // 爆炸图设置
    explodeEnabled?: boolean;
    explodeIntensity?: number; // 爆炸强度 0-1
    restoreModel?: boolean; // 恢复模型标记
    triggerExplode?: boolean; // 触发爆炸动画标记
    // FFmpeg录屏设置
    showVideoRecorder?: boolean;
    // 后期处理设置
    postProcessing?: PostProcessingSettings;
  };
  onDataChange?: (data: any) => void;
  zoom?: number;
  width?: number;
  height?: number;
  canvasBackgroundColor?: string;
  elementId?: string; // 添加元素ID属性
}

const environmentPresets: EnvironmentPreset[] = [
  // 基础场景 - 提高默认亮度
  {
    id: 'studio',
    name: '工作室',
    ambientIntensity: 0.8,
    ambientColor: '#ffffff',
    directionalIntensity: 1.8,
    directionalColor: '#ffffff'
  },
  {
    id: 'outdoor',
    name: '户外',
    ambientIntensity: 1.0,
    ambientColor: '#87ceeb',
    directionalIntensity: 2.0,
    directionalColor: '#ffffff'
  },
  {
    id: 'sunset',
    name: '日落',
    ambientIntensity: 0.6,
    ambientColor: '#ff7f50',
    directionalIntensity: 0.8,
    directionalColor: '#ff4500'
  },
  {
    id: 'night',
    name: '夜晚',
    ambientIntensity: 0.2,
    ambientColor: '#000033',
    directionalIntensity: 0.4,
    directionalColor: '#ffffff'
  },
  {
    id: 'warm',
    name: '暖光',
    ambientIntensity: 0.7,
    ambientColor: '#fff8dc',
    directionalIntensity: 1.0,
    directionalColor: '#ffd700'
  },
  {
    id: 'dramatic',
    name: '戏剧性',
    ambientIntensity: 0.3,
    ambientColor: '#2c3e50',
    directionalIntensity: 1.8,
    directionalColor: '#ecf0f1'
  },
  
  // 新增亮度梯度场景
  {
    id: 'bright-studio',
    name: '明亮工作室',
    ambientIntensity: 1.2,
    ambientColor: '#ffffff',
    directionalIntensity: 2.5,
    directionalColor: '#ffffff'
  },
  {
    id: 'metal-showcase',
    name: '金属展示',
    ambientIntensity: 1.5,
    ambientColor: '#f0f8ff',
    directionalIntensity: 3.0,
    directionalColor: '#ffffff'
  },
  {
    id: 'chrome-lighting',
    name: '铬合金光照',
    ambientIntensity: 1.8,
    ambientColor: '#ffffff',
    directionalIntensity: 3.5,
    directionalColor: '#ffffff'
  },
  {
    id: 'soft-studio',
    name: '柔和工作室',
    ambientIntensity: 0.3,
    ambientColor: '#f8f8ff',
    directionalIntensity: 0.6,
    directionalColor: '#ffffff'
  },
  {
    id: 'golden-hour',
    name: '黄金时刻',
    ambientIntensity: 0.7,
    ambientColor: '#ffd700',
    directionalIntensity: 1.2,
    directionalColor: '#ff8c00'
  },
  {
    id: 'blue-hour',
    name: '蓝色时刻',
    ambientIntensity: 0.4,
    ambientColor: '#4169e1',
    directionalIntensity: 0.8,
    directionalColor: '#87ceeb'
  },
  {
    id: 'dawn',
    name: '黎明',
    ambientIntensity: 0.5,
    ambientColor: '#ffb6c1',
    directionalIntensity: 1.0,
    directionalColor: '#ff69b4'
  },
  {
    id: 'dusk',
    name: '黄昏',
    ambientIntensity: 0.4,
    ambientColor: '#8b4513',
    directionalIntensity: 0.7,
    directionalColor: '#cd853f'
  },
  {
    id: 'moonlight',
    name: '月光',
    ambientIntensity: 0.2,
    ambientColor: '#e6e6fa',
    directionalIntensity: 0.5,
    directionalColor: '#f0f8ff'
  },
  {
    id: 'neon',
    name: '霓虹',
    ambientIntensity: 0.3,
    ambientColor: '#00ff00',
    directionalIntensity: 1.5,
    directionalColor: '#ff00ff'
  },
  {
    id: 'industrial',
    name: '工业风',
    ambientIntensity: 0.4,
    ambientColor: '#708090',
    directionalIntensity: 1.3,
    directionalColor: '#ffffff'
  },
  {
    id: 'forest',
    name: '森林',
    ambientIntensity: 0.6,
    ambientColor: '#228b22',
    directionalIntensity: 1.1,
    directionalColor: '#90ee90'
  },
  {
    id: 'ocean',
    name: '海洋',
    ambientIntensity: 0.7,
    ambientColor: '#00bfff',
    directionalIntensity: 1.4,
    directionalColor: '#87ceeb'
  },
  {
    id: 'desert',
    name: '沙漠',
    ambientIntensity: 0.8,
    ambientColor: '#f4a460',
    directionalIntensity: 1.6,
    directionalColor: '#ffd700'
  },
  {
    id: 'arctic',
    name: '极地',
    ambientIntensity: 0.5,
    ambientColor: '#f0f8ff',
    directionalIntensity: 1.0,
    directionalColor: '#ffffff'
  },
  {
    id: 'volcano',
    name: '火山',
    ambientIntensity: 0.4,
    ambientColor: '#8b0000',
    directionalIntensity: 1.7,
    directionalColor: '#ff4500'
  },
  {
    id: 'aurora',
    name: '极光',
    ambientIntensity: 0.3,
    ambientColor: '#00ff7f',
    directionalIntensity: 1.2,
    directionalColor: '#ff1493'
  },
  {
    id: 'cyberpunk',
    name: '赛博朋克',
    ambientIntensity: 0.2,
    ambientColor: '#ff00ff',
    directionalIntensity: 1.8,
    directionalColor: '#00ffff'
  },
  {
    id: 'minimalist',
    name: '极简主义',
    ambientIntensity: 0.6,
    ambientColor: '#ffffff',
    directionalIntensity: 0.8,
    directionalColor: '#f5f5f5'
  },
  {
    id: 'vintage',
    name: '复古',
    ambientIntensity: 0.5,
    ambientColor: '#daa520',
    directionalIntensity: 1.1,
    directionalColor: '#cd853f'
  },
  {
    id: 'futuristic',
    name: '未来主义',
    ambientIntensity: 0.4,
    ambientColor: '#00ced1',
    directionalIntensity: 1.5,
    directionalColor: '#ffffff'
  }
];

export default function ThreeDModel({ data, onDataChange, zoom = 100, width, height, canvasBackgroundColor = "#ffffff", elementId }: ThreeDModelProps) {
  const { setGetCurrentCameraState } = useCameraState();
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const modelRef = useRef<THREE.Group | null>(null);
  const ambientLightRef = useRef<THREE.AmbientLight | null>(null);
  const directionalLightRef = useRef<THREE.DirectionalLight | null>(null);
  const frontLightRef = useRef<THREE.DirectionalLight | null>(null);
  const backLightRef = useRef<THREE.DirectionalLight | null>(null);
  const leftLightRef = useRef<THREE.DirectionalLight | null>(null);
  const rightLightRef = useRef<THREE.DirectionalLight | null>(null);
  const topLightRef = useRef<THREE.DirectionalLight | null>(null);
  const bottomLightRef = useRef<THREE.DirectionalLight | null>(null);
  const composerRef = useRef<EffectComposer | null>(null);
  const bokehPassRef = useRef<BokehPass | null>(null);
  const filmPassRef = useRef<FilmPass | null>(null);
  const colorCorrectionPassRef = useRef<ShaderPass | null>(null);
  const fxaaPassRef = useRef<ShaderPass | null>(null);
  const vignettePassRef = useRef<ShaderPass | null>(null);
  
  // 全局动画清理 ref
  const animationCleanupRef = useRef<(() => void) | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');
  const [isInitialized, setIsInitialized] = useState(false);
  const [showErrorDetails, setShowErrorDetails] = useState(false);

  // 默认后期处理设置
  const defaultPostProcessing: PostProcessingSettings = {
    depthOfField: {
      enabled: false,
      focus: 10.0,
      aperture: 0.025,
      maxblur: 0.01
    },
    film: {
      enabled: false,
      noiseIntensity: 0.35,
      scanlinesIntensity: 0.025,
      scanlinesCount: 648,
      grayscale: false
    },
    colorCorrection: {
      enabled: false,
      brightness: 0.0,
      contrast: 1.0,
      saturation: 1.0,
      hue: 0.0,
      gamma: 1.0
    },
    fxaa: {
      enabled: false
    },
    vignette: {
      enabled: false,
      offset: 1.0,
      darkness: 2.0
    }
  };

  const postProcessing = useMemo(() => {
    return data?.postProcessing || defaultPostProcessing;
  }, [data?.postProcessing]);

  // 使用ref存储最新的postProcessing值，避免循环依赖
  const postProcessingRef = useRef(postProcessing);
  postProcessingRef.current = postProcessing;

  // 创建跟随模型的光源系统
  const createModelFollowingLights = useCallback((model: THREE.Group) => {
    // 前光源
    const frontLight = new THREE.DirectionalLight(0xffffff, 5.0);
    frontLight.position.set(0, 5, 15);
    frontLight.castShadow = true;
    frontLight.shadow.mapSize.width = 1024;
    frontLight.shadow.mapSize.height = 1024;
    frontLight.shadow.camera.near = 0.1;
    frontLight.shadow.camera.far = 50;
    frontLight.shadow.camera.left = -10;
    frontLight.shadow.camera.right = 10;
    frontLight.shadow.camera.top = 10;
    frontLight.shadow.camera.bottom = -10;
    frontLight.shadow.bias = -0.0001;
    model.add(frontLight);
    frontLightRef.current = frontLight;

    // 后光源
    const backLight = new THREE.DirectionalLight(0xffffff, 5.0);
    backLight.position.set(0, 5, -15);
    backLight.castShadow = true;
    backLight.shadow.mapSize.width = 1024;
    backLight.shadow.mapSize.height = 1024;
    backLight.shadow.camera.near = 0.1;
    backLight.shadow.camera.far = 50;
    backLight.shadow.camera.left = -10;
    backLight.shadow.camera.right = 10;
    backLight.shadow.camera.top = 10;
    backLight.shadow.camera.bottom = -10;
    backLight.shadow.bias = -0.0001;
    model.add(backLight);
    backLightRef.current = backLight;

    // 左光源
    const leftLight = new THREE.DirectionalLight(0xffffff, 5.0);
    leftLight.position.set(-15, 5, 0);
    leftLight.castShadow = true;
    leftLight.shadow.mapSize.width = 1024;
    leftLight.shadow.mapSize.height = 1024;
    leftLight.shadow.camera.near = 0.1;
    leftLight.shadow.camera.far = 50;
    leftLight.shadow.camera.left = -10;
    leftLight.shadow.camera.right = 10;
    leftLight.shadow.camera.top = 10;
    leftLight.shadow.camera.bottom = -10;
    leftLight.shadow.bias = -0.0001;
    model.add(leftLight);
    leftLightRef.current = leftLight;

    // 右光源
    const rightLight = new THREE.DirectionalLight(0xffffff, 5.0);
    rightLight.position.set(15, 5, 0);
    rightLight.castShadow = true;
    rightLight.shadow.mapSize.width = 1024;
    rightLight.shadow.mapSize.height = 1024;
    rightLight.shadow.camera.near = 0.1;
    rightLight.shadow.camera.far = 50;
    rightLight.shadow.camera.left = -10;
    rightLight.shadow.camera.right = 10;
    rightLight.shadow.camera.top = 10;
    rightLight.shadow.camera.bottom = -10;
    rightLight.shadow.bias = -0.0001;
    model.add(rightLight);
    rightLightRef.current = rightLight;

    // 顶部光源
    const topLight = new THREE.DirectionalLight(0xffffff, 5.0);
    topLight.position.set(0, 20, 0);
    topLight.castShadow = true;
    topLight.shadow.mapSize.width = 1024;
    topLight.shadow.mapSize.height = 1024;
    topLight.shadow.camera.near = 0.1;
    topLight.shadow.camera.far = 50;
    topLight.shadow.camera.left = -10;
    topLight.shadow.camera.right = 10;
    topLight.shadow.camera.top = 10;
    topLight.shadow.camera.bottom = -10;
    topLight.shadow.bias = -0.0001;
    model.add(topLight);
    topLightRef.current = topLight;

    // 底部光源
    const bottomLight = new THREE.DirectionalLight(0xffffff, 3.0);
    bottomLight.position.set(0, -10, 0);
    bottomLight.castShadow = true;
    bottomLight.shadow.mapSize.width = 1024;
    bottomLight.shadow.mapSize.height = 1024;
    bottomLight.shadow.camera.near = 0.1;
    bottomLight.shadow.camera.far = 50;
    bottomLight.shadow.camera.left = -10;
    bottomLight.shadow.camera.right = 10;
    bottomLight.shadow.camera.top = 10;
    bottomLight.shadow.camera.bottom = -10;
    bottomLight.shadow.bias = -0.0001;
    model.add(bottomLight);
    bottomLightRef.current = bottomLight;

    console.log('跟随模型的光源系统已创建');
  }, []);

  // 初始化后期处理（带设置参数）
  const initializePostProcessingWithSettings = useCallback((renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.PerspectiveCamera, settings: PostProcessingSettings) => {
    try {
      const composer = new EffectComposer(renderer);

      // 基础渲染通道
      const renderPass = new RenderPass(scene, camera);
      composer.addPass(renderPass);

    // 景深效果
    if (settings.depthOfField?.enabled) {
      const bokehPass = new BokehPass(scene, camera, {
        focus: settings.depthOfField.focus,
        aperture: settings.depthOfField.aperture,
        maxblur: settings.depthOfField.maxblur,
        width: mountRef.current?.clientWidth || 800,
        height: mountRef.current?.clientHeight || 600
      });
      composer.addPass(bokehPass);
      bokehPassRef.current = bokehPass;
    }

    // 噪点效果
    if (settings.film?.enabled) {
      const filmPass = new FilmPass(
        settings.film.noiseIntensity,
        settings.film.scanlinesIntensity,
        settings.film.scanlinesCount,
        settings.film.grayscale
      );
      composer.addPass(filmPass);
      filmPassRef.current = filmPass;
    }

    // 色彩调整 - 使用简化的实现
    if (settings.colorCorrection?.enabled) {
      try {
        const colorCorrectionPass = new ShaderPass(ColorCorrectionShader);
        // ColorCorrectionShader可能没有我们期望的uniforms，所以先尝试添加，如果失败就跳过
        composer.addPass(colorCorrectionPass);
        colorCorrectionPassRef.current = colorCorrectionPass;
      } catch (error) {
        console.warn('色彩调整效果初始化失败:', error);
      }
    }

    // 抗锯齿
    if (settings.fxaa?.enabled) {
      try {
        const fxaaPass = new ShaderPass(FXAAShader);
        composer.addPass(fxaaPass);
        fxaaPassRef.current = fxaaPass;
      } catch (error) {
        console.warn('FXAA抗锯齿效果初始化失败:', error);
      }
    }

    // 暗角效果
    if (settings.vignette?.enabled) {
      try {
        console.log('初始化暗角效果:', settings.vignette);
        const vignettePass = new ShaderPass(VignetteShader);
        vignettePass.uniforms['offset'].value = settings.vignette.offset;
        vignettePass.uniforms['darkness'].value = settings.vignette.darkness;
        composer.addPass(vignettePass);
        vignettePassRef.current = vignettePass;
        console.log('暗角效果初始化成功');
      } catch (error) {
        console.warn('暗角效果初始化失败:', error);
      }
    }

      return composer;
    } catch (error) {
      console.error('initializePostProcessingWithSettings 错误:', error);
      // 返回一个基础的composer，只包含渲染通道
      const composer = new EffectComposer(renderer);
      const renderPass = new RenderPass(scene, camera);
      composer.addPass(renderPass);
      return composer;
    }
  }, []); // 移除settings依赖，避免循环依赖

  // 初始化后期处理（使用当前设置）
  const initializePostProcessing = useCallback((renderer: THREE.WebGLRenderer, scene: THREE.Scene, camera: THREE.PerspectiveCamera) => {
    return initializePostProcessingWithSettings(renderer, scene, camera, postProcessing);
  }, [initializePostProcessingWithSettings, postProcessing]);

  // 安全的后期处理更新函数，使用ref避免循环依赖
  const updatePostProcessingSafe = useCallback(() => {
    const currentSettings = postProcessingRef.current;
    
    if (!sceneRef.current || !cameraRef.current || !rendererRef.current) {
      return;
    }

    try {
      // 直接重新创建composer，不依赖现有的composer
      const composer = initializePostProcessingWithSettings(rendererRef.current, sceneRef.current, cameraRef.current, currentSettings);
      composerRef.current = composer;
    } catch (error) {
      console.error('updatePostProcessingSafe 错误:', error);
    }
  }, []); // 移除依赖，避免循环依赖

  // 视角管理状态
  const [showViewDialog, setShowViewDialog] = useState(false);
  const [newViewName, setNewViewName] = useState('');
  const [newViewDescription, setNewViewDescription] = useState('');
  const [isCreatingView, setIsCreatingView] = useState(false);

  // 右键菜单状态
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [contextMenuPosition, setContextMenuPosition] = useState({ x: 0, y: 0 });

  // 视角动画播放状态
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentViewIndex, setCurrentViewIndex] = useState(0);
  const [animationTimer, setAnimationTimer] = useState<NodeJS.Timeout | null>(null);
  const currentViewIndexRef = useRef(0);

  // 爆炸图状态
  const [isExploded, setIsExploded] = useState(false);
  const originalPositionsRef = useRef<Map<THREE.Object3D, THREE.Vector3>>(new Map());
  const explodeAnimationRef = useRef<number | null>(null);
  const decomposedMeshesRef = useRef<THREE.Mesh[]>([]);
  
  // FFmpeg录屏状态
  const [showVideoRecorder, setShowVideoRecorder] = useState(false);


  // 生成唯一ID
  const generateId = useCallback(() => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }, []);

  // 分解几何体为多个小网格（用于单一大型模型的爆炸）
  const decomposeGeometry = useCallback((model: THREE.Object3D): THREE.Mesh[] => {
    const decomposedMeshes: THREE.Mesh[] = [];
    
    model.traverse((child: THREE.Object3D) => {
      if (child instanceof THREE.Mesh && child.geometry) {
        const geometry = child.geometry;
        const positions = geometry.attributes.position;
        
        if (positions && positions.count > 0) {
          // 如果顶点数量较少，直接使用原网格
          if (positions.count <= 200) {
            decomposedMeshes.push(child);
            return;
          }
          
          // 对于大型几何体，使用更简单的方法：基于空间位置分解
          const vertexCount = positions.count;
          const positionsArray = positions.array;
          
          // 计算几何体的边界框
          let minX = Infinity, maxX = -Infinity;
          let minY = Infinity, maxY = -Infinity;
          let minZ = Infinity, maxZ = -Infinity;
          
          for (let i = 0; i < vertexCount; i++) {
            const x = positionsArray[i * 3];
            const y = positionsArray[i * 3 + 1];
            const z = positionsArray[i * 3 + 2];
            
            minX = Math.min(minX, x);
            maxX = Math.max(maxX, x);
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
            minZ = Math.min(minZ, z);
            maxZ = Math.max(maxZ, z);
          }
          
          // 将几何体分解为8个象限
          const centerX = (minX + maxX) / 2;
          const centerY = (minY + maxY) / 2;
          const centerZ = (minZ + maxZ) / 2;
          
          for (let octant = 0; octant < 8; octant++) {
            const vertices: number[] = [];
            const normals: number[] = [];
            const indices: number[] = [];
            
            // 确定象限范围
            const xMin = (octant & 1) ? centerX : minX;
            const xMax = (octant & 1) ? maxX : centerX;
            const yMin = (octant & 2) ? centerY : minY;
            const yMax = (octant & 2) ? maxY : centerY;
            const zMin = (octant & 4) ? centerZ : minZ;
            const zMax = (octant & 4) ? maxZ : centerZ;
            
            // 收集属于这个象限的顶点
            const vertexMap = new Map<number, number>();
            let newVertexIndex = 0;
            
            for (let i = 0; i < vertexCount; i++) {
              const x = positionsArray[i * 3];
              const y = positionsArray[i * 3 + 1];
              const z = positionsArray[i * 3 + 2];
              
              if (x >= xMin && x <= xMax && y >= yMin && y <= yMax && z >= zMin && z <= zMax) {
                vertices.push(x, y, z);
                
                if (geometry.attributes.normal) {
                  const normalArray = geometry.attributes.normal.array;
                  normals.push(normalArray[i * 3], normalArray[i * 3 + 1], normalArray[i * 3 + 2]);
                }
                
                vertexMap.set(i, newVertexIndex++);
              }
            }
            
            // 如果有足够的顶点，创建新的几何体
            if (vertices.length >= 9) { // 至少3个顶点
              const newGeometry = new THREE.BufferGeometry();
              newGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(vertices), 3));
              
              if (normals.length > 0) {
                newGeometry.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(normals), 3));
              }
              
              // 创建新的网格
              const newMesh = new THREE.Mesh(newGeometry, child.material);
              newMesh.position.copy(child.position);
              newMesh.rotation.copy(child.rotation);
              newMesh.scale.copy(child.scale);
              
              decomposedMeshes.push(newMesh);
            }
          }
        }
      }
    });
    
    return decomposedMeshes;
  }, []);

  // 获取当前相机状态
  const getCurrentCameraState = useCallback(() => {
    if (!cameraRef.current || !controlsRef.current) return null;
    
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    
    return {
      position: {
        x: camera.position.x,
        y: camera.position.y,
        z: camera.position.z
      },
      rotation: {
        x: camera.rotation.x,
        y: camera.rotation.y,
        z: camera.rotation.z
      },
      fov: camera.fov,
      target: controls.target ? {
        x: controls.target.x,
        y: controls.target.y,
        z: controls.target.z
      } : undefined
    };
  }, []);

  // 将相机状态获取函数传递给Context
  useEffect(() => {
    setGetCurrentCameraState(getCurrentCameraState);
  }, [getCurrentCameraState]); // 移除setGetCurrentCameraState依赖，避免无限循环

  // 组件卸载时清理所有动画
  useEffect(() => {
    return () => {
      if (animationCleanupRef.current) {
        animationCleanupRef.current();
        animationCleanupRef.current = null;
      }
      // 清理动画播放定时器
      if (animationTimer) {
        clearTimeout(animationTimer);
      }
    };
  }, [animationTimer]);

  // 视角动画播放逻辑
  useEffect(() => {
    // 如果动画播放被禁用，停止播放
    if (!data?.viewAnimationEnabled) {
      setIsPlaying(false);
      if (animationTimer) {
        clearTimeout(animationTimer);
        setAnimationTimer(null);
      }
      return;
    }

    // 如果没有视角预设，停止播放
    if (!data?.viewPresets || data.viewPresets.length === 0) {
      setIsPlaying(false);
      if (animationTimer) {
        clearTimeout(animationTimer);
        setAnimationTimer(null);
      }
      return;
    }

    // 开始播放动画
    if (!isPlaying) {
      setIsPlaying(true);
      setCurrentViewIndex(0);
      startViewAnimation();
    }
  }, [data?.viewAnimationEnabled, data?.viewPresets]);

  // 开始视角动画播放
  const startViewAnimation = useCallback(() => {
    if (!data?.viewPresets || data.viewPresets.length === 0) return;

    const playNextView = () => {
      if (!data?.viewAnimationEnabled || !data?.viewPresets) return;

      const viewPresets = data.viewPresets;
      let nextIndex = currentViewIndexRef.current + 1;
      
      // 检查是否到达最后一个视角
      if (nextIndex >= viewPresets.length) {
        // 到达最后一个视角后，重新从第一个视角开始循环播放
        nextIndex = 0;
        console.log('视角动画循环播放：重新从第一个视角开始');
      }

      const nextView = viewPresets[nextIndex];

      // 切换到下一个视角（动画完成后会自动触发下一个视角）
      switchToView(nextView.id, playNextView);
      currentViewIndexRef.current = nextIndex;
      setCurrentViewIndex(nextIndex);
    };

    // 立即播放第一个视角
    if (data.viewPresets.length > 0) {
      const firstView = data.viewPresets[0];
      currentViewIndexRef.current = 0;
      setCurrentViewIndex(0);
      switchToView(firstView.id, playNextView);
    }
  }, [data?.viewPresets, data?.viewAnimationEnabled]);

  // 停止视角动画播放
  const stopViewAnimation = useCallback(() => {
    console.log('3D组件：停止视角动画播放');
    setIsPlaying(false);
    currentViewIndexRef.current = 0;
    setCurrentViewIndex(0);
    
    // 清理动画定时器
    if (animationTimer) {
      clearTimeout(animationTimer);
      setAnimationTimer(null);
    }
    
    // 清理动画清理函数
    if (animationCleanupRef.current) {
      animationCleanupRef.current();
      animationCleanupRef.current = null;
    }
    
    console.log('3D组件：视角动画已完全停止');
  }, [animationTimer]);

  // 爆炸图功能
  const explodeModel = useCallback((intensity: number = 0.5) => {
    if (!modelRef.current || !sceneRef.current || !cameraRef.current || !controlsRef.current) return;

    // 停止之前的爆炸动画
    if (explodeAnimationRef.current) {
      cancelAnimationFrame(explodeAnimationRef.current);
    }

    const model = modelRef.current;
    const meshes: THREE.Mesh[] = [];
    const instancedMeshes: THREE.InstancedMesh[] = [];
    
    // 收集所有网格对象和实例化网格
    model.traverse((child: THREE.Object3D) => {
      if (child instanceof THREE.Mesh) {
        // 检查几何体是否有效
        if (child.geometry && child.geometry.attributes.position && child.geometry.attributes.position.count > 0) {
          meshes.push(child);
        }
      } else if (child instanceof THREE.InstancedMesh) {
        // 处理实例化网格
        if (child.geometry && child.geometry.attributes.position && child.geometry.attributes.position.count > 0) {
          instancedMeshes.push(child);
        }
      }
    });

    // 如果没有找到任何可爆炸的对象，尝试其他方法
    if (meshes.length === 0 && instancedMeshes.length === 0) {
      console.warn('未找到可爆炸的网格对象，尝试使用几何体分解');
      
      // 尝试分解几何体
      const decomposedMeshes = decomposeGeometry(model);
      if (decomposedMeshes.length > 0) {
        // 保存分解后的网格引用
        decomposedMeshesRef.current = decomposedMeshes;
        
        // 为分解后的网格保存原始位置
        decomposedMeshes.forEach(mesh => {
          if (!originalPositionsRef.current.has(mesh)) {
            originalPositionsRef.current.set(mesh, mesh.position.clone());
          }
        });
        
        meshes.push(...decomposedMeshes);
      } else {
        console.warn('无法分解几何体，爆炸动画不可用');
        return;
      }
    }

    // 计算模型中心点和边界框（使用原始位置）
    const tempPositions = new Map<THREE.Mesh, THREE.Vector3>();
    meshes.forEach(mesh => {
      const originalPos = originalPositionsRef.current.get(mesh);
      if (originalPos) {
        tempPositions.set(mesh, mesh.position.clone());
        mesh.position.copy(originalPos);
      }
    });

    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxSize = Math.max(size.x, size.y, size.z);

    // 恢复临时位置
    tempPositions.forEach((pos, mesh) => {
      mesh.position.copy(pos);
    });

    // 为每个网格计算爆炸方向
    const explodeData = meshes.map((mesh) => {
      const originalPos = originalPositionsRef.current.get(mesh);
      if (!originalPos) return null;

      // 计算从中心到网格的方向向量
      const direction = new THREE.Vector3()
        .subVectors(originalPos, center)
        .normalize();

      // 如果方向向量为零（在中心），使用基于索引的均匀分布方向
      if (direction.length() < 0.001) {
        const index = meshes.indexOf(mesh);
        const phi = Math.acos(1 - 2 * index / meshes.length);
        const theta = Math.PI * (1 + Math.sqrt(5)) * index; // 黄金角度分布
        direction.set(
          Math.cos(theta) * Math.sin(phi),
          Math.sin(theta) * Math.sin(phi),
          Math.cos(phi)
        );
      }

      // 计算爆炸距离（更平滑的分布）
      const distanceFromCenter = originalPos.distanceTo(center);
      const baseDistance = Math.max(distanceFromCenter, maxSize * 0.1);
      const explodeDistance = baseDistance * (0.5 + intensity * 1.5);

      // 计算目标位置
      const targetPosition = new THREE.Vector3()
        .copy(originalPos)
        .add(direction.multiplyScalar(explodeDistance));

      return {
        mesh,
        originalPos: originalPos.clone(),
        targetPosition,
        direction: direction.clone()
      };
    }).filter(Boolean);

    // 计算爆炸后的整体边界框
    const expandedBox = new THREE.Box3();
    explodeData.forEach((data) => {
      if (data) {
        expandedBox.expandByPoint(data.originalPos);
        expandedBox.expandByPoint(data.targetPosition);
      }
    });
    
    const expandedCenter = expandedBox.getCenter(new THREE.Vector3());
    const expandedSize = expandedBox.getSize(new THREE.Vector3());
    const maxExpandedSize = Math.max(expandedSize.x, expandedSize.y, expandedSize.z);
    
    // 计算倾斜45度俯视的相机位置
    const currentCamera = cameraRef.current;
    const currentControls = controlsRef.current;
    const currentCameraPosition = currentCamera.position.clone();
    const currentTarget = currentControls.target.clone();
    
    // 计算合适的相机距离（确保能看到全貌）
    const baseDistance = maxExpandedSize * 3.5; // 增加基础距离
    const currentDistance = currentCameraPosition.distanceTo(center);
    const minDistance = maxExpandedSize * 2.5; // 最小距离限制
    const cameraDistance = Math.max(baseDistance, Math.max(currentDistance * 1.2, minDistance));
    
    // 设置倾斜45度俯视角度
    const angle = Math.PI / 4; // 45度
    const cameraPosition = new THREE.Vector3(
      expandedCenter.x + cameraDistance * Math.sin(angle) * 0.7,
      expandedCenter.y + cameraDistance * Math.cos(angle),
      expandedCenter.z + cameraDistance * Math.sin(angle) * 0.7
    );
    
    // 设置相机目标点为模型中心
    const cameraTarget = expandedCenter.clone();

    // 执行爆炸动画
    const startTime = performance.now();
    const duration = 2000; // 2秒动画，更平滑

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // 使用更平滑的缓动函数
      const easeProgress = progress < 0.5 
        ? 4 * progress * progress * progress 
        : 1 - Math.pow(-2 * progress + 2, 3) / 2; // easeInOutCubic

      // 更新网格位置
      explodeData.forEach((data) => {
        if (data) {
          data.mesh.position.lerpVectors(data.originalPos, data.targetPosition, easeProgress);
        }
      });

      // 平滑调整相机到倾斜45度俯视角度
      if (cameraRef.current && controlsRef.current) {
        const camera = cameraRef.current;
        const controls = controlsRef.current;
        
        // 平滑移动到倾斜45度俯视位置
        camera.position.lerp(cameraPosition, easeProgress * 0.8);
        controls.target.lerp(cameraTarget, easeProgress * 0.8);
        controls.update();
      }

      if (progress < 1) {
        explodeAnimationRef.current = requestAnimationFrame(animate);
      } else {
        explodeAnimationRef.current = null;
        setIsExploded(true);
      }
    };

    animate(startTime);
  }, []);

  // 处理爆炸按钮点击
  const handleExplodeClick = useCallback(() => {
    if (data?.explodeIntensity !== undefined) {
      explodeModel(data.explodeIntensity);
    }
  }, [data?.explodeIntensity, explodeModel]);

  // 处理FFmpeg录屏按钮点击
  const handleVideoRecorderClick = useCallback(() => {
    setShowVideoRecorder(true);
  }, []);

  // 恢复模型到原始状态
  const restoreModel = useCallback((immediate: boolean = false) => {
    if (!modelRef.current || !cameraRef.current || !controlsRef.current) return;

    console.log('3D组件：恢复模型到原始状态', immediate ? '(立即恢复)' : '(动画恢复)');

    // 停止之前的动画
    if (explodeAnimationRef.current) {
      cancelAnimationFrame(explodeAnimationRef.current);
      explodeAnimationRef.current = null;
    }

    const model = modelRef.current;
    const meshes: THREE.Mesh[] = [];
    
    // 收集所有网格对象
    model.traverse((child: THREE.Object3D) => {
      if (child instanceof THREE.Mesh) {
        meshes.push(child);
      }
    });

    // 如果有分解后的网格，也包含它们
    if (decomposedMeshesRef.current.length > 0) {
      meshes.push(...decomposedMeshesRef.current);
    }

    if (meshes.length === 0) return;

    // 立即恢复所有网格到原始位置
    meshes.forEach((mesh) => {
      const originalPos = originalPositionsRef.current.get(mesh);
      if (originalPos) {
        mesh.position.copy(originalPos);
      }
    });

    // 立即设置爆炸状态为false
    setIsExploded(false);

    if (immediate) {
      console.log('3D组件：模型已立即恢复到原始状态');
      return;
    }

    // 如果需要动画恢复，执行恢复动画
    const restoreData = meshes.map((mesh) => {
      const originalPos = originalPositionsRef.current.get(mesh);
      if (!originalPos) return null;

      return {
        mesh,
        startPos: mesh.position.clone(),
        targetPos: originalPos.clone()
      };
    }).filter(Boolean);

    // 执行恢复动画
    const startTime = performance.now();
    const duration = 1500; // 1.5秒动画

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // 使用更平滑的缓动函数
      const easeProgress = progress < 0.5 
        ? 4 * progress * progress * progress 
        : 1 - Math.pow(-2 * progress + 2, 3) / 2; // easeInOutCubic

      // 更新网格位置
      restoreData.forEach((data) => {
        if (data) {
          data.mesh.position.lerpVectors(data.startPos, data.targetPos, easeProgress);
        }
      });

      if (progress < 1) {
        explodeAnimationRef.current = requestAnimationFrame(animate);
      } else {
        explodeAnimationRef.current = null;
        console.log('3D组件：模型恢复动画完成');
      }
    };

    animate(startTime);
  }, []);





  // 全局点击事件监听器，关闭右键菜单
  useEffect(() => {
    const handleGlobalClick = () => {
      setShowContextMenu(false);
    };

    document.addEventListener('click', handleGlobalClick);
    
    return () => {
      document.removeEventListener('click', handleGlobalClick);
    };
  }, []);

  // 创建新视角
  const createView = useCallback(() => {
    if (!newViewName.trim()) return;
    
    const currentState = getCurrentCameraState();
    if (!currentState) return;
    
    const newView: ViewPreset = {
      id: generateId(),
      name: newViewName.trim(),
      description: newViewDescription.trim(),
      position: currentState.position,
      rotation: currentState.rotation,
      fov: currentState.fov,
      target: currentState.target,
      createdAt: new Date().toISOString()
    };
    
    const updatedViewPresets = [...(data?.viewPresets || []), newView];
    
    if (onDataChange) {
      onDataChange({
        ...data,
        viewPresets: updatedViewPresets,
        currentView: newView.id
      });
    }
    
    // 重置表单
    setNewViewName('');
    setNewViewDescription('');
    setShowViewDialog(false);
    setIsCreatingView(false);
  }, [newViewName, newViewDescription, data, onDataChange, getCurrentCameraState, generateId]);

  // 切换到指定视角
  const switchToView = useCallback((viewId: string, onComplete?: () => void) => {
    if (!cameraRef.current || !controlsRef.current) return;
    
    const view = data?.viewPresets?.find(v => v.id === viewId);
    if (!view) return;
    
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    
    // 平滑切换到目标视角
    const duration = 2000; // 2秒
    const startTime = Date.now();
    const startPosition = camera.position.clone();
    const startRotation = camera.rotation.clone();
    const startFov = camera.fov;
    const startTarget = controls.target.clone();
    
    const targetPosition = new THREE.Vector3(view.position.x, view.position.y, view.position.z);
    const targetRotation = new THREE.Euler(view.rotation.x, view.rotation.y, view.rotation.z);
    const targetFov = view.fov;
    const targetTarget = view.target ? new THREE.Vector3(view.target.x, view.target.y, view.target.z) : new THREE.Vector3(0, 0, 0);
    
    // 使用 ref 来跟踪动画状态，以便在组件卸载时清理
    const animationRef = { current: null as number | null };
    
    const animate = () => {
      // 检查组件是否仍然挂载
      if (!cameraRef.current || !controlsRef.current) {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
        return;
      }
      
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // 使用更平滑的缓动函数 (easeInOutCubic)
      const easeProgress = progress < 0.5 
        ? 4 * progress * progress * progress 
        : 1 - Math.pow(-2 * progress + 2, 3) / 2;
      
      // 插值位置
      camera.position.lerpVectors(startPosition, targetPosition, easeProgress);
      
      // 插值旋转
      camera.rotation.x = startRotation.x + (targetRotation.x - startRotation.x) * easeProgress;
      camera.rotation.y = startRotation.y + (targetRotation.y - startRotation.y) * easeProgress;
      camera.rotation.z = startRotation.z + (targetRotation.z - startRotation.z) * easeProgress;
      
      // 插值FOV
      camera.fov = startFov + (targetFov - startFov) * easeProgress;
      camera.updateProjectionMatrix();
      
      // 插值目标点
      controls.target.lerpVectors(startTarget, targetTarget, easeProgress);
      controls.update();
      
      if (progress < 1) {
        animationRef.current = requestAnimationFrame(animate);
      } else {
        animationRef.current = null;
        // 动画完成后调用回调函数
        if (onComplete) {
          onComplete();
        }
      }
    };
    
    animate();
    
    // 更新当前视角
    if (onDataChange) {
      onDataChange({
        ...data,
        currentView: viewId
      });
    }
    
    // 设置全局清理函数
    animationCleanupRef.current = () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [data, onDataChange]);

  // 删除视角
  const deleteView = useCallback((viewId: string) => {
    const updatedViewPresets = data?.viewPresets?.filter(v => v.id !== viewId) || [];
    
    if (onDataChange) {
      onDataChange({
        ...data,
        viewPresets: updatedViewPresets,
        currentView: data?.currentView === viewId ? undefined : data?.currentView
      });
    }
  }, [data, onDataChange]);

  // 打开创建视角对话框
  const openCreateViewDialog = useCallback(() => {
    setShowViewDialog(true);
    setIsCreatingView(true);
  }, []);

  // 取消创建视角
  const cancelCreateView = useCallback(() => {
    setShowViewDialog(false);
    setIsCreatingView(false);
    setNewViewName('');
    setNewViewDescription('');
  }, []);



  // 处理右键菜单
  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    console.log('右键菜单触发，位置:', { x: e.clientX, y: e.clientY });
    setContextMenuPosition({ x: e.clientX, y: e.clientY });
    setShowContextMenu(true);
  }, []);

  // 关闭右键菜单
  const closeContextMenu = useCallback(() => {
    setShowContextMenu(false);
  }, []);

  // 初始化Three.js场景
  const initScene = () => {
    if (!mountRef.current || isInitialized) return;
    
    // 强制清理所有旧内容
    mountRef.current.innerHTML = '';
    
    // 重置所有ref
    sceneRef.current = null;
    rendererRef.current = null;
    cameraRef.current = null;
    controlsRef.current = null;
    modelRef.current = null;
    ambientLightRef.current = null;
    directionalLightRef.current = null;

    // 创建场景
    const scene = new THREE.Scene();
    // 使用画布背景色
    scene.background = new THREE.Color(canvasBackgroundColor);
    sceneRef.current = scene;

    // 创建相机
    const camera = new THREE.PerspectiveCamera(
      45,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(5, 5, 5);
    cameraRef.current = camera;

    // 创建高质量渲染器
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true,
      preserveDrawingBuffer: true, // 必须为true才能录制Canvas内容
      powerPreference: "high-performance"
    });
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // 限制像素比以保持性能
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.shadowMap.autoUpdate = true;
    rendererRef.current = renderer;

    // 创建控制器
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controlsRef.current = controls;

    // 创建基础光照系统（环境光和主光源）
    // 环境光 - 提供基础照明，大幅提高亮度
    const ambientLight = new THREE.AmbientLight(0xffffff, 10.0);
    scene.add(ambientLight);
    ambientLightRef.current = ambientLight;

    // 主光源 - 模拟太阳光，增强阴影效果，大幅提高强度
    const directionalLight = new THREE.DirectionalLight(0xffffff, 10.0);
    directionalLight.position.set(8, 12, 8);
    directionalLight.castShadow = true;
    
    // 高质量阴影设置
    directionalLight.shadow.mapSize.width = 4096; // 提高阴影分辨率
    directionalLight.shadow.mapSize.height = 4096;
    directionalLight.shadow.camera.near = 0.1;
    directionalLight.shadow.camera.far = 100;
    directionalLight.shadow.camera.left = -15;
    directionalLight.shadow.camera.right = 15;
    directionalLight.shadow.camera.top = 15;
    directionalLight.shadow.camera.bottom = -15;
    directionalLight.shadow.bias = -0.0005; // 减少阴影瑕疵
    directionalLight.shadow.normalBias = 0.02; // 减少阴影漏光
    directionalLight.shadow.radius = 2; // 阴影模糊半径
    scene.add(directionalLight);
    directionalLightRef.current = directionalLight;



    // 点光源 - 增加局部高光
    const pointLight1 = new THREE.PointLight(0xffffff, 1.5, 30);
    pointLight1.position.set(5, 8, 5);
    pointLight1.castShadow = true;
    pointLight1.shadow.mapSize.width = 1024;
    pointLight1.shadow.mapSize.height = 1024;
    pointLight1.shadow.camera.near = 0.1;
    pointLight1.shadow.camera.far = 30;
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0xffffff, 1.5, 30);
    pointLight2.position.set(-5, 8, -5);
    pointLight2.castShadow = true;
    pointLight2.shadow.mapSize.width = 1024;
    pointLight2.shadow.mapSize.height = 1024;
    pointLight2.shadow.camera.near = 0.1;
    pointLight2.shadow.camera.far = 30;
    scene.add(pointLight2);

    // 添加地面平面以接收阴影
    const groundGeometry = new THREE.PlaneGeometry(20, 20);
    const groundMaterial = new THREE.ShadowMaterial({ 
      opacity: 0.3,
      transparent: true,
      color: 0x000000
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2; // 水平放置
    ground.position.y = -2; // 稍微降低位置
    ground.receiveShadow = true;
    scene.add(ground);

    // 添加环境贴图以提升真实感
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    
    // 创建明亮的环境贴图来增强金属反射
    const envScene = new THREE.Scene();
    
    // 添加多个光源来创建超明亮的环境
    const envLight1 = new THREE.DirectionalLight(0xffffff, 4.0);
    envLight1.position.set(10, 10, 10);
    envScene.add(envLight1);
    
    const envLight2 = new THREE.DirectionalLight(0xffffff, 3.0);
    envLight2.position.set(-10, 10, -10);
    envScene.add(envLight2);
    
    const envLight3 = new THREE.DirectionalLight(0xffffff, 2.5);
    envLight3.position.set(0, -10, 0);
    envScene.add(envLight3);
    
    const envLight4 = new THREE.DirectionalLight(0xffffff, 2.0);
    envLight4.position.set(0, 10, 0);
    envScene.add(envLight4);
    
    const envLight5 = new THREE.DirectionalLight(0xffffff, 2.0);
    envLight5.position.set(10, 0, 0);
    envScene.add(envLight5);
    
    const envLight6 = new THREE.DirectionalLight(0xffffff, 2.0);
    envLight6.position.set(-10, 0, 0);
    envScene.add(envLight6);
    
    // 添加超强环境光
    const envAmbient = new THREE.AmbientLight(0xffffff, 2.0);
    envScene.add(envAmbient);
    
    const envTexture = pmremGenerator.fromScene(envScene).texture;
    scene.environment = envTexture;
    // 使用画布背景色
    scene.background = new THREE.Color(canvasBackgroundColor);
    
    // 添加网格辅助线（可选）
    const gridHelper = new THREE.GridHelper(20, 20, 0x888888, 0xcccccc);
    gridHelper.material.opacity = 0.2;
    gridHelper.material.transparent = true;
    gridHelper.position.y = -1.99; // 稍微高于地面
    scene.add(gridHelper);

    // 初始化后期处理
    const composer = initializePostProcessing(renderer, scene, camera);
    composerRef.current = composer;

    // 添加到DOM
    if (mountRef.current && !mountRef.current.contains(renderer.domElement)) {
      mountRef.current.appendChild(renderer.domElement);
    }
    
    setIsInitialized(true);

    // 动画循环
    const animationRef = { current: null as number | null };
    
    const animate = () => {
      // 检查组件是否仍然挂载
      if (!cameraRef.current || !controlsRef.current || !rendererRef.current || !sceneRef.current) {
        if (animationRef.current) {
          cancelAnimationFrame(animationRef.current);
        }
        return;
      }
      
      controlsRef.current!.update();
      
      // 使用后期处理渲染
      if (composerRef.current) {
        composerRef.current.render();
      } else {
        rendererRef.current!.render(sceneRef.current!, cameraRef.current!);
      }
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    // 设置全局清理函数
    animationCleanupRef.current = () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };

    // 处理窗口大小变化
    const handleResize = () => {
      if (!mountRef.current || !camera || !renderer) return;
      
      const width = mountRef.current.clientWidth;
      const height = mountRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      setIsInitialized(false);
    };
  }

  // 加载3D模型
  const loadModel = useCallback(async (url: string) => {
    if (!sceneRef.current) return;

    setIsLoading(true);
    setError('');

    try {
      // 验证URL格式
      if (!url || url.trim() === '') {
        throw new Error('URL不能为空');
      }

      // 检查URL格式
      let validUrl = url.trim();
      if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
        validUrl = 'https://' + validUrl;
      }

      console.log('开始加载3D模型:', validUrl);

      const loader = new GLTFLoader();
      loader.setPath('');
      
      // 尝试多种加载策略
      let gltf = null;
      let lastError = null;
      let loadMethod = '';
      
      // 策略1: 直接加载（优先尝试）
      try {
        console.log('策略1: 尝试直接加载...');
        gltf = await loader.loadAsync(validUrl);
        loadMethod = '直接加载';
        console.log('直接加载成功');
      } catch (directError: any) {
        console.warn('直接加载失败:', directError.message);
        lastError = directError;
        
        // 策略2: 使用代理加载（增加超时处理）
        try {
          console.log('策略2: 尝试使用代理加载...');
          const proxyUrl = `/api/proxy?url=${encodeURIComponent(validUrl)}`;
          
          // 对于大文件，添加加载进度提示
          console.log('通过代理加载大文件，请耐心等待...');
          
          // 设置更长的超时时间
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('代理加载超时')), 120000); // 2分钟超时
          });
          
          const loadPromise = loader.loadAsync(proxyUrl);
          gltf = await Promise.race([loadPromise, timeoutPromise]);
          loadMethod = '代理加载';
          console.log('代理加载成功');
        } catch (proxyError: any) {
          console.error('代理加载也失败:', proxyError.message);
          lastError = proxyError;
          
          // 检查是否是大文件超时问题
          if (proxyError.message.includes('timeout') || proxyError.message.includes('500')) {
            console.log('可能是大文件加载超时，尝试增加超时时间...');
          }
          
          // 策略3: 尝试预检请求后直接加载
          try {
            console.log('策略3: 尝试预检请求...');
            const response = await fetch(validUrl, { 
              method: 'HEAD',
              mode: 'cors',
              headers: {
                'Accept': '*/*',
                'User-Agent': 'Mozilla/5.0 (compatible; 3D-Model-Loader/1.0)',
              }
            });
            
            if (!response.ok) {
              throw new Error(`HTTP错误: ${response.status} ${response.statusText}`);
            }
            
            // 检查文件大小
            const contentLength = response.headers.get('Content-Length');
            if (contentLength) {
              const fileSize = parseInt(contentLength, 10);
              console.log(`文件大小: ${(fileSize / 1024 / 1024).toFixed(2)} MB`);
              if (fileSize > 50 * 1024 * 1024) {
                console.warn('文件过大，可能影响加载性能');
              }
            }
            
            // 预检成功，再次尝试直接加载
            gltf = await loader.loadAsync(validUrl);
            loadMethod = '预检后直接加载';
            console.log('预检后直接加载成功');
          } catch (preflightError: any) {
            console.error('预检请求失败:', preflightError.message);
            lastError = preflightError;
            
            // 策略4: 尝试不带CORS模式的fetch
            try {
              console.log('策略4: 尝试不带CORS模式的加载...');
              const response = await fetch(validUrl, { 
                method: 'HEAD',
                mode: 'no-cors',
                headers: {
                  'Accept': '*/*',
                  'User-Agent': 'Mozilla/5.0 (compatible; 3D-Model-Loader/1.0)',
                }
              });
              
              if (response.type === 'opaque') {
                // no-cors模式下无法读取响应，说明存在CORS限制
                console.log('检测到CORS限制，但代理也失败，尝试其他方法...');
                // 不在这里再次尝试代理，因为代理已经失败了
                throw new Error('CORS限制且代理失败');
              } else {
                // no-cors成功，尝试直接加载
                gltf = await loader.loadAsync(validUrl);
                loadMethod = 'no-cors后直接加载';
                console.log('no-cors后直接加载成功');
              }
            } catch (noCorsError: any) {
              console.error('no-cors模式也失败:', noCorsError.message);
              lastError = noCorsError;
              
              // 策略5: 最后的尝试 - 使用不同的User-Agent
              try {
                console.log('策略5: 尝试不同的User-Agent...');
                const response = await fetch(validUrl, { 
                  method: 'HEAD',
                  mode: 'cors',
                  headers: {
                    'Accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                  }
                });
                
                if (response.ok) {
                  gltf = await loader.loadAsync(validUrl);
                  loadMethod = '自定义User-Agent加载';
                  console.log('自定义User-Agent加载成功');
                } else {
                  throw new Error(`HTTP错误: ${response.status} ${response.statusText}`);
                }
              } catch (userAgentError: any) {
                console.error('自定义User-Agent也失败:', userAgentError.message);
                lastError = userAgentError;
              }
            }
          }
        }
      }
      
      if (!gltf) {
        // 分析错误类型并提供具体建议
        let errorMessage = '模型加载失败';
        let suggestions = [];
        
        // 检查是否所有策略都失败了
        const allStrategiesFailed = lastError?.message?.includes('500: Internal Server Error') || 
                                   lastError?.message?.includes('CORS限制且代理失败');
        
        // 检查是否是大文件问题
        const isLargeFile = lastError?.message?.includes('timeout') || 
                           lastError?.message?.includes('大文件') ||
                           lastError?.message?.includes('12.9MB') ||
                           lastError?.message?.includes('12931240');
        
        if (isLargeFile) {
          errorMessage = '大文件加载失败';
          suggestions.push('文件较大（12.9MB），加载可能需要更长时间');
          suggestions.push('请耐心等待，或尝试使用较小的模型文件');
          suggestions.push('检查网络连接是否稳定');
          suggestions.push('考虑使用压缩后的模型文件');
        } else if (allStrategiesFailed) {
          errorMessage = '所有加载策略都失败了';
          suggestions.push('目标服务器可能存在问题');
          suggestions.push('服务器可能已关闭或不可访问');
          suggestions.push('网络连接可能有问题');
          suggestions.push('建议使用其他模型文件');
          suggestions.push('或稍后重试');
        } else if (lastError?.message?.includes('500: Internal Server Error')) {
          errorMessage = '目标服务器内部错误 (500)';
          suggestions.push('目标服务器出现问题');
          suggestions.push('请稍后重试');
          suggestions.push('或联系文件提供方');
          suggestions.push('尝试使用其他模型文件');
        } else if (lastError?.message?.includes('404')) {
          errorMessage = '模型文件不存在 (404)';
          suggestions.push('请检查URL是否正确');
          suggestions.push('确认文件是否已被删除或移动');
          suggestions.push('验证服务器是否正常运行');
        } else if (lastError?.message?.includes('403')) {
          errorMessage = '访问被拒绝 (403)';
          suggestions.push('服务器可能设置了访问限制');
          suggestions.push('可能需要认证或特殊权限');
          suggestions.push('尝试使用其他模型文件');
        } else if (lastError?.message?.includes('CORS') || lastError?.message?.includes('cross-origin')) {
          errorMessage = '跨域访问被阻止 (CORS)';
          suggestions.push('服务器不支持跨域访问');
          suggestions.push('已尝试多种加载策略');
          suggestions.push('建议联系文件提供方启用CORS');
          suggestions.push('或使用支持CORS的模型文件');
        } else if (lastError?.message?.includes('Failed to fetch')) {
          errorMessage = '网络连接失败';
          suggestions.push('请检查网络连接');
          suggestions.push('确认URL可以正常访问');
          suggestions.push('检查防火墙设置');
          suggestions.push('尝试使用其他网络环境');
        } else if (lastError?.message?.includes('timeout')) {
          errorMessage = '请求超时';
          suggestions.push('网络连接较慢，请稍后重试');
          suggestions.push('或检查文件大小是否过大');
          suggestions.push('尝试使用较小的模型文件');
        } else if (lastError?.message?.includes('GLTF')) {
          errorMessage = 'GLTF文件格式错误';
          suggestions.push('请确认文件是有效的GLB/GLTF格式');
          suggestions.push('检查文件是否损坏');
          suggestions.push('尝试使用其他模型文件');
        } else if (lastError?.message?.includes('代理')) {
          errorMessage = '代理服务错误';
          suggestions.push('代理服务可能存在问题');
          suggestions.push('请稍后重试');
          suggestions.push('或尝试直接访问URL');
          suggestions.push('检查网络连接');
        } else {
          errorMessage = '未知加载错误';
          suggestions.push('请检查URL格式是否正确');
          suggestions.push('确认文件格式为GLB/GLTF');
          suggestions.push('尝试使用官方示例模型');
          suggestions.push('检查浏览器控制台获取更多信息');
        }
        
        // 添加具体的错误详情
        let errorDetails = lastError?.message || '未知错误';
        if (isLargeFile) {
          errorDetails = '文件较大（12.9MB），加载超时或内存不足。建议使用较小的模型文件或优化网络环境。';
        } else if (lastError?.message?.includes('500: Internal Server Error')) {
          errorDetails = '目标服务器返回500内部服务器错误，这通常表示服务器端的问题，而不是客户端的问题。';
        } else if (allStrategiesFailed) {
          errorDetails = '所有加载策略（直接加载、代理加载、预检请求、no-cors模式、自定义User-Agent）都失败了，这表明目标服务器或网络环境存在严重问题。';
        }
        
        // 添加推荐的替代方案
        const alternativeModels = [
          'https://threejs.org/examples/models/gltf/DamagedHelmet/glTF/DamagedHelmet.gltf',
          'https://threejs.org/examples/models/gltf/LittlestTokyo.glb',
          'https://threejs.org/examples/models/gltf/RobotExpressive/RobotExpressive.glb'
        ];
        
        throw new Error(`${errorMessage}\n\n已尝试的加载策略:\n• 直接加载\n• 代理加载\n• 预检请求\n• no-cors模式\n• 自定义User-Agent\n\n建议:\n${suggestions.map(s => `• ${s}`).join('\n')}\n\n推荐替代模型:\n${alternativeModels.map(url => `• ${url}`).join('\n')}\n\n技术详情: ${errorDetails}`);
      }
      
      console.log(`模型加载成功 (${loadMethod}):`, validUrl);
      
      // 移除旧模型
      if (modelRef.current) {
        sceneRef.current.remove(modelRef.current);
      }

      // 添加新模型
      const model = (gltf as GLTF).scene;
      modelRef.current = model;

      // 为模型创建跟随光源系统
      createModelFollowingLights(model);

      // 优化模型材质和阴影，并保存原始位置用于爆炸图
      originalPositionsRef.current.clear();
      decomposedMeshesRef.current = []; // 清理解析后的网格
      
      model.traverse((child: THREE.Object3D) => {
        if (child instanceof THREE.Mesh) {
          // 检查几何体是否有效
          if (child.geometry && child.geometry.attributes.position && child.geometry.attributes.position.count > 0) {
            // 保存原始位置用于爆炸图
            originalPositionsRef.current.set(child, child.position.clone());
            
            // 启用阴影 - 增强立体感
            child.castShadow = true;
            child.receiveShadow = true;
          }
        } else if (child instanceof THREE.InstancedMesh) {
          // 处理实例化网格
          if (child.geometry && child.geometry.attributes.position && child.geometry.attributes.position.count > 0) {
            originalPositionsRef.current.set(child, child.position.clone());
            child.castShadow = true;
            child.receiveShadow = true;
          }
        }
      });
      
      // 重新遍历处理材质
      model.traverse((child: THREE.Object3D) => {
        if (child instanceof THREE.Mesh) {
          // 启用阴影 - 增强立体感
          child.castShadow = true;
          child.receiveShadow = true;
          
          // 优化材质
          if (child.material) {
            // 如果是数组材质
            if (Array.isArray(child.material)) {
              child.material.forEach(mat => {
                if (mat) {
                  mat.needsUpdate = true;
                  mat.envMapIntensity = 1.2; // 大幅增加环境反射
                  mat.roughness = Math.min(mat.roughness || 0.3, 0.4); // 降低粗糙度，增加光泽
                  mat.metalness = Math.max(mat.metalness || 0.0, 0.8); // 大幅增加金属感
                  
                  // 添加阴影接收设置
                  if (mat.transparent) {
                    mat.alphaTest = 0.1; // 减少透明材质的阴影问题
                  }
                }
              });
            } else {
              // 单个材质
              child.material.needsUpdate = true;
              child.material.envMapIntensity = 1.2; // 大幅增加环境反射
              child.material.roughness = Math.min(child.material.roughness || 0.3, 0.4); // 降低粗糙度，增加光泽
              child.material.metalness = Math.max(child.material.metalness || 0.0, 0.8); // 大幅增加金属感
              
              // 添加阴影接收设置
              if (child.material.transparent) {
                child.material.alphaTest = 0.1; // 减少透明材质的阴影问题
              }
            }
          }
        }
      });

      // 自动调整模型大小和位置
      const box = new THREE.Box3().setFromObject(model);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      const maxDim = Math.max(size.x, size.y, size.z);
      const scale = 2 / maxDim;
      
      model.scale.setScalar(scale);
      model.position.sub(center.multiplyScalar(scale));
      
      // 确保模型在地面之上，以便投射阴影
      const modelBox = new THREE.Box3().setFromObject(model);
      const modelBottom = modelBox.min.y;
      if (modelBottom < 0) {
        model.position.y -= modelBottom;
      }
      
      sceneRef.current.add(model);
      
      // 调整相机位置以更好地观察阴影
      if (cameraRef.current) {
        cameraRef.current.position.set(4, 4, 4);
        cameraRef.current.lookAt(0, 0, 0);
      }
      
      // 强制更新阴影
      if (rendererRef.current) {
        rendererRef.current.shadowMap.needsUpdate = true;
      }

    } catch (err: any) {
      console.error('Model loading error:', err);
      
      // 根据错误类型提供更具体的错误信息
      if (err.message?.includes('Failed to fetch')) {
        setError('网络请求失败，可能是CORS跨域问题。请确保：\n1. URL可以正常访问\n2. 服务器支持CORS\n3. 使用HTTPS协议');
      } else if (err.message?.includes('404')) {
        setError('模型文件不存在或URL错误。请检查：\n1. URL是否正确\n2. 文件是否存在\n3. 服务器是否正常运行');
      } else if (err.message?.includes('HTTP错误')) {
        setError(`HTTP错误: ${err.message}`);
      } else if (err.message?.includes('URL不能为空')) {
        setError('请输入有效的URL地址');
      } else if (err.message?.includes('模型加载失败: 直接访问和代理访问都失败')) {
        setError('模型加载失败，可能的原因：\n1. 网络连接问题\n2. 服务器不支持CORS\n3. 文件格式不支持\n4. URL地址错误');
      } else {
        setError(`模型加载失败: ${err.message || '未知错误'}`);
      }
    } finally {
      setIsLoading(false);
    }
  }, []);


  // 应用环境预设
  const applyEnvironmentPreset = useCallback((presetId: string) => {
    const preset = environmentPresets.find(p => p.id === presetId);
    if (!preset || !ambientLightRef.current || !directionalLightRef.current) return;

    ambientLightRef.current.intensity = preset.ambientIntensity;
    ambientLightRef.current.color.setHex(parseInt(preset.ambientColor.replace('#', ''), 16));
    
    directionalLightRef.current.intensity = preset.directionalIntensity;
    directionalLightRef.current.color.setHex(parseInt(preset.directionalColor.replace('#', ''), 16));
  }, []);



  // 初始化场景
  useEffect(() => {
    // 先清理之前的场景
    if (animationCleanupRef.current) {
      animationCleanupRef.current();
      animationCleanupRef.current = null;
    }
    
    if (mountRef.current) {
      mountRef.current.innerHTML = '';
    }
    
    const cleanup = initScene();
    
    // 组件卸载时的清理
    return () => {
      if (cleanup) cleanup();
      if (animationCleanupRef.current) {
        animationCleanupRef.current();
        animationCleanupRef.current = null;
      }
      if (mountRef.current) {
        mountRef.current.innerHTML = '';
      }
      setIsInitialized(false);
    };
  }, []);

  // 使用 ref 来缓存当前的 modelUrl，避免重复加载
  const previousModelUrlRef = useRef<string | undefined>();
  
  // 加载模型
  useEffect(() => {
    const currentModelUrl = data?.modelUrl;
    
    // 只有当 modelUrl 真正改变时才重新加载模型
    if (currentModelUrl && currentModelUrl !== previousModelUrlRef.current) {
      previousModelUrlRef.current = currentModelUrl;
      loadModel(currentModelUrl);
    }
  }, [data?.modelUrl]); // 移除 loadModel 依赖，避免循环

  // 应用环境预设
  useEffect(() => {
    if (data?.environmentPreset && ambientLightRef.current && directionalLightRef.current) {
      const preset = environmentPresets.find(p => p.id === data.environmentPreset);
      if (preset) {
        ambientLightRef.current.intensity = preset.ambientIntensity;
        ambientLightRef.current.color.setHex(parseInt(preset.ambientColor.replace('#', ''), 16));
        
        directionalLightRef.current.intensity = preset.directionalIntensity;
        directionalLightRef.current.color.setHex(parseInt(preset.directionalColor.replace('#', ''), 16));
      }
    }
  }, [data?.environmentPreset]);

  // 响应环境光强度变化
  useEffect(() => {
    if (data?.ambientIntensity !== undefined && ambientLightRef.current) {
      ambientLightRef.current.intensity = data.ambientIntensity;
    }
  }, [data?.ambientIntensity]);

  // 响应环境光颜色变化
  useEffect(() => {
    if (data?.ambientColor && ambientLightRef.current) {
      ambientLightRef.current.color.setHex(parseInt(data.ambientColor.replace('#', ''), 16));
    }
  }, [data?.ambientColor]);

  // 响应方向光强度变化
  useEffect(() => {
    if (data?.directionalIntensity !== undefined && directionalLightRef.current) {
      directionalLightRef.current.intensity = data.directionalIntensity;
    }
  }, [data?.directionalIntensity]);

  // 响应方向光颜色变化
  useEffect(() => {
    if (data?.directionalColor && directionalLightRef.current) {
      directionalLightRef.current.color.setHex(parseInt(data.directionalColor.replace('#', ''), 16));
    }
  }, [data?.directionalColor]);

  // 响应爆炸图设置变化
  useEffect(() => {
    if (data?.explodeEnabled === false && isExploded) {
      // 关闭爆炸图时恢复模型
      restoreModel();
    }
    // 移除自动播放爆炸动画的逻辑，只在用户主动点击爆炸按钮时播放
  }, [data?.explodeEnabled, restoreModel, isExploded]);

  // 响应恢复模型标记
  useEffect(() => {
    if (data?.restoreModel === true && isExploded) {
      // 恢复模型位置，但保持爆炸图功能开启
      restoreModel();
      // 清除恢复标记
      if (onDataChange) {
        onDataChange({
          ...data,
          restoreModel: false
        });
      }
    }
  }, [data?.restoreModel, isExploded, restoreModel, onDataChange]); // 移除data依赖，避免无限循环

  // 响应爆炸按钮点击
  useEffect(() => {
    if (data?.triggerExplode === true && data?.explodeEnabled === true && data?.explodeIntensity !== undefined) {
      // 用户主动点击爆炸按钮，播放爆炸动画
      explodeModel(data.explodeIntensity);
      // 清除爆炸标记
      if (onDataChange) {
        onDataChange({
          ...data,
          triggerExplode: false
        });
      }
    }
  }, [data?.triggerExplode, data?.explodeEnabled, data?.explodeIntensity, explodeModel, onDataChange]); // 移除data依赖，避免无限循环

  // 响应演示模式事件
  useEffect(() => {
    const handlePresentationViewAnimation = (event: CustomEvent) => {
      // 检查是否是当前组件 - 通过元素ID来精确匹配
      if (event.detail?.elementId === elementId && data?.modelUrl && data?.viewPresets && data.viewPresets.length > 0) {
        console.log('演示模式：开始视角动画', event.detail.elementId, '当前组件ID:', elementId);
        // 开始视角动画
        startViewAnimation();
      }
    };

    const handlePresentationExplodeAnimation = (event: CustomEvent) => {
      // 检查是否是当前组件
      if (event.detail?.elementId === elementId && data?.modelUrl && data?.explodeEnabled && data?.explodeIntensity !== undefined) {
        console.log('演示模式：开始爆炸动画', event.detail.elementId, '当前组件ID:', elementId);
        // 播放爆炸动画
        explodeModel(data.explodeIntensity);
      }
    };

    const handlePresentationRestoreModel = (event: CustomEvent) => {
      // 检查是否是当前组件
      if (event.detail?.elementId === elementId && data?.modelUrl && isExploded) {
        console.log('演示模式：恢复模型', event.detail.elementId, '当前组件ID:', elementId);
        // 恢复模型
        restoreModel();
      }
    };

    const handlePresentationStopAnimation = (event: CustomEvent) => {
      // 检查是否是当前组件
      if (event.detail?.elementId === elementId && data?.modelUrl) {
        console.log('演示模式：停止动画', event.detail.elementId, '当前组件ID:', elementId);
        
        // 立即停止所有动画
        stopViewAnimation();
        
        // 如果模型处于爆炸状态，立即恢复
        if (isExploded) {
          console.log('演示模式：恢复爆炸的模型到初始状态');
          restoreModel(true); // 立即恢复，不使用动画
        }
        
        // 强制停止所有正在进行的动画
        if (explodeAnimationRef.current) {
          cancelAnimationFrame(explodeAnimationRef.current);
          explodeAnimationRef.current = null;
        }
        
        // 清理动画清理函数
        if (animationCleanupRef.current) {
          animationCleanupRef.current();
          animationCleanupRef.current = null;
        }
        
        console.log('演示模式：组件动画已完全停止');
      }
    };

    // 添加事件监听器
    window.addEventListener('presentation-view-animation', handlePresentationViewAnimation as EventListener);
    window.addEventListener('presentation-explode-animation', handlePresentationExplodeAnimation as EventListener);
    window.addEventListener('presentation-restore-model', handlePresentationRestoreModel as EventListener);
    window.addEventListener('presentation-stop-animation', handlePresentationStopAnimation as EventListener);

    // 清理事件监听器
    return () => {
      window.removeEventListener('presentation-view-animation', handlePresentationViewAnimation as EventListener);
      window.removeEventListener('presentation-explode-animation', handlePresentationExplodeAnimation as EventListener);
      window.removeEventListener('presentation-restore-model', handlePresentationRestoreModel as EventListener);
      window.removeEventListener('presentation-stop-animation', handlePresentationStopAnimation as EventListener);
    };
  }, [elementId, data?.modelUrl, data?.viewPresets, data?.explodeEnabled, data?.explodeIntensity, isExploded, explodeModel, restoreModel, startViewAnimation, stopViewAnimation]);

  // 响应画布背景色变化
  useEffect(() => {
    if (sceneRef.current && canvasBackgroundColor) {
      sceneRef.current.background = new THREE.Color(canvasBackgroundColor);
    }
  }, [canvasBackgroundColor]);

  // 后期处理实时更新 - 使用防抖机制避免无限循环
  const lastPostProcessingHashRef = useRef<string>('');
  const updateTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    if (!isInitialized) return;
    
    // 创建设置的哈希值来比较是否有变化
    const currentHash = JSON.stringify(postProcessing);
    
    if (currentHash !== lastPostProcessingHashRef.current) {
      lastPostProcessingHashRef.current = currentHash;
      
      // 清除之前的定时器
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
      
      // 使用防抖机制，延迟100ms执行更新
      updateTimeoutRef.current = setTimeout(() => {
        requestAnimationFrame(() => {
          updatePostProcessingSafe();
        });
      }, 100);
    }
    
    // 清理函数
    return () => {
      if (updateTimeoutRef.current) {
        clearTimeout(updateTimeoutRef.current);
      }
    };
  }, [postProcessing, isInitialized]);



  // 应用视角预设 - 使用平滑动画
  useEffect(() => {
    if (data?.currentView && data?.viewPresets && cameraRef.current && controlsRef.current) {
      const preset = data.viewPresets.find(p => p.id === data.currentView);
      if (preset) {
        // 使用平滑动画切换到目标视角
        const camera = cameraRef.current;
        const controls = controlsRef.current;
        
        // 平滑切换到目标视角
        const duration = 2000; // 2秒
        const startTime = Date.now();
        const startPosition = camera.position.clone();
        const startRotation = camera.rotation.clone();
        const startFov = camera.fov;
        const startTarget = controls.target.clone();
        
        const targetPosition = new THREE.Vector3(preset.position.x, preset.position.y, preset.position.z);
        const targetRotation = new THREE.Euler(preset.rotation.x, preset.rotation.y, preset.rotation.z);
        const targetFov = preset.fov;
        const targetTarget = preset.target ? new THREE.Vector3(preset.target.x, preset.target.y, preset.target.z) : new THREE.Vector3(0, 0, 0);
        
        // 使用 ref 来跟踪动画状态，以便在组件卸载时清理
        const animationRef = { current: null as number | null };
        
        const animate = () => {
          // 检查组件是否仍然挂载
          if (!cameraRef.current || !controlsRef.current) {
            if (animationRef.current) {
              cancelAnimationFrame(animationRef.current);
            }
            return;
          }
          
          const elapsed = Date.now() - startTime;
          const progress = Math.min(elapsed / duration, 1);
          
          // 使用更平滑的缓动函数 (easeInOutCubic)
          const easeProgress = progress < 0.5 
            ? 4 * progress * progress * progress 
            : 1 - Math.pow(-2 * progress + 2, 3) / 2;
          
          // 插值位置
          camera.position.lerpVectors(startPosition, targetPosition, easeProgress);
          
          // 插值旋转
          camera.rotation.x = startRotation.x + (targetRotation.x - startRotation.x) * easeProgress;
          camera.rotation.y = startRotation.y + (targetRotation.y - startRotation.y) * easeProgress;
          camera.rotation.z = startRotation.z + (targetRotation.z - startRotation.z) * easeProgress;
          
          // 插值FOV
          camera.fov = startFov + (targetFov - startFov) * easeProgress;
          camera.updateProjectionMatrix();
          
          // 插值目标点
          controls.target.lerpVectors(startTarget, targetTarget, easeProgress);
          controls.update();
          
          if (progress < 1) {
            animationRef.current = requestAnimationFrame(animate);
          } else {
            animationRef.current = null;
          }
        };
        
        animate();
        
        // 设置全局清理函数
        const cleanup = () => {
          if (animationRef.current) {
            cancelAnimationFrame(animationRef.current);
            animationRef.current = null;
          }
        };
        
        // 返回清理函数
        return cleanup;
      }
    }
  }, [data?.currentView, data?.viewPresets]);

  // 响应缩放和尺寸变化
  useEffect(() => {
    if (mountRef.current && rendererRef.current && cameraRef.current) {
      // 使用传入的尺寸，如果没有则使用容器尺寸
      const containerWidth = width || mountRef.current.clientWidth;
      const containerHeight = height || mountRef.current.clientHeight;
      
      // 根据缩放比例调整渲染器大小
      const scaledWidth = containerWidth * (zoom / 100);
      const scaledHeight = containerHeight * (zoom / 100);
      
      rendererRef.current.setSize(scaledWidth, scaledHeight);
      cameraRef.current.aspect = scaledWidth / scaledHeight;
      cameraRef.current.updateProjectionMatrix();
    }
  }, [zoom, width, height]);

  return (
    <div className="w-full h-full">
      {/* 3D渲染区域 */}
      <div className="w-full h-full relative">
        <div 
          ref={mountRef} 
          className="w-full h-full" 
          onContextMenu={handleContextMenu}
        />
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <div className="text-white">加载中...</div>
          </div>
        )}
        {error && (
          <div className="absolute top-4 left-4 right-4 bg-red-500 text-white p-4 rounded-lg shadow-lg">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-semibold mb-2">模型加载失败</h3>
                <p className="text-sm mb-2">{error.split('\n')[0]}</p>
                <button
                  onClick={() => setShowErrorDetails(!showErrorDetails)}
                  className="text-xs underline hover:no-underline"
                >
                  {showErrorDetails ? '隐藏详情' : '显示详情'}
                </button>
                {showErrorDetails && (
                  <div className="mt-2 text-xs bg-red-600 p-2 rounded whitespace-pre-line">
            {error}
                  </div>
                )}
              </div>
              <button
                onClick={() => setError('')}
                className="text-white hover:text-gray-300 ml-2"
              >
                ✕
              </button>
            </div>
          </div>
        )}


        


       

      </div>

      {/* 创建视角对话框 */}
      <Dialog open={showViewDialog} onOpenChange={setShowViewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-blue-600" />
              创建新视角
            </DialogTitle>
            <DialogDescription>
              保存当前相机位置和角度作为新的视角预设
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="view-name" className="text-sm font-medium">
                视角名称 *
              </Label>
              <Input
                id="view-name"
                placeholder="例如：正面视角、侧面视角、俯视角度..."
                value={newViewName}
                onChange={(e) => setNewViewName(e.target.value)}
                className="mt-1"
                autoFocus
              />
            </div>
            
            <div>
              <Label htmlFor="view-description" className="text-sm font-medium">
                描述（可选）
              </Label>
              <Input
                id="view-description"
                placeholder="添加视角的详细描述..."
                value={newViewDescription}
                onChange={(e) => setNewViewDescription(e.target.value)}
                className="mt-1"
              />
            </div>
            
            {/* 当前相机信息预览 */}
            <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg">
              <h4 className="text-sm font-medium mb-2">当前相机状态</h4>
              <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 dark:text-gray-400">
                <div>
                  <span className="font-medium">位置:</span>
                  <div className="ml-2">
                    X: {cameraRef.current?.position.x.toFixed(2) || '0.00'}
                  </div>
                  <div className="ml-2">
                    Y: {cameraRef.current?.position.y.toFixed(2) || '0.00'}
                  </div>
                  <div className="ml-2">
                    Z: {cameraRef.current?.position.z.toFixed(2) || '0.00'}
                  </div>
                </div>
                <div>
                  <span className="font-medium">FOV:</span>
                  <div className="ml-2">
                    {cameraRef.current?.fov.toFixed(1) || '45.0'}°
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={cancelCreateView}>
              取消
            </Button>
            <Button 
              onClick={createView}
              disabled={!newViewName.trim()}
            >
              <Save className="w-4 h-4 mr-2" />
              保存视角
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* FFmpeg录屏对话框 */}
      <ThreeDVideoRecorder
        canvasRef={rendererRef}
        isOpen={showVideoRecorder}
        onClose={() => setShowVideoRecorder(false)}
      />
    </div>
  );
}
