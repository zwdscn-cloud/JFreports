import { useCallback } from 'react'
import { soundManager, SoundType, playSound } from '@/lib/sound-effects'

// 音效Hook
export const useSound = () => {
  // 播放按钮点击音效
  const playButtonClick = useCallback(() => {
    playSound(SoundType.BUTTON_CLICK)
  }, [])

  // 播放菜单点击音效
  const playMenuClick = useCallback(() => {
    playSound(SoundType.MENU_CLICK)
  }, [])

  // 播放成功音效
  const playSuccess = useCallback(() => {
    playSound(SoundType.SUCCESS)
  }, [])

  // 播放错误音效
  const playError = useCallback(() => {
    playSound(SoundType.ERROR)
  }, [])

  // 播放悬停音效
  const playHover = useCallback(() => {
    playSound(SoundType.HOVER)
  }, [])

  // 播放特殊音效
  const playSpecial = useCallback(() => {
    playSound(SoundType.SPECIAL)
  }, [])

  // 设置音效开关
  const setSoundEnabled = useCallback((enabled: boolean) => {
    soundManager.setEnabled(enabled)
  }, [])

  // 设置音量
  const setVolume = useCallback((volume: number) => {
    soundManager.setVolume(volume)
  }, [])

  return {
    playButtonClick,
    playMenuClick,
    playSuccess,
    playError,
    playHover,
    playSpecial,
    setSoundEnabled,
    setVolume
  }
}
