"use client"

import { useEffect, useRef, useState } from "react"
import { getThemeById, applyThemeToChart } from "@/lib/color-themes"

interface TreeNode {
  name: string
  children?: TreeNode[]
  value?: number
  id?: string
}

interface TreeChartProps {
  data?: TreeNode[] | TreeNode
  width?: number
  height?: number
  colors?: string[]
  title?: string
  themeId?: string
  transparent?: boolean
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

// 默认数据 - 使用简单的数组格式
const defaultData: TreeNode[] = [
  {
    id: "root",
    name: "公司组织",
    value: 1000,
    children: [
      {
        id: "dept1",
        name: "技术部",
        value: 400,
        children: [
          { id: "team1", name: "前端团队", value: 150 },
          { id: "team2", name: "后端团队", value: 200 },
          { id: "team3", name: "测试团队", value: 50 }
        ]
      },
      {
        id: "dept2",
        name: "产品部",
        value: 300,
        children: [
          { id: "team4", name: "产品设计", value: 100 },
          { id: "team5", name: "用户体验", value: 200 }
        ]
      },
      {
        id: "dept3",
        name: "运营部",
        value: 300,
        children: [
          { id: "team6", name: "市场推广", value: 150 },
          { id: "team7", name: "客户服务", value: 150 }
        ]
      }
    ]
  }
]

export function TreeChart({
  data = defaultData,
  width = 400,
  height = 300,
  colors,
  title = "树图",
  themeId = "DA001",
  transparent = false,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: TreeChartProps) {
  const theme = getThemeById(themeId)
  const chartColors = colors || (theme ? applyThemeToChart(theme, "tree") : ["#5470c6", "#91cc75", "#fac858", "#ee6666", "#73c0de", "#3ba272"]) as string[]
  
  // 处理数据格式 - 支持数组或单个对象
  const treeData = Array.isArray(data) ? data[0] : data
  
  // 计算节点所需的最小宽度
  const calculateNodeWidth = (node: TreeNode): number => {
    if (!node.children || node.children.length === 0) {
      return 120 // 叶子节点宽度
    }
    
    const childrenWidth = node.children.reduce((total, child) => total + calculateNodeWidth(child), 0)
    const minSpacing = 20
    return Math.max(120, childrenWidth + (node.children.length - 1) * minSpacing)
  }
  
  // 计算树图的层级信息
  const calculateTreeLevels = (node: TreeNode, level: number = 0, levels: TreeNode[][] = []): TreeNode[][] => {
    if (!levels[level]) levels[level] = []
    levels[level].push(node)
    
    if (node.children) {
      node.children.forEach(child => calculateTreeLevels(child, level + 1, levels))
    }
    
    return levels
  }
  
  // 计算整个树图所需的最小宽度和高度
  const calculateTreeDimensions = () => {
    if (!treeData) return { width: 400, height: 300 }
    
    // 获取树的所有层级
    const levels = calculateTreeLevels(treeData)
    
    // 找到节点数最多的层级
    const maxNodesInLevel = Math.max(...levels.map(level => level.length))
    
    // 基本参数
    const nodeWidth = 120 // 节点宽度
    const nodeHeight = 40 // 节点高度
    const minNodeSpacing = 40 // 节点之间的最小间距
    const levelSpacing = 60 // 层级之间的间距
    const horizontalPadding = 60 // 左右边距
    const verticalPadding = 40 // 上下边距
    
    // 计算每层所需的宽度
    const levelWidths = levels.map(nodes => 
      nodes.length * nodeWidth + (nodes.length - 1) * minNodeSpacing
    )
    
    // 找到最宽的层级宽度
    const maxLevelWidth = Math.max(...levelWidths)
    
    // 计算总宽度和高度
    const totalWidth = maxLevelWidth + (horizontalPadding * 2)
    const totalHeight = (levels.length * nodeHeight) + 
                       ((levels.length - 1) * levelSpacing) + 
                       (verticalPadding * 2)
    
    // 确保宽度至少是高度的1.5倍，这样树图看起来更协调
    const minWidth = Math.max(totalHeight * 1.5, 800)
    
    // 在计算的宽度基础上增加300px的额外空间
    const extraWidth = 300
    const finalWidth = Math.max(totalWidth, minWidth) + extraWidth
    
    console.log("Tree dimensions calculation:", {
      levels,
      maxNodesInLevel,
      levelWidths,
      maxLevelWidth,
      totalWidth,
      totalHeight,
      minWidth,
      finalWidth
    })
    
    return {
      width: finalWidth,
      height: Math.max(totalHeight, 300)
    }
  }
  
  const { width: treeWidth, height: treeHeight } = calculateTreeDimensions()
  
  // 添加调试信息
  console.log("TreeChart render:", { 
    data, 
    treeData, 
    width, 
    height, 
    title, 
    treeWidth, 
    treeHeight,
    calculatedWidth: treeWidth,
    originalWidth: width
  })

  const containerClasses = [
    "w-full h-full",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-4"
  ].filter(Boolean).join(" ")

  // 渲染函数
  const renderTree = () => {
    if (!treeData) return null
    
    const levels = calculateTreeLevels(treeData)
    const nodeWidth = 120
    const nodeHeight = 40
    const minNodeSpacing = 40
    const levelSpacing = 60
    
    // 计算每层节点的位置
    const calculateLevelPositions = () => {
      return levels.map((nodes, level) => {
        // 计算这一层所有节点加间距的总宽度
        const levelWidth = nodes.length * nodeWidth + (nodes.length - 1) * minNodeSpacing
        // 计算这一层的起始x坐标（居中）
        const startX = (width - levelWidth) / 2
        
        return nodes.map((node, index) => {
          const x = startX + index * (nodeWidth + minNodeSpacing) + nodeWidth/2
          const y = 60 + level * (nodeHeight + levelSpacing)
          return { node, x, y }
        })
      })
    }
    
    const nodePositions = calculateLevelPositions()
    
    // 渲染单个节点
    const renderNode = (node: TreeNode, x: number, y: number, level: number) => {
      const nodeColor = chartColors[level % chartColors.length]
      
      return (
        <g key={node.id || `${level}-${x}`}>
          {/* 节点矩形 */}
          <rect
            x={x - nodeWidth/2}
            y={y - nodeHeight/2}
            width={nodeWidth}
            height={nodeHeight}
            rx={6}
            ry={6}
            fill="rgba(255,255,255,0.9)"
            stroke={nodeColor}
            strokeWidth={2}
          />
          
          {/* 节点标签 */}
          <text
            x={x}
            y={y}
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize={chartFontSize || 12}
            fill={chartTextColor || textColors?.label || "#333333"}
            fontWeight="500"
          >
            {node.name}
          </text>
          
          {/* 节点值 */}
          {node.value && (
            <text
              x={x}
              y={y + 15}
              textAnchor="middle"
              fontSize={Math.max(10, (chartFontSize || 12) * 0.8)}
              fill={chartTextColor || textColors?.label || "#666666"}
            >
              {node.value}
            </text>
          )}
        </g>
      )
    }
    
    // 渲染连接线
    const renderConnections = () => {
      const connections: React.ReactElement[] = []
      
      nodePositions.forEach((levelNodes, level) => {
        if (level === 0) return // 跳过根节点
        
        levelNodes.forEach(({ node, x, y }) => {
          // 找到父节点位置
          const parentLevel = nodePositions[level - 1]
          const parentPos = parentLevel.find(p => 
            p.node.children?.some(child => child.id === node.id)
          )
          
          if (parentPos) {
            connections.push(
              <line
                key={`${parentPos.node.id}-${node.id}`}
                x1={parentPos.x}
                y1={parentPos.y + nodeHeight/2}
                x2={x}
                y2={y - nodeHeight/2}
                stroke={chartTextColor || textColors?.label || "#999999"}
                strokeWidth={2}
                opacity={0.6}
              />
            )
          }
        })
      })
      
      return connections
    }
    
    // 渲染所有节点
    const renderNodes = () => {
      return nodePositions.map((levelNodes, level) => 
        levelNodes.map(({ node, x, y }) => renderNode(node, x, y, level))
      )
    }
    
    return (
      <g>
        {renderConnections()}
        {renderNodes()}
      </g>
    )
  }

  return (
    <div className={containerClasses}>
      {title && !transparent && (
        <div className="mb-2">
          <h3 
            className="font-semibold tracking-tight drop-shadow-sm"
            style={{ 
              fontSize: `${titleFontSize || 14}px`,
              color: titleTextColor || textColors?.title || (transparent ? "#ffffff" : "#333333")
            }}
          >
            {title}
          </h3>
        </div>
      )}
      
      <div className="h-full w-full relative" style={{ width: `${treeWidth}px`, height: `${treeHeight}px` }}>
        {!treeData ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <div className="text-sm mb-2" style={{ color: chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#666666") }}>
                暂无数据
              </div>
              <div className="text-xs" style={{ color: chartTextColor || textColors?.label || (transparent ? "#ffffff" : "#999999") }}>
                请在属性面板中添加树状数据
              </div>
            </div>
          </div>
        ) : (
          <svg
            width={treeWidth}
            height={treeHeight}
            viewBox={`0 0 ${treeWidth} ${treeHeight}`}
            className="absolute inset-0"
            style={{ overflow: 'visible' }}
          >
            {renderTree()}
          </svg>
        )}
      </div>
    </div>
  )
}