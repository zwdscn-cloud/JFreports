"use client"

import {
  RadarChart as RechartsRadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  ResponsiveContainer,
  Legend,
  Tooltip
} from "recharts"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface RadarChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  showLegend?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  textColors?: {
    title?: string
    axis?: string
    legend?: string
    tooltip?: string
    chart?: string
    grid?: string
  }
  titleFontSize?: number
  axisFontSize?: number
  legendFontSize?: number
  tooltipFontSize?: number
  chartFontSize?: number
  titleTextColor?: string
  axisTextColor?: string
  legendTextColor?: string
  tooltipTextColor?: string
  chartTextColor?: string
  gridColor?: string
  scale?: number // 缩放比例，默认为1
}

export function RadarChart({
  data,
  title,
  showLegend = true,
  showTooltip = true,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  textColors,
  titleFontSize = 16,
  axisFontSize = 12,
  legendFontSize = 12,
  tooltipFontSize = 12,
  chartFontSize = 12,
  titleTextColor,
  axisTextColor,
  legendTextColor,
  tooltipTextColor,
  chartTextColor,
  gridColor,
  scale = 1
}: RadarChartProps) {
  const { playHover } = useSound()
  
  // 转换数据格式以适应 Recharts
  const formattedData = data.map(item => ({
    subject: item.name,
    A: item.value,
    fullMark: 100
  }))

  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  // 计算缩放后的字体大小
  const scaledTitleFontSize = titleFontSize * scale
  const scaledAxisFontSize = axisFontSize * scale
  const scaledLegendFontSize = legendFontSize * scale

  // 确定颜色
  const titleColor = titleTextColor || textColors?.title || (transparent ? "#fff" : "#333")
  const axisColor = axisTextColor || textColors?.axis || (transparent ? "#fff" : "#666")
  const legendColor = legendTextColor || textColors?.legend || (transparent ? "#fff" : "#333")
  const radarColor = colors?.[0] || "#8884d8"
  // 让所有线条颜色与坐标轴字体颜色一致
  const lineColor = axisColor

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            fontSize: `${scaledTitleFontSize}px`,
            color: titleColor
          }}
        >
          {title}
        </div>
      )}
      <div className="flex items-center justify-center w-full h-full relative">
        <ResponsiveContainer width="100%" height="100%">
          <RechartsRadarChart 
            cx="50%" 
            cy="50%" 
            outerRadius={transparent ? "90%" : "80%"} 
            data={formattedData}
            margin={transparent ? { top: 5, right: 5, bottom: 5, left: 5 } : { top: 20, right: 20, bottom: 20, left: 20 }}
          >
          <PolarGrid stroke={lineColor} />
          <PolarAngleAxis
            dataKey="subject"
            tick={{ 
              fill: axisColor, 
              fontSize: scaledAxisFontSize 
            }}
          />
          <PolarRadiusAxis
            angle={30}
            domain={[0, 100]}
            tick={{ 
              fill: axisColor, 
              fontSize: scaledAxisFontSize 
            }}
          />
          <Radar
            name="数值"
            dataKey="A"
            stroke={lineColor}
            fill={radarColor}
            fillOpacity={0.2}
            strokeWidth={2.5}
            strokeOpacity={1}
          />
          {showTooltip && (
            <Tooltip 
              contentStyle={{
                fontSize: `${tooltipFontSize * scale}px`,
                color: tooltipTextColor || textColors?.tooltip || "#333"
              }}
            />
          )}
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontSize: `${scaledLegendFontSize}px`,
                color: legendColor,
              }}
            />
          )}
          </RechartsRadarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}