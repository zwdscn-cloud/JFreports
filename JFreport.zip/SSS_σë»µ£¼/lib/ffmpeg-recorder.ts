import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';

export interface RecordingOptions {
  width: number;
  height: number;
  frameRate: number;
  duration: number;
  quality: 'low' | 'medium' | 'high';
}

export interface FrameData {
  data: Uint8Array;
  timestamp: number;
}

export class FFmpegRecorder {
  private ffmpeg: FFmpeg;
  private isLoaded: boolean = false;
  private frames: FrameData[] = [];
  private recording: boolean = false;
  private startTime: number = 0;

  constructor() {
    this.ffmpeg = new FFmpeg();
  }

  async initialize(): Promise<void> {
    if (this.isLoaded) return;

    try {
      // 加载FFmpeg核心文件
      const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
      await this.ffmpeg.load({
        coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
        wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
      });
      
      this.isLoaded = true;
      console.log('FFmpeg loaded successfully');
    } catch (error) {
      console.error('Failed to load FFmpeg:', error);
      throw error;
    }
  }

  startRecording(): void {
    if (!this.isLoaded) {
      throw new Error('FFmpeg not initialized');
    }
    
    this.frames = [];
    this.recording = true;
    this.startTime = performance.now();
    console.log('Recording started');
  }

  addFrame(canvas: HTMLCanvasElement): void {
    if (!this.recording) return;

    try {
      // 将canvas转换为图像数据
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const timestamp = performance.now() - this.startTime;

      this.frames.push({
        data: new Uint8Array(imageData.data),
        timestamp
      });
    } catch (error) {
      console.error('Failed to add frame:', error);
    }
  }

  async stopRecording(options: RecordingOptions): Promise<Blob> {
    if (!this.recording) {
      throw new Error('No recording in progress');
    }

    this.recording = false;
    console.log(`Stopping recording with ${this.frames.length} frames`);

    try {
      // 创建临时目录
      await this.ffmpeg.writeDir('/tmp');

      // 将帧数据写入文件
      for (let i = 0; i < this.frames.length; i++) {
        const frame = this.frames[i];
        const filename = `/tmp/frame_${i.toString().padStart(6, '0')}.png`;
        
        // 创建PNG数据
        const pngData = await this.createPNGFromImageData(frame.data, options.width, options.height);
        await this.ffmpeg.writeFile(filename, pngData);
      }

      // 设置输出文件名
      const outputFile = '/tmp/output.mp4';
      
      // 构建FFmpeg命令
      const qualitySettings = this.getQualitySettings(options.quality);
      const command = [
        '-framerate', options.frameRate.toString(),
        '-i', '/tmp/frame_%06d.png',
        '-c:v', 'libx264',
        '-pix_fmt', 'yuv420p',
        ...qualitySettings,
        '-movflags', '+faststart',
        outputFile
      ];

      console.log('Running FFmpeg command:', command.join(' '));
      
      // 执行FFmpeg命令
      await this.ffmpeg.exec(command);

      // 读取输出文件
      const data = await this.ffmpeg.readFile(outputFile);
      
      // 清理临时文件
      await this.cleanup();

      // 返回Blob
      return new Blob([data], { type: 'video/mp4' });
    } catch (error) {
      console.error('Failed to process recording:', error);
      await this.cleanup();
      throw error;
    }
  }

  private async createPNGFromImageData(imageData: Uint8Array, width: number, height: number): Promise<Uint8Array> {
    // 创建一个临时的canvas来生成PNG
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('Failed to get canvas context');
    }

    // 将ImageData绘制到canvas
    const imgData = new ImageData(new Uint8ClampedArray(imageData), width, height);
    ctx.putImageData(imgData, 0, 0);

    // 转换为PNG Blob
    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Failed to create PNG blob'));
          return;
        }
        
        blob.arrayBuffer().then(buffer => {
          resolve(new Uint8Array(buffer));
        }).catch(reject);
      }, 'image/png');
    });
  }

  private getQualitySettings(quality: 'low' | 'medium' | 'high'): string[] {
    switch (quality) {
      case 'low':
        return ['-crf', '28', '-preset', 'fast'];
      case 'medium':
        return ['-crf', '23', '-preset', 'medium'];
      case 'high':
        return ['-crf', '18', '-preset', 'slow'];
      default:
        return ['-crf', '23', '-preset', 'medium'];
    }
  }

  private async cleanup(): Promise<void> {
    try {
      // 清理临时文件
      const files = await this.ffmpeg.listDir('/tmp');
      for (const file of files) {
        if (file.isFile) {
          await this.ffmpeg.deleteFile(`/tmp/${file.name}`);
        }
      }
    } catch (error) {
      console.warn('Failed to cleanup temporary files:', error);
    }
  }

  getFrameCount(): number {
    return this.frames.length;
  }

  getRecordingDuration(): number {
    if (this.frames.length === 0) return 0;
    return this.frames[this.frames.length - 1].timestamp;
  }

  isRecordingActive(): boolean {
    return this.recording;
  }
}

// 单例实例
let recorderInstance: FFmpegRecorder | null = null;

export const getFFmpegRecorder = (): FFmpegRecorder => {
  if (!recorderInstance) {
    recorderInstance = new FFmpegRecorder();
  }
  return recorderInstance;
};
