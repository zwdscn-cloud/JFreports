import React from 'react'

interface GradientDefsProps {
  id: string
  colors: string[]
  direction?: 'horizontal' | 'vertical' | 'diagonal'
}

export function GradientDefs({ id, colors, direction = 'vertical' }: GradientDefsProps) {
  const getGradientDirection = () => {
    switch (direction) {
      case 'horizontal':
        return { x1: '0%', y1: '0%', x2: '100%', y2: '0%' }
      case 'diagonal':
        return { x1: '0%', y1: '0%', x2: '100%', y2: '100%' }
      case 'vertical':
      default:
        return { x1: '0%', y1: '0%', x2: '0%', y2: '100%' }
    }
  }

  const gradientProps = getGradientDirection()

  return (
    <defs>
      <linearGradient
        id={id}
        {...gradientProps}
      >
        {colors.map((color, index) => (
          <stop
            key={index}
            offset={`${(index / (colors.length - 1)) * 100}%`}
            stopColor={color}
            stopOpacity={1}
          />
        ))}
      </linearGradient>
    </defs>
  )
}

// 紫色渐变预设
export const PURPLE_GRADIENTS = {
  primary: ['#8b5cf6', '#a855f7', '#c084fc'],
  secondary: ['#a855f7', '#c084fc', '#d8b4fe'],
  tertiary: ['#c084fc', '#d8b4fe', '#e9d5ff'],
  quaternary: ['#8b5cf6', '#c084fc', '#e9d5ff'],
  quinary: ['#a855f7', '#d8b4fe', '#f3e8ff']
}

// 创建紫色渐变定义
export function PurpleGradientDefs() {
  return (
    <defs>
      {Object.entries(PURPLE_GRADIENTS).map(([key, colors], index) => (
        <linearGradient
          key={key}
          id={`purple-gradient-${key}`}
          x1="0%"
          y1="0%"
          x2="0%"
          y2="100%"
        >
          {colors.map((color, colorIndex) => (
            <stop
              key={colorIndex}
              offset={`${(colorIndex / (colors.length - 1)) * 100}%`}
              stopColor={color}
              stopOpacity={1}
            />
          ))}
        </linearGradient>
      ))}
    </defs>
  )
}
