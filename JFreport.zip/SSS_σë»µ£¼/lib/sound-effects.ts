// 音效管理工具
export class SoundManager {
  private static instance: SoundManager
  private audioContext: AudioContext | null = null
  private isEnabled: boolean = true
  private volume: number = 0.3

  private constructor() {
    // 初始化音频上下文
    if (typeof window !== 'undefined') {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    }
  }

  public static getInstance(): SoundManager {
    if (!SoundManager.instance) {
      SoundManager.instance = new SoundManager()
    }
    return SoundManager.instance
  }

  // 启用/禁用音效
  public setEnabled(enabled: boolean) {
    this.isEnabled = enabled
  }

  // 设置音量
  public setVolume(volume: number) {
    this.volume = Math.max(0, Math.min(1, volume))
  }

  // 创建布灵布灵音效
  private createCrystalSound(frequency: number, duration: number = 0.1) {
    if (!this.audioContext || !this.isEnabled) return

    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    // 设置频率
    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime)
    
    // 设置波形为sine波，产生清脆的声音
    oscillator.type = 'sine'

    // 设置音量包络
    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime)
    gainNode.gain.linearRampToValueAtTime(this.volume, this.audioContext.currentTime + 0.01)
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration)

    // 播放音效
    oscillator.start(this.audioContext.currentTime)
    oscillator.stop(this.audioContext.currentTime + duration)
  }

  // 按钮点击音效 - 清脆的布灵声
  public playButtonClick() {
    this.createCrystalSound(800, 0.15)
  }

  // 菜单点击音效 - 稍微低一点的布灵声
  public playMenuClick() {
    this.createCrystalSound(600, 0.12)
  }

  // 成功音效 - 上升的布灵声
  public playSuccess() {
    if (!this.audioContext || !this.isEnabled) return

    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    oscillator.type = 'sine'
    oscillator.frequency.setValueAtTime(600, this.audioContext.currentTime)
    oscillator.frequency.linearRampToValueAtTime(1000, this.audioContext.currentTime + 0.2)

    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime)
    gainNode.gain.linearRampToValueAtTime(this.volume, this.audioContext.currentTime + 0.01)
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.2)

    oscillator.start(this.audioContext.currentTime)
    oscillator.stop(this.audioContext.currentTime + 0.2)
  }

  // 错误音效 - 下降的布灵声
  public playError() {
    if (!this.audioContext || !this.isEnabled) return

    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    oscillator.type = 'sine'
    oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime)
    oscillator.frequency.linearRampToValueAtTime(400, this.audioContext.currentTime + 0.15)

    gainNode.gain.setValueAtTime(0, this.audioContext.currentTime)
    gainNode.gain.linearRampToValueAtTime(this.volume, this.audioContext.currentTime + 0.01)
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.15)

    oscillator.start(this.audioContext.currentTime)
    oscillator.stop(this.audioContext.currentTime + 0.15)
  }

  // 悬停音效 - 轻微的布灵声
  public playHover() {
    this.createCrystalSound(1000, 0.05)
  }

  // 特殊操作音效 - 多音调布灵声
  public playSpecial() {
    if (!this.audioContext || !this.isEnabled) return

    // 创建多个音调
    const frequencies = [523, 659, 784] // C5, E5, G5 和弦
    const duration = 0.3

    frequencies.forEach((freq, index) => {
      const oscillator = this.audioContext!.createOscillator()
      const gainNode = this.audioContext!.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(this.audioContext!.destination)

      oscillator.type = 'sine'
      oscillator.frequency.setValueAtTime(freq, this.audioContext!.currentTime + index * 0.05)

      gainNode.gain.setValueAtTime(0, this.audioContext!.currentTime + index * 0.05)
      gainNode.gain.linearRampToValueAtTime(this.volume * 0.5, this.audioContext!.currentTime + index * 0.05 + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext!.currentTime + index * 0.05 + duration)

      oscillator.start(this.audioContext!.currentTime + index * 0.05)
      oscillator.stop(this.audioContext!.currentTime + index * 0.05 + duration)
    })
  }
}

// 导出单例实例
export const soundManager = SoundManager.getInstance()

// 音效类型枚举
export enum SoundType {
  BUTTON_CLICK = 'buttonClick',
  MENU_CLICK = 'menuClick',
  SUCCESS = 'success',
  ERROR = 'error',
  HOVER = 'hover',
  SPECIAL = 'special'
}

// 播放音效的便捷函数
export const playSound = (type: SoundType) => {
  switch (type) {
    case SoundType.BUTTON_CLICK:
      soundManager.playButtonClick()
      break
    case SoundType.MENU_CLICK:
      soundManager.playMenuClick()
      break
    case SoundType.SUCCESS:
      soundManager.playSuccess()
      break
    case SoundType.ERROR:
      soundManager.playError()
      break
    case SoundType.HOVER:
      soundManager.playHover()
      break
    case SoundType.SPECIAL:
      soundManager.playSpecial()
      break
  }
}
