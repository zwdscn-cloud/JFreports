import { useCallback, useRef, useState, useEffect } from 'react'

interface CanvasState {
  zoom: number
  offset: { x: number; y: number }
  isPanning: boolean
  isSelecting: boolean
  isDragging: boolean
}

interface UseOptimizedCanvasProps {
  initialZoom?: number
  initialOffset?: { x: number; y: number }
  onZoomChange?: (zoom: number) => void
  onOffsetChange?: (offset: { x: number; y: number }) => void
}

export function useOptimizedCanvas({
  initialZoom = 100,
  initialOffset = { x: 0, y: 0 },
  onZoomChange,
  onOffsetChange
}: UseOptimizedCanvasProps = {}) {
  const [state, setState] = useState<CanvasState>({
    zoom: initialZoom,
    offset: initialOffset,
    isPanning: false,
    isSelecting: false,
    isDragging: false
  })

  const animationFrameRef = useRef<number | null>(null)
  const lastMousePos = useRef({ x: 0, y: 0 })
  const panStart = useRef({ x: 0, y: 0 })
  const canvasRef = useRef<HTMLDivElement>(null)

  // 优化的坐标计算 - 使用缓存
  const getCanvasCoordinates = useCallback((e: React.MouseEvent | MouseEvent) => {
    if (!canvasRef.current) return null

    const rect = canvasRef.current.getBoundingClientRect()
    const scale = state.zoom / 100
    
    return {
      x: (e.clientX - rect.left) / scale,
      y: (e.clientY - rect.top) / scale
    }
  }, [state.zoom])

  // 优化的缩放函数
  const setZoom = useCallback((newZoom: number) => {
    const clampedZoom = Math.max(25, Math.min(200, newZoom))
    setState(prev => ({ ...prev, zoom: clampedZoom }))
    onZoomChange?.(clampedZoom)
  }, [onZoomChange])

  // 优化的偏移函数
  const setOffset = useCallback((newOffset: { x: number; y: number }) => {
    setState(prev => ({ ...prev, offset: newOffset }))
    onOffsetChange?.(newOffset)
  }, [onOffsetChange])

  // 缩放控制
  const zoomIn = useCallback(() => {
    setZoom(state.zoom + 10)
  }, [state.zoom, setZoom])

  const zoomOut = useCallback(() => {
    setZoom(state.zoom - 10)
  }, [state.zoom, setZoom])

  const resetZoom = useCallback(() => {
    setZoom(100)
    setOffset({ x: 0, y: 0 })
  }, [setZoom, setOffset])

  // 优化的鼠标按下处理
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return

    const coords = getCanvasCoordinates(e)
    if (!coords) return

    lastMousePos.current = { x: e.clientX, y: e.clientY }
    
    if (e.ctrlKey || e.metaKey) {
      // 开始平移
      setState(prev => ({ 
        ...prev, 
        isPanning: true,
        isSelecting: false,
        isDragging: false
      }))
      panStart.current = { x: e.clientX - state.offset.x, y: e.clientY - state.offset.y }
    } else {
      // 开始选择
      setState(prev => ({ 
        ...prev, 
        isSelecting: true,
        isPanning: false,
        isDragging: false
      }))
    }
  }, [getCanvasCoordinates, state.offset])

  // 优化的鼠标移动处理 - 使用 requestAnimationFrame
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
    }

    animationFrameRef.current = requestAnimationFrame(() => {
      const coords = getCanvasCoordinates(e)
      if (!coords) return

      if (state.isPanning) {
        // 实时更新偏移
        const newOffset = {
          x: e.clientX - panStart.current.x,
          y: e.clientY - panStart.current.y
        }
        setOffset(newOffset)
      } else if (state.isSelecting) {
        // 处理选择逻辑
        // 这里可以添加选择框的实时更新
      }

      lastMousePos.current = { x: e.clientX, y: e.clientY }
    })
  }, [getCanvasCoordinates, state.isPanning, state.isSelecting, setOffset])

  // 优化的鼠标释放处理
  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }

    setState(prev => ({
      ...prev,
      isPanning: false,
      isSelecting: false,
      isDragging: false
    }))
  }, [])

  // 滚轮缩放处理
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    
    const delta = e.deltaY > 0 ? -10 : 10
    const newZoom = state.zoom + delta
    setZoom(newZoom)
  }, [state.zoom, setZoom])

  // 清理函数
  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [])

  return {
    // 状态
    zoom: state.zoom,
    offset: state.offset,
    isPanning: state.isPanning,
    isSelecting: state.isSelecting,
    isDragging: state.isDragging,
    
    // 引用
    canvasRef,
    
    // 函数
    getCanvasCoordinates,
    setZoom,
    setOffset,
    zoomIn,
    zoomOut,
    resetZoom,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleWheel
  }
}
