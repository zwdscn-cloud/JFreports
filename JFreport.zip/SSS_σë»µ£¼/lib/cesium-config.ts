// Cesium配置
export const CESIUM_CONFIG = {
  // Cesium Ion访问令牌
  ION_TOKEN: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJhMGY0MDZmMy1iMjYxLTQxZGQtODNlMC0xMTU0MWYzODA2ZDQiLCJpZCI6ODAwNzIsImlhdCI6MTY0NDg1MjI3M30.sLYxZ-k3L5U2Z5B1SkYErwkSNFJg5oDGrEYlxyrXrpU",
  
  // Bing Maps密钥（可选）
  BING_MAPS_KEY: "your_bing_maps_key_here",
  
  // 默认相机位置
  DEFAULT_CAMERA: {
    longitude: 116.4,
    latitude: 39.9,
    height: 10000000,
    heading: 0,
    pitch: -90,
    roll: 0,
  },
  
  // 默认样式
  DEFAULT_STYLE: {
    baseMapStyle: "satellite" as const,
    dataVisualizationStyle: "individual" as const,
    colorScheme: "viridis" as const,
  }
}
