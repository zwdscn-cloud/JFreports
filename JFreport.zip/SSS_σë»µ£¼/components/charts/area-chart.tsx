"use client"

import {
  AreaChart as RechartsAreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface AreaChartProps {
  data: Array<{
    name: string
    value: number
    value2?: number
    value3?: number
  }>
  title?: string
  showLegend?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  transparent?: boolean
  colors?: string[]
  scale?: number // 缩放比例，默认为1
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

export function AreaChart({
  data,
  title,
  showLegend = true,
  showGrid = true,
  showTooltip = true,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  scale = 1,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: AreaChartProps) {
  const { playHover } = useSound()
  
  const containerClasses = [
    "w-full h-full min-h-[200px] cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  // 计算缩放后的字体大小
  const scaledFontSize = 12 * scale

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div 
          className="font-medium mb-4"
          style={{ 
            fontSize: `${titleFontSize || scaledFontSize}px`,
            color: titleTextColor || textColors?.title || (transparent ? "#fff" : "#333")
          }}
        >
          {title}
        </div>
      )}
      <ResponsiveContainer width="100%" height={transparent ? "100%" : "100%"}>
        <RechartsAreaChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          {showGrid && (
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke={transparent ? "rgba(255,255,255,0.2)" : "#666"} 
              vertical={false} 
            />
          )}
          <XAxis
            dataKey="name"
            stroke={axisTextColor || textColors?.axis || (transparent ? "#fff" : colors[0])}
            fontSize={axisFontSize || scaledFontSize}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke={axisTextColor || textColors?.axis || (transparent ? "#fff" : colors[0])} 
            fontSize={axisFontSize || scaledFontSize} 
            tickLine={false} 
            axisLine={false} 
          />
          {showTooltip && (
            <Tooltip
              contentStyle={{
                backgroundColor: transparent ? "rgba(15, 23, 42, 0.9)" : "#fff",
                border: transparent ? "1px solid rgba(255, 255, 255, 0.2)" : "1px solid #ddd",
                borderRadius: "8px",
                color: tooltipTextColor || textColors?.tooltip || (transparent ? "#fff" : "#333"),
                fontSize: `${tooltipFontSize || scaledFontSize}px`,
              }}
            />
          )}
          {showLegend && (
            <Legend
              wrapperStyle={{
                fontSize: `${legendFontSize || scaledFontSize}px`,
                color: legendTextColor || textColors?.legend || (transparent ? "#fff" : colors[0]),
              }}
            />
          )}
          <Area
            type="monotone"
            dataKey="value"
            name="数值"
            stroke={colors[0]}
            fill={colors[0]}
            fillOpacity={0.6}
            strokeWidth={2}
          />
          {data.some(item => item.value2 !== undefined) && (
            <Area
              type="monotone"
              dataKey="value2"
              name="数值2"
              stroke={colors[1]}
              fill={colors[1]}
              fillOpacity={0.6}
              strokeWidth={2}
            />
          )}
          {data.some(item => item.value3 !== undefined) && (
            <Area
              type="monotone"
              dataKey="value3"
              name="数值3"
              stroke={colors[2]}
              fill={colors[2]}
              fillOpacity={0.6}
              strokeWidth={2}
            />
          )}
        </RechartsAreaChart>
      </ResponsiveContainer>
    </div>
  )
}