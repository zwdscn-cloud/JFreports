"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Check, X } from "lucide-react"

interface ColorPickerProps {
  value: string
  onChange: (color: string) => void
  label?: string
  id?: string
  className?: string
  buttonsAtBottom?: boolean
}

export function ColorPicker({ value, onChange, label, id, className, buttonsAtBottom = false }: ColorPickerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [tempColor, setTempColor] = useState(value)

  const handleConfirm = () => {
    onChange(tempColor)
    setIsOpen(false)
  }

  const handleCancel = () => {
    setTempColor(value)
    setIsOpen(false)
  }

  const handleOpenChange = (open: boolean) => {
    if (open) {
      setTempColor(value)
    }
    setIsOpen(open)
  }

  return (
    <div className={className}>
      {label && <Label htmlFor={id}>{label}</Label>}
      <Popover open={isOpen} onOpenChange={handleOpenChange}>
        <PopoverTrigger asChild>
          <Button
            id={id}
            variant="outline"
            className="mt-1 h-10 w-full justify-start text-left font-normal"
          >
            <div
              className="w-4 h-4 rounded border mr-2"
              style={{ backgroundColor: value }}
            />
            {value}
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          className="w-64 p-4" 
          align="center" 
          side="bottom"
          sideOffset={4}
        >
          <div className="space-y-4">
            {/* 确定和取消按钮 - 根据buttonsAtBottom决定位置 */}
            {!buttonsAtBottom && (
              <div className="flex space-x-2 pb-2 border-b border-border">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCancel}
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-1" />
                  取消
                </Button>
                <Button
                  size="sm"
                  onClick={handleConfirm}
                  className="flex-1"
                >
                  <Check className="w-4 h-4 mr-1" />
                  确定
                </Button>
              </div>
            )}

            {/* 颜色选择器 */}
            <div>
              <Label htmlFor="color-input">选择颜色</Label>
              <Input
                id="color-input"
                type="color"
                value={tempColor}
                onChange={(e) => setTempColor(e.target.value)}
                className="mt-1 h-12 w-full"
              />
            </div>
            
            {/* 十六进制输入 */}
            <div>
              <Label htmlFor="hex-input">十六进制值</Label>
              <Input
                id="hex-input"
                type="text"
                value={tempColor}
                onChange={(e) => setTempColor(e.target.value)}
                className="mt-1"
                placeholder="#000000"
              />
            </div>

            {/* 颜色对比预览 */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center space-x-2">
                <div
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: value }}
                />
                <span className="text-sm text-muted-foreground">当前</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <div
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: tempColor }}
                />
                <span className="text-sm text-muted-foreground">预览</span>
              </div>
            </div>

            {/* 确定和取消按钮 - 放在最下面（仅当buttonsAtBottom为true时） */}
            {buttonsAtBottom && (
              <div className="flex space-x-2 pt-2 border-t border-border">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleCancel}
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-1" />
                  取消
                </Button>
                <Button
                  size="sm"
                  onClick={handleConfirm}
                  className="flex-1"
                >
                  <Check className="w-4 h-4 mr-1" />
                  确定
                </Button>
              </div>
            )}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
