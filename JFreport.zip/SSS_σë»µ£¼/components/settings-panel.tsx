"use client"

import React, { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { 
  Settings, 
  Download, 
  Upload, 
  Palette, 
  Monitor, 
  Keyboard, 
  Volume2, 
  Eye, 
  Zap, 
  Shield, 
  Database,
  Globe,
  FileText,
  Image,
  Video,
  Music,
  Trash2,
  RefreshCw,
  Save,
  Copy,
  Share2,
  Lock,
  Unlock,
  Bell,
  BellOff
} from "lucide-react"
import { useSound } from "@/hooks/use-sound"

interface SettingsPanelProps {
  isOpen: boolean
  onClose: () => void
  onExport?: (format: string) => void
  onImport?: (file: File) => void
  onClearCache?: () => void
  onResetSettings?: () => void
}

export function SettingsPanel({
  isOpen,
  onClose,
  onExport,
  onImport,
  onClearCache,
  onResetSettings
}: SettingsPanelProps) {
  const { playSuccess, playError } = useSound()
  
  // 设置状态
  const [settings, setSettings] = useState({
    // 外观设置
    theme: "auto",
    fontSize: 14,
    animationSpeed: 1,
    showGrid: true,
    showRulers: false,
    
    // 性能设置
    enableHardwareAcceleration: true,
    maxFPS: 60,
    quality: "high",
    enableCaching: true,
    cacheSize: 100,
    
    // 音效设置
    enableSounds: true,
    soundVolume: 70,
    enableHoverSounds: true,
    enableClickSounds: true,
    
    // 快捷键设置
    enableShortcuts: true,
    quickSave: "Ctrl+S",
    quickLoad: "Ctrl+O",
    quickClear: "Ctrl+Delete",
    
    // 安全设置
    autoSave: true,
    autoSaveInterval: 5,
    enableBackup: true,
    backupCount: 3,
    
    // 导出设置
    defaultFormat: "json",
    includeMetadata: true,
    compressFiles: true,
    
    // 通知设置
    enableNotifications: true,
    showSuccessMessages: true,
    showErrorMessages: true,
    showWarningMessages: true
  })

  // 处理设置更新
  const updateSetting = useCallback((key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }, [])

  // 处理文件导入
  const handleFileImport = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && onImport) {
      onImport(file)
      playSuccess()
    }
    event.target.value = ""
  }, [onImport, playSuccess])

  // 处理导出
  const handleExport = useCallback((format: string) => {
    if (onExport) {
      onExport(format)
      playSuccess()
    }
  }, [onExport, playSuccess])

  // 处理清除缓存
  const handleClearCache = useCallback(() => {
    if (onClearCache) {
      onClearCache()
      playSuccess()
    }
  }, [onClearCache, playSuccess])

  // 处理重置设置
  const handleResetSettings = useCallback(() => {
    if (onResetSettings) {
      onResetSettings()
      playError()
    }
  }, [onResetSettings, playError])

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            系统设置
          </DialogTitle>
          <DialogDescription>
            自定义你的工作环境和偏好设置
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="appearance" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="appearance" className="flex items-center gap-2">
              <Palette className="w-4 h-4" />
              外观
            </TabsTrigger>
            <TabsTrigger value="performance" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              性能
            </TabsTrigger>
            <TabsTrigger value="audio" className="flex items-center gap-2">
              <Volume2 className="w-4 h-4" />
              音效
            </TabsTrigger>
            <TabsTrigger value="shortcuts" className="flex items-center gap-2">
              <Keyboard className="w-4 h-4" />
              快捷键
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              安全
            </TabsTrigger>
            <TabsTrigger value="export" className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              导出
            </TabsTrigger>
          </TabsList>

          {/* 外观设置 */}
          <TabsContent value="appearance" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">主题设置</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="theme">主题模式</Label>
                  <Select value={settings.theme} onValueChange={(value) => updateSetting('theme', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">浅色模式</SelectItem>
                      <SelectItem value="dark">深色模式</SelectItem>
                      <SelectItem value="auto">自动</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fontSize">字体大小</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.fontSize]}
                      onValueChange={([value]) => updateSetting('fontSize', value)}
                      min={12}
                      max={20}
                      step={1}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-8">{settings.fontSize}px</span>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">界面设置</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    <Label htmlFor="showGrid">显示网格</Label>
                  </div>
                  <Switch
                    id="showGrid"
                    checked={settings.showGrid}
                    onCheckedChange={(checked) => updateSetting('showGrid', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Monitor className="w-4 h-4" />
                    <Label htmlFor="showRulers">显示标尺</Label>
                  </div>
                  <Switch
                    id="showRulers"
                    checked={settings.showRulers}
                    onCheckedChange={(checked) => updateSetting('showRulers', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="animationSpeed">动画速度</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.animationSpeed]}
                      onValueChange={([value]) => updateSetting('animationSpeed', value)}
                      min={0.5}
                      max={3}
                      step={0.1}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.animationSpeed}x</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* 性能设置 */}
          <TabsContent value="performance" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">渲染设置</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    <Label htmlFor="hardwareAcceleration">硬件加速</Label>
                  </div>
                  <Switch
                    id="hardwareAcceleration"
                    checked={settings.enableHardwareAcceleration}
                    onCheckedChange={(checked) => updateSetting('enableHardwareAcceleration', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="maxFPS">最大帧率</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.maxFPS]}
                      onValueChange={([value]) => updateSetting('maxFPS', value)}
                      min={30}
                      max={120}
                      step={10}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.maxFPS} FPS</span>
                  </div>
                </div>
                <div>
                  <Label htmlFor="quality">渲染质量</Label>
                  <Select value={settings.quality} onValueChange={(value) => updateSetting('quality', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">低质量</SelectItem>
                      <SelectItem value="medium">中等质量</SelectItem>
                      <SelectItem value="high">高质量</SelectItem>
                      <SelectItem value="ultra">超高质量</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">缓存设置</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <Label htmlFor="enableCaching">启用缓存</Label>
                  </div>
                  <Switch
                    id="enableCaching"
                    checked={settings.enableCaching}
                    onCheckedChange={(checked) => updateSetting('enableCaching', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="cacheSize">缓存大小 (MB)</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.cacheSize]}
                      onValueChange={([value]) => updateSetting('cacheSize', value)}
                      min={50}
                      max={500}
                      step={10}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.cacheSize}MB</span>
                  </div>
                </div>
                <Button variant="outline" onClick={handleClearCache} className="w-full">
                  <Trash2 className="w-4 h-4 mr-2" />
                  清除缓存
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* 音效设置 */}
          <TabsContent value="audio" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">音效控制</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4" />
                    <Label htmlFor="enableSounds">启用音效</Label>
                  </div>
                  <Switch
                    id="enableSounds"
                    checked={settings.enableSounds}
                    onCheckedChange={(checked) => updateSetting('enableSounds', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="soundVolume">音量</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.soundVolume]}
                      onValueChange={([value]) => updateSetting('soundVolume', value)}
                      min={0}
                      max={100}
                      step={5}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.soundVolume}%</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4" />
                    <Label htmlFor="enableHoverSounds">悬停音效</Label>
                  </div>
                  <Switch
                    id="enableHoverSounds"
                    checked={settings.enableHoverSounds}
                    onCheckedChange={(checked) => updateSetting('enableHoverSounds', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4" />
                    <Label htmlFor="enableClickSounds">点击音效</Label>
                  </div>
                  <Switch
                    id="enableClickSounds"
                    checked={settings.enableClickSounds}
                    onCheckedChange={(checked) => updateSetting('enableClickSounds', checked)}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* 快捷键设置 */}
          <TabsContent value="shortcuts" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">快捷键配置</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Keyboard className="w-4 h-4" />
                    <Label htmlFor="enableShortcuts">启用快捷键</Label>
                  </div>
                  <Switch
                    id="enableShortcuts"
                    checked={settings.enableShortcuts}
                    onCheckedChange={(checked) => updateSetting('enableShortcuts', checked)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quickSave">快速保存</Label>
                    <Input value={settings.quickSave} readOnly className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="quickLoad">快速加载</Label>
                    <Input value={settings.quickLoad} readOnly className="mt-1" />
                  </div>
                  <div>
                    <Label htmlFor="quickClear">快速清除</Label>
                    <Input value={settings.quickClear} readOnly className="mt-1" />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* 安全设置 */}
          <TabsContent value="security" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">自动保存</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Save className="w-4 h-4" />
                    <Label htmlFor="autoSave">启用自动保存</Label>
                  </div>
                  <Switch
                    id="autoSave"
                    checked={settings.autoSave}
                    onCheckedChange={(checked) => updateSetting('autoSave', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="autoSaveInterval">自动保存间隔 (分钟)</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.autoSaveInterval]}
                      onValueChange={([value]) => updateSetting('autoSaveInterval', value)}
                      min={1}
                      max={30}
                      step={1}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.autoSaveInterval}分钟</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <Label htmlFor="enableBackup">启用备份</Label>
                  </div>
                  <Switch
                    id="enableBackup"
                    checked={settings.enableBackup}
                    onCheckedChange={(checked) => updateSetting('enableBackup', checked)}
                  />
                </div>
                <div>
                  <Label htmlFor="backupCount">备份数量</Label>
                  <div className="flex items-center gap-2">
                    <Slider
                      value={[settings.backupCount]}
                      onValueChange={([value]) => updateSetting('backupCount', value)}
                      min={1}
                      max={10}
                      step={1}
                      className="flex-1"
                    />
                    <span className="text-sm text-muted-foreground w-12">{settings.backupCount}个</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* 导出设置 */}
          <TabsContent value="export" className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">导出配置</h3>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="defaultFormat">默认格式</Label>
                  <Select value={settings.defaultFormat} onValueChange={(value) => updateSetting('defaultFormat', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="png">PNG图片</SelectItem>
                      <SelectItem value="pdf">PDF文档</SelectItem>
                      <SelectItem value="svg">SVG矢量</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    <Label htmlFor="includeMetadata">包含元数据</Label>
                  </div>
                  <Switch
                    id="includeMetadata"
                    checked={settings.includeMetadata}
                    onCheckedChange={(checked) => updateSetting('includeMetadata', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    <Label htmlFor="compressFiles">压缩文件</Label>
                  </div>
                  <Switch
                    id="compressFiles"
                    checked={settings.compressFiles}
                    onCheckedChange={(checked) => updateSetting('compressFiles', checked)}
                  />
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">快速导出</h3>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={() => handleExport('json')} className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  JSON格式
                </Button>
                <Button variant="outline" onClick={() => handleExport('png')} className="flex items-center gap-2">
                  <Image className="w-4 h-4" />
                  PNG图片
                </Button>
                <Button variant="outline" onClick={() => handleExport('pdf')} className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  PDF文档
                </Button>
                <Button variant="outline" onClick={() => handleExport('svg')} className="flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  SVG矢量
                </Button>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">导入文件</h3>
              <div className="space-y-3">
                <div className="relative">
                  <input
                    type="file"
                    accept=".json,.png,.pdf,.svg"
                    onChange={handleFileImport}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    id="import-file"
                  />
                  <Button variant="outline" className="w-full flex items-center gap-2" asChild>
                    <label htmlFor="import-file" className="cursor-pointer">
                      <Upload className="w-4 h-4" />
                      选择文件导入
                    </label>
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between items-center pt-4 border-t">
          <Button variant="outline" onClick={handleResetSettings} className="text-red-600 hover:text-red-700">
            <RefreshCw className="w-4 h-4 mr-2" />
            重置设置
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              取消
            </Button>
            <Button onClick={onClose}>
              保存设置
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
