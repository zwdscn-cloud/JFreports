"use client"

import { useEffect, useRef, useCallback, useMemo } from "react"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { useSound } from "@/hooks/use-sound"

interface GaugeChartProps {
  data: Array<{
    name: string
    value: number
  }>
  title?: string
  transparent?: boolean
  colors?: string[]
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  titleFontSize?: number
  titleTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
  backgroundColor?: string
  borderColor?: string
  borderWidth?: number
  showTicks?: boolean
  majorTickCount?: number
  minorTickCount?: number
  needleColor?: string
  needleWidth?: number
  showValue?: boolean
  showTitle?: boolean
  onValueChange?: (value: number) => void
  className?: string
  // 量程设置
  minValue?: number
  maxValue?: number
  unit?: string
  // 尺寸设置
  width?: number
  height?: number
  // 仪表盘配色设置
  gaugeArcColor1?: string
  gaugeArcColor2?: string
  gaugeArcColor3?: string
  gaugeNeedleColor?: string
  gaugeCenterColor?: string
  gaugeTickColor?: string
  gaugeLabelColor?: string
  gaugeValueColor?: string
  gaugeNameColor?: string
  gaugeColorScheme?: string
}

// 位置计算函数 - 半圆形设计，居中对称，支持动态尺寸
function parsePosition(width: number, height: number) {
  const size = Math.min(width, height)
  const cx = width / 2
  const cy = height / 2  // 完全居中
  const r = size * 0.4
  return { cx, cy, r }
}

// 线性映射函数
function linearMap(val: number, domain: [number, number], range: [number, number], clamp?: boolean) {
  const d0 = domain[0]
  const d1 = domain[1]
  const r0 = range[0]
  const r1 = range[1]
  
  if (d0 === d1) {
    return r0
  }
  
  let t = (val - d0) / (d1 - d0)
  
  if (clamp) {
    t = Math.max(0, Math.min(1, t))
  }
  
  return t * (r1 - r0) + r0
}

// 格式化标签
function formatLabel(value: number, formatter?: string | ((value: number) => string)) {
  let label = value == null ? '' : value + ''
  if (formatter) {
    if (typeof formatter === 'string') {
      label = formatter.replace('{value}', label)
    } else if (typeof formatter === 'function') {
      label = formatter(value)
    }
  }
  return label
}

export function GaugeChart({
  data,
  title,
  transparent = true,
  colors = DEFAULT_CHART_COLORS,
  textColors,
  titleFontSize,
  titleTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor,
  backgroundColor,
  borderColor,
  borderWidth = 2,
  showTicks = true,
  majorTickCount = 10,
  minorTickCount = 4,
  needleColor,
  needleWidth = 4,
  showValue = true,
  showTitle = true,
  onValueChange,
  className,
  // 量程设置
  minValue = 0,
  maxValue = 240,
  unit = 'km/h',
  // 尺寸设置
  width = 400,
  height = 300,
  // 仪表盘配色设置
  gaugeArcColor1 = "#8b5cf6",
  gaugeArcColor2 = "#a855f7",
  gaugeArcColor3 = "#c084fc",
  gaugeNeedleColor = "#8b5cf6",
  gaugeCenterColor = "#a855f7",
  gaugeTickColor = "#ffffff",
  gaugeLabelColor = "#ffffff",
  gaugeValueColor = "#ffffff",
  gaugeNameColor = "#8b5cf6",
  gaugeColorScheme = "purple"
}: GaugeChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number | undefined>(undefined)
  const { playHover } = useSound()
  
  // 从数据中获取值，添加安全检查
  const value = (data && data.length > 0 && data[0]?.value !== undefined) ? data[0].value : 0
  const min = minValue
  const max = maxValue
  
  const currentValueRef = useRef(value)
  const targetValueRef = useRef(value)

  const textColor = chartTextColor || textColors?.label || (transparent ? "#fff" : "#333")
  const titleColor = titleTextColor || textColors?.title || (transparent ? "#fff" : "#333")
  const needleColorFinal = needleColor || "#ffffff" // 白色指针

  // 颜色配置 - 只保留蓝色区域，删除红色区域
  const colorList = useMemo(() => {
    return [
      [0, "#60a5fa"],      // 浅蓝色 (0-240 km/h)
      [1, "#60a5fa"]       // 浅蓝色 (整个范围)
    ] as [number, string][]
  }, [])

  const posInfo = useMemo(() => parsePosition(400, 300), []) // 固定尺寸

  // 角度计算 - 再向左旋转45度，从左侧到右侧
  // 左侧是-180度，右侧是0度，形成水平的半圆
  const startAngle = -Math.PI        // -180度 (左侧)
  const endAngle = 0                 // 0度 (右侧)
  const angleRangeSpan = Math.PI     // 180度范围

  // 绘制函数
  const drawGauge = (ctx: CanvasRenderingContext2D, currentValue: number) => {
    const { cx, cy, r } = posInfo
    
    ctx.clearRect(0, 0, width, height)

    // 绘制背景
    if (backgroundColor) {
      ctx.fillStyle = backgroundColor
      ctx.fillRect(0, 0, width, height)
    }


    // 绘制仪表盘弧线 - 使用紫色渐变
    const axisLineWidth = 20
    let prevEndAngle = startAngle

    for (let i = 0; i < colorList.length; i++) {
      const percent = Math.min(Math.max(colorList[i][0], 0), 1)
      const endAngle = startAngle + angleRangeSpan * percent
      
      // 创建渐变
      const gradient = ctx.createLinearGradient(
        cx - r, cy - r, 
        cx + r, cy + r
      )
      
      // 根据位置使用不同的配色渐变
      if (i === 0) {
        gradient.addColorStop(0, gaugeArcColor1)
        gradient.addColorStop(0.5, gaugeArcColor2)
        gradient.addColorStop(1, gaugeArcColor3)
      } else if (i === 1) {
        gradient.addColorStop(0, gaugeArcColor2)
        gradient.addColorStop(0.5, gaugeArcColor3)
        gradient.addColorStop(1, gaugeArcColor3)
      } else {
        gradient.addColorStop(0, gaugeArcColor3)
        gradient.addColorStop(0.5, gaugeArcColor3)
        gradient.addColorStop(1, gaugeArcColor3)
      }
      
      ctx.beginPath()
      ctx.arc(cx, cy, r, prevEndAngle, endAngle)
      ctx.strokeStyle = gradient
      ctx.lineWidth = axisLineWidth
      ctx.lineCap = 'round'
      ctx.stroke()
      
      prevEndAngle = endAngle
    }

    // 绘制刻度 - 根据量程动态计算，美化样式
    if (showTicks) {
      const range = max - min
      const tickInterval = range / majorTickCount
      const splitLineLen = r * 0.15
      let angle = startAngle
      const step = (endAngle - startAngle) / majorTickCount

      for (let i = 0; i <= majorTickCount; i++) {
        const unitX = Math.cos(angle)
        const unitY = Math.sin(angle)
        
        // 绘制主刻度线 - 3D效果
        ctx.beginPath()
        ctx.moveTo(unitX * (r - axisLineWidth/2) + cx, unitY * (r - axisLineWidth/2) + cy)
        ctx.lineTo(unitX * (r - splitLineLen - axisLineWidth/2) + cx, unitY * (r - splitLineLen - axisLineWidth/2) + cy)
        
        // 使用渐变色的刻度线
        const gradient = ctx.createLinearGradient(
          unitX * (r - axisLineWidth/2) + cx, unitY * (r - axisLineWidth/2) + cy,
          unitX * (r - splitLineLen - axisLineWidth/2) + cx, unitY * (r - splitLineLen - axisLineWidth/2) + cy
        )
        gradient.addColorStop(0, gaugeTickColor)
        gradient.addColorStop(0.5, gaugeTickColor)
        gradient.addColorStop(1, gaugeTickColor)
        
        ctx.strokeStyle = gradient
        ctx.lineWidth = 4
        ctx.lineCap = 'round'
        ctx.stroke()
        
        // 添加刻度线阴影
        ctx.beginPath()
        ctx.moveTo(unitX * (r - axisLineWidth/2 - 1) + cx, unitY * (r - axisLineWidth/2 - 1) + cy)
        ctx.lineTo(unitX * (r - splitLineLen - axisLineWidth/2 - 1) + cx, unitY * (r - splitLineLen - axisLineWidth/2 - 1) + cy)
        ctx.strokeStyle = "rgba(0, 0, 0, 0.3)"
        ctx.lineWidth = 4
        ctx.lineCap = 'round'
        ctx.stroke()

        // 绘制刻度数字 - 美化字体，根据组件尺寸调整字体大小
        const currentValue = min + (i * tickInterval)
        const label = formatLabel(Math.round(currentValue))
        const labelX = unitX * (r - splitLineLen - axisLineWidth/2 - 20) + cx
        const labelY = unitY * (r - splitLineLen - axisLineWidth/2 - 20) + cy
        
        // 根据组件尺寸动态调整字体大小
        const dynamicFontSize = Math.max(10, Math.min(20, (width + height) / 40))
        
        // 文字阴影效果
        ctx.font = `bold ${chartFontSize || dynamicFontSize}px Arial`
        ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.fillText(label, labelX + 1, labelY + 1)
        
        // 主文字
        ctx.fillStyle = gaugeLabelColor
        ctx.fillText(label, labelX, labelY)
        
        angle += step
      }
    }

    // 绘制指针 - 3D美化效果
    const valueExtent: [number, number] = [min, max]
    const angleExtent: [number, number] = [startAngle, endAngle]
    const pointerAngle = linearMap(currentValue, valueExtent, angleExtent, true)
    
    const pointerLength = r - 20
    const pointerWidth = needleWidth
    
    // 指针阴影
    const pointerEndX = cx + Math.cos(pointerAngle) * pointerLength
    const pointerEndY = cy + Math.sin(pointerAngle) * pointerLength
    
    ctx.beginPath()
    ctx.moveTo(cx + 2, cy + 2)
    ctx.lineTo(pointerEndX + 2, pointerEndY + 2)
    ctx.strokeStyle = "rgba(0, 0, 0, 0.4)"
    ctx.lineWidth = pointerWidth + 2
    ctx.lineCap = 'round'
    ctx.stroke()
    
    // 指针主体 - 使用自定义配色渐变
    const pointerGradient = ctx.createLinearGradient(cx, cy, pointerEndX, pointerEndY)
    pointerGradient.addColorStop(0, gaugeNeedleColor)
    pointerGradient.addColorStop(0.5, gaugeNeedleColor)
    pointerGradient.addColorStop(1, gaugeNeedleColor)
    
    ctx.beginPath()
    ctx.moveTo(cx, cy)
    ctx.lineTo(pointerEndX, pointerEndY)
    ctx.strokeStyle = pointerGradient
    ctx.lineWidth = pointerWidth
    ctx.lineCap = 'round'
    ctx.stroke()
    
    // 指针高光
    ctx.beginPath()
    ctx.moveTo(cx, cy)
    ctx.lineTo(pointerEndX, pointerEndY)
    ctx.strokeStyle = "rgba(255, 255, 255, 0.3)"
    ctx.lineWidth = 2
    ctx.lineCap = 'round'
    ctx.stroke()
    
    // 绘制指针中心点 - 3D效果
    // 阴影
    ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
    ctx.beginPath()
    ctx.arc(cx + 2, cy + 2, 8, 0, 2 * Math.PI)
    ctx.fill()
    
    // 主体
    const centerGradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, 8)
    centerGradient.addColorStop(0, '#ffffff')
    centerGradient.addColorStop(0.3, gaugeCenterColor)
    centerGradient.addColorStop(1, gaugeCenterColor)
    
    ctx.fillStyle = centerGradient
    ctx.beginPath()
    ctx.arc(cx, cy, 8, 0, 2 * Math.PI)
    ctx.fill()
    
    // 高光
    ctx.fillStyle = "rgba(255, 255, 255, 0.6)"
    ctx.beginPath()
    ctx.arc(cx - 2, cy - 2, 3, 0, 2 * Math.PI)
    ctx.fill()

    // 绘制中央显示 - 美化数值显示，根据组件尺寸调整字体大小
    if (showValue) {
      const valueText = formatLabel(Math.round(currentValue))
      
      // 根据组件尺寸动态调整数值字体大小
      const dynamicValueFontSize = Math.max(20, Math.min(60, (width + height) / 15))
      
      // 数值阴影
      ctx.font = `bold ${chartFontSize ? chartFontSize + 16 : dynamicValueFontSize}px Arial`
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(valueText, cx + 2, cy + 22)
      
      // 数值主体 - 使用自定义配色渐变
      const valueGradient = ctx.createLinearGradient(cx - 50, cy + 20, cx + 50, cy + 20)
      valueGradient.addColorStop(0, gaugeValueColor)
      valueGradient.addColorStop(0.5, gaugeValueColor)
      valueGradient.addColorStop(1, gaugeValueColor)
      
      ctx.fillStyle = valueGradient
      ctx.fillText(valueText, cx, cy + 20)
    }

    // 绘制名称 - 美化名称显示，根据组件尺寸调整字体大小
    if (data && data.length > 0 && data[0].name) {
      // 根据组件尺寸动态调整名称字体大小
      const dynamicNameFontSize = Math.max(12, Math.min(30, (width + height) / 25))
      
      // 名称阴影
      ctx.font = `bold ${chartFontSize || dynamicNameFontSize}px Arial`
      ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText(data[0].name, cx + 1, cy + 2)
      
      // 名称主体 - 使用自定义配色渐变
      const nameGradient = ctx.createLinearGradient(cx - 30, cy + 1, cx + 30, cy + 1)
      nameGradient.addColorStop(0, gaugeNameColor)
      nameGradient.addColorStop(0.5, gaugeNameColor)
      nameGradient.addColorStop(1, gaugeNameColor)
      
      ctx.fillStyle = nameGradient
      ctx.fillText(data[0].name, cx, cy + 1)
    }
  }

  const animate = () => {
    const diff = targetValueRef.current - currentValueRef.current
    if (Math.abs(diff) < 0.1) {
      currentValueRef.current = targetValueRef.current
      return
    }

    currentValueRef.current += diff * 0.1
    const ctx = canvasRef.current?.getContext('2d')
    if (ctx) {
      drawGauge(ctx, currentValueRef.current)
    }
    animationRef.current = requestAnimationFrame(animate)
  }

  const setValue = useCallback((newValue: number) => {
    const clampedValue = Math.max(min, Math.min(max, newValue))
    targetValueRef.current = clampedValue
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current)
    }
    // 直接调用动画，避免依赖循环
    const diff = targetValueRef.current - currentValueRef.current
    if (Math.abs(diff) < 0.1) {
      currentValueRef.current = targetValueRef.current
      return
    }
    currentValueRef.current += diff * 0.1
    const ctx = canvasRef.current?.getContext('2d')
    if (ctx) {
      drawGauge(ctx, currentValueRef.current)
    }
    animationRef.current = requestAnimationFrame(animate)
  }, [min, max])

  // 点击交互
  const handleClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onValueChange) return

    const canvas = canvasRef.current!
    const rect = canvas.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top
    
    const { cx, cy, r } = posInfo
    
    const dx = x - cx
    const dy = y - cy
    let angle = Math.atan2(dy, dx)
    
    if (angle < startAngle) angle += 2 * Math.PI
    if (angle > endAngle) angle -= 2 * Math.PI
    
    const newValue = linearMap(angle, [startAngle, endAngle], [min, max], true)
    
    onValueChange(newValue)
  }, [posInfo, startAngle, endAngle, min, max, onValueChange])

  useEffect(() => {
    setValue(value)
  }, [value, setValue])

  useEffect(() => {
    const canvas = canvasRef.current
    if (canvas) {
      const ctx = canvas.getContext('2d')
      if (ctx) {
        drawGauge(ctx, currentValueRef.current)
      }
    }
  }, [value, width, height, minValue, maxValue, gaugeArcColor1, gaugeArcColor2, gaugeArcColor3, gaugeNeedleColor, gaugeCenterColor, gaugeTickColor, gaugeLabelColor, gaugeValueColor, gaugeNameColor])

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [])

  const containerClasses = [
    "flex flex-col cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div 
      className={containerClasses}
      style={{
        width: `${width}px`,
        height: `${height}px`
      }}
      onMouseEnter={handleMouseEnter}
    >
      {title && showTitle && !transparent && (
        <div 
          className="font-medium mb-4 text-center"
          style={{ 
            color: titleColor,
            fontSize: `${titleFontSize || 18}px`
          }}
        >
          {title}
        </div>
      )}
      
      <div className="flex items-center justify-center flex-1">
        <div className="relative" style={{ width: `${width}px`, height: `${height}px` }}>
          <canvas
            ref={canvasRef}
            width={width}
            height={height}
            className={className}
            onClick={handleClick}
            style={{ 
              cursor: onValueChange ? 'pointer' : 'default',
              width: `${width}px`,
              height: `${height}px`
            }}
          />
          {/* 底部标签 - 参考图片的样式 */}
          {showTitle && (
            <div 
              className="absolute bottom-0 left-1/2 transform -translate-x-1/2 text-center"
              style={{ 
                color: titleColor,
                fontSize: `${titleFontSize || 16}px`,
                fontWeight: 'bold'
              }}
            >
              {data && data.length > 0 ? data[0].name : "CPU使用率"}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
