/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // 启用API路由
  distDir: 'dist',
  // 允许开发环境跨域访问
  allowedDevOrigins: ['192.168.1.16'],
  // Cesium配置
  webpack: (config) => {
    config.resolve.alias = {
      ...config.resolve.alias,
      cesium: 'cesium',
    }
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      path: false,
    }
    return config
  },
  transpilePackages: ['cesium'],
  experimental: {
    esmExternals: 'loose',
  },
}

export default nextConfig
