"use client"

import { useState, useCallback, useEffect, useRef } from "react"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { DashboardCanvas } from "@/components/dashboard-canvas"
import { DashboardView } from "@/components/dashboard-view"
import { PropertiesPanel } from "@/components/properties-panel"
import { ProjectPanel } from "@/components/project-panel"
import { DashboardToolbar } from "@/components/dashboard-toolbar"
import { ThemeProvider } from "@/components/theme-provider"
import { ErrorBoundary } from "@/components/error-boundary"
import { CameraStateProvider } from "@/components/camera-state-context"
import { ScreenRecordingSelector } from "@/components/screen-recording-selector"
import { PresentationMode } from "@/components/presentation-mode"
import { LoadingScreen, useLoadingSimulation } from "@/components/loading-screen"
import { usePersistence } from "@/hooks/use-persistence"

interface CanvasElement {
  id: string
  type: string
  x: number
  y: number
  width: number
  height: number
  title?: string
  content?: string
  headingLevel?: string
  level?: number
  zIndex?: number
  data?: any[] | { nodes: any[], links: any[] }
  tableData?: {
    headers: string[]
    rows: string[][]
  }
  textColor?: string
  backgroundColor?: string
  fontSize?: number
  fontWeight?: string
  textAlign?: string
  opacity?: number
  showLegend?: boolean
  showGrid?: boolean
  showTooltip?: boolean
  animation?: boolean
  themeId?: string
  imageUrl?: string
  alt?: string
  videoUrl?: string
  autoplay?: boolean
  controls?: boolean
  muted?: boolean
  audioUrl?: string
  transparent?: boolean
  isPreviewing?: boolean
  positionLocked?: boolean
  visible?: boolean
}

export default function Dashboard() {
  // 数据持久化
  const { saveData, loadData, isLoaded } = usePersistence()
  
  // 防抖定时器
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  
  const [selectedChart, setSelectedChart] = useState<string | null>(null)
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>([])
  const [selectedElement, setSelectedElement] = useState<string | null>(null)
  const [activeTheme, setActiveTheme] = useState("DA001")
  const [isDarkMode, setIsDarkMode] = useState(true)
  
  // 加载状态管理
  const { isLoading, progress } = useLoadingSimulation(3000) // 3秒加载时间
  const [canvasSettings, setCanvasSettings] = useState({
    width: 1920,
    height: 1080,
    backgroundColor: "#333333"
  })
  
  // 播放控制状态
  const [isPlaying, setIsPlaying] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null)
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([])
  
  // 录屏选择器状态
  const [showRecordingSelector, setShowRecordingSelector] = useState(false)
  
  // 演示模式状态
  const [isPresentationMode, setIsPresentationMode] = useState(false)
  
  // 全屏状态
  const [isFullscreen, setIsFullscreen] = useState(false)
  
  // 画布组件引用
  const canvasRef = useRef<any>(null)

  // 从本地存储加载所有数据
  useEffect(() => {
    const loadAllData = () => {
      try {
        const savedData = loadData()
        
        // 加载画布元素
        if (savedData.canvasElements) {
          setCanvasElements(savedData.canvasElements)
        }
        
        // 加载选中的元素
        if (savedData.selectedElement) {
          setSelectedElement(savedData.selectedElement)
        }
        
        // 加载主题
        if (savedData.activeTheme) {
          setActiveTheme(savedData.activeTheme)
        }
        
        // 加载暗色模式
        if (typeof savedData.isDarkMode === 'boolean') {
          setIsDarkMode(savedData.isDarkMode)
        }
        
        // 加载画布设置
        if (savedData.canvasSettings) {
          setCanvasSettings(savedData.canvasSettings)
        } else {
          // 如果没有保存的画布设置，加载背景颜色
          const storedColor = localStorage.getItem('dashboard-canvas-background-color')
          const backgroundColor = storedColor || "#333333"
          setCanvasSettings({
            width: 1920,
            height: 1080,
            backgroundColor
          })
        }
      } catch (error) {
        console.warn('Failed to load data from localStorage:', error)
      }
    }

    loadAllData()
  }, []) // 移除 loadData 依赖，避免无限循环

  // 初始化暗色模式
  useEffect(() => {
    // 确保页面加载时应用暗色模式
    if (!document.documentElement.classList.contains('dark')) {
      document.documentElement.classList.add('dark')
    }
  }, [])

  // 清理定时器
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current)
      }
    }
  }, [])

  // 明暗主题切换函数
  const toggleDarkMode = useCallback(() => {
    const newMode = !isDarkMode
    setIsDarkMode(newMode)
    
    // 切换 HTML 的 class
    if (newMode) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
    
    // 保存暗色模式状态
    saveData({ isDarkMode: newMode })
  }, [isDarkMode, saveData])

  const handleElementUpdate = useCallback((elementId: string, updates: Partial<CanvasElement>) => {
    setCanvasElements((prev) => {
      const newElements = prev.map((el) => (el.id === elementId ? { ...el, ...updates } : el))
      // 使用防抖保存，避免频繁保存
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current)
      }
      saveTimeoutRef.current = setTimeout(() => {
        saveData({ canvasElements: newElements })
      }, 300)
      return newElements
    })
  }, [saveData])

  // 稳定的元素变化处理函数，避免无限循环
  const handleElementsChange = useCallback((newElements: CanvasElement[]) => {
    setCanvasElements(newElements)
    // 使用防抖保存，避免频繁保存
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current)
    }
    saveTimeoutRef.current = setTimeout(() => {
      saveData({ canvasElements: newElements })
    }, 300)
  }, [saveData])

  const handleCanvasSettingsChange = useCallback((settings: {
    width: number
    height: number
    backgroundColor: string
  }) => {
    // 只有当设置真正改变时才更新，避免循环
    setCanvasSettings(prev => {
      if (prev.backgroundColor !== settings.backgroundColor || 
          prev.width !== settings.width || 
          prev.height !== settings.height) {
        // 保存背景颜色到本地存储
        try {
          localStorage.setItem('dashboard-canvas-background-color', settings.backgroundColor)
        } catch (error) {
          console.warn('Failed to save canvas settings to localStorage:', error)
        }
        // 保存画布设置
        saveData({ canvasSettings: settings })
        return settings
      }
      return prev
    })
  }, [saveData])

  const selectedElementData = canvasElements.find((el) => el.id === selectedElement)


  const handleSave = useCallback((fileName?: string) => {
    try {
      const dashboardData = {
        version: "1.0",
        timestamp: new Date().toISOString(),
        activeTheme,
        canvasSettings,
        elements: canvasElements,
      }

      const dataStr = JSON.stringify(dashboardData, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })

      const link = document.createElement("a")
      link.href = URL.createObjectURL(dataBlob)
      
      // 使用用户提供的文件名，如果没有则使用默认文件名
      const defaultFileName = `dashboard-${new Date().toISOString().split("T")[0]}.json`
      const finalFileName = fileName ? `${fileName}.json` : defaultFileName
      link.download = finalFileName
      
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      // 清理URL对象
      URL.revokeObjectURL(link.href)

      console.log("[JF] Dashboard saved successfully:", finalFileName)
      return true
    } catch (error) {
      console.error("[JF] Error saving dashboard:", error)
      return false
    }
  }, [activeTheme, canvasSettings, canvasElements])

  const handleLoad = useCallback((file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string
        const dashboardData = JSON.parse(content)

        if (dashboardData.elements && Array.isArray(dashboardData.elements)) {
          setCanvasElements(dashboardData.elements)
          if (dashboardData.activeTheme) {
            setActiveTheme(dashboardData.activeTheme)
          }
          if (dashboardData.canvasSettings) {
            setCanvasSettings(dashboardData.canvasSettings)
          }
          setSelectedElement(null)
          setSelectedChart(null)
          console.log("[JF] Dashboard loaded successfully:", dashboardData.elements.length, "elements")
        } else {
          console.error("[JF] Invalid dashboard file format")
          alert("无效的仪表板文件格式")
        }
      } catch (error) {
        console.error("[JF] Error loading dashboard:", error)
        alert("加载仪表板文件时出错")
      }
    }
    reader.readAsText(file)
  }, [])

  const handleClear = useCallback(() => {
    setCanvasElements([])
    setSelectedElement(null)
    setSelectedChart(null)
    // 保存清空后的状态
    saveData({ canvasElements: [], selectedElement: null })
    console.log("[JF] Canvas cleared successfully")
  }, [saveData])

  // 处理组件定位
  const handleElementFocus = useCallback((elementId: string) => {
    // 这里可以添加定位逻辑，比如滚动到组件位置或高亮显示
    console.log("[JF] Focusing on element:", elementId)
    // 可以在这里添加画布滚动或高亮逻辑
  }, [])

  // 处理组件删除
  const handleElementDelete = useCallback((elementId: string) => {
    setCanvasElements(prev => prev.filter(el => el.id !== elementId))
    if (selectedElement === elementId) {
      setSelectedElement(null)
    }
    console.log("[JF] Element deleted:", elementId)
  }, [selectedElement])

  // 处理组件复制
  const handleElementDuplicate = useCallback((elementId: string) => {
    const elementToDuplicate = canvasElements.find(el => el.id === elementId)
    if (elementToDuplicate) {
      const newElement = {
        ...elementToDuplicate,
        id: Date.now().toString(36) + Math.random().toString(36).substr(2),
        x: elementToDuplicate.x + 20,
        y: elementToDuplicate.y + 20,
        title: elementToDuplicate.title ? `${elementToDuplicate.title} (副本)` : undefined
      }
      setCanvasElements(prev => [...prev, newElement])
      console.log("[JF] Element duplicated:", elementId)
    }
  }, [canvasElements])

  // 处理组件锁定/解锁
  const handleElementToggleLock = useCallback((elementId: string) => {
    setCanvasElements(prev => prev.map(el => 
      el.id === elementId 
        ? { ...el, positionLocked: !el.positionLocked }
        : el
    ))
    console.log("[JF] Element lock toggled:", elementId)
  }, [])

  // 处理组件显示/隐藏切换
  const handleElementToggleVisible = useCallback((elementId: string) => {
    setCanvasElements(prev => prev.map(el => 
      el.id === elementId 
        ? { ...el, visible: el.visible === false ? true : false }
        : el
    ))
    console.log("[JF] Element visibility toggled:", elementId)
  }, [])

  // 处理组件重新排序（层级调整）
  const handleElementReorder = useCallback((elementId: string, newIndex: number) => {
    setCanvasElements(prev => {
      const elementIndex = prev.findIndex(el => el.id === elementId)
      if (elementIndex === -1 || elementIndex === newIndex) return prev
      
      const newElements = [...prev]
      const [movedElement] = newElements.splice(elementIndex, 1)
      newElements.splice(newIndex, 0, movedElement)
      
      // 更新zIndex以确保正确的显示层级
      return newElements.map((el, index) => ({
        ...el,
        zIndex: index + 1 // 确保zIndex从1开始递增
      }))
    })
    console.log("[JF] Element reordered:", elementId, "to index", newIndex)
  }, [])

  // 处理点击创建组件
  const handleCreateChart = useCallback((chartType: string) => {
    // 计算画布中央位置
    const centerX = canvasSettings.width / 2
    const centerY = canvasSettings.height / 2
    
    // 调用画布的创建组件方法
    if (canvasRef.current) {
      canvasRef.current.createChartAtPosition(chartType, centerX, centerY)
    }
    console.log("[JF] Creating chart at center:", chartType, centerX, centerY)
  }, [canvasSettings.width, canvasSettings.height])

  // 处理全屏切换
  const handleToggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      // 进入全屏
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true)
      }).catch((err) => {
        console.error('无法进入全屏模式:', err)
      })
    } else {
      // 退出全屏
      document.exitFullscreen().then(() => {
        setIsFullscreen(false)
      }).catch((err) => {
        console.error('无法退出全屏模式:', err)
      })
    }
  }, [])

  // 监听全屏状态变化
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange)
    }
  }, [])

  // 播放控制函数
  const handlePlay = useCallback(() => {
    setIsPlaying(true)
    // 通知所有3D组件开始播放动画
    setCanvasElements(prev => prev.map(el => {
      if (el.type === '3d-model') {
        return {
          ...el,
          data: {
            ...el.data,
            viewAnimationEnabled: true,
            triggerExplode: true
          }
        }
      }
      return el
    }))
  }, [])

  const handlePause = useCallback(() => {
    setIsPlaying(false)
    
    // 暂停所有视频和音频元素
    const videos = document.querySelectorAll('video')
    const audios = document.querySelectorAll('audio')
    
    videos.forEach(video => {
      if (!video.paused) {
        video.pause()
      }
    })
    
    audios.forEach(audio => {
      if (!audio.paused) {
        audio.pause()
      }
    })
    
    // 通知所有3D组件暂停动画
    setCanvasElements(prev => prev.map(el => {
      if (el.type === '3d-model') {
        return {
          ...el,
          data: {
            ...el.data,
            viewAnimationEnabled: false
          }
        }
      }
      return el
    }))
  }, [])

  const handleStop = useCallback(() => {
    setIsPlaying(false)
    
    // 停止所有视频和音频元素
    const videos = document.querySelectorAll('video')
    const audios = document.querySelectorAll('audio')
    
    videos.forEach(video => {
      if (!video.paused) {
        video.pause()
        video.currentTime = 0 // 重置到开始位置
      }
    })
    
    audios.forEach(audio => {
      if (!audio.paused) {
        audio.pause()
        audio.currentTime = 0 // 重置到开始位置
      }
    })
    
    // 通知所有3D组件停止动画并恢复原始状态
    setCanvasElements(prev => prev.map(el => {
      if (el.type === '3d-model') {
        return {
          ...el,
          data: {
            ...el.data,
            viewAnimationEnabled: false,
            restoreModel: true
          }
        }
      }
      return el
    }))
  }, [])

  // 录屏控制函数
  const handleStartRecording = useCallback(() => {
    // 如果已经在录屏，则停止录屏
    if (isRecording) {
      setIsRecording(false)
      return
    }
    // 设置录屏状态，触发画布录屏组件
    setIsRecording(true)
  }, [isRecording])

  // 开始录制指定区域
  const startRecordingWithArea = useCallback(async (area?: { x: number, y: number, width: number, height: number }) => {
    try {
      // 检查浏览器是否支持getDisplayMedia
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        alert('您的浏览器不支持屏幕录制功能，请使用Chrome、Firefox或Edge浏览器')
        return
      }

      // 请求屏幕共享权限
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          mediaSource: 'screen',
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          frameRate: { ideal: 30 }
        },
        audio: false // 暂时不录制音频
      })

      // 创建MediaRecorder - 尝试使用MP4格式
      let mimeType = 'video/mp4;codecs=h264'
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm;codecs=vp9'
      }
      
      const recorder = new MediaRecorder(stream, {
        mimeType: mimeType
      })

      const chunks: Blob[] = []
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data)
        }
      }

      recorder.onstop = () => {
        // 根据MIME类型确定文件扩展名
        const fileExtension = mimeType.includes('mp4') ? 'mp4' : 'webm'
        const blob = new Blob(chunks, { type: mimeType })
        const url = URL.createObjectURL(blob)
        
        // 创建下载链接
        const a = document.createElement('a')
        a.href = url
        a.download = `录屏_${new Date().toISOString().replace(/[:.]/g, '-')}.${fileExtension}`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
        
        // 停止所有轨道
        stream.getTracks().forEach(track => track.stop())
      }

      // 监听用户停止共享
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        if (recorder.state === 'recording') {
          recorder.stop()
          setIsRecording(false)
          setMediaRecorder(null)
          setRecordedChunks([])
        }
      })

      // 开始录制
      recorder.start()
      setMediaRecorder(recorder)
      setRecordedChunks(chunks)
      setIsRecording(true)

    } catch (error) {
      console.error('开始录屏失败:', error)
      if (error.name === 'NotAllowedError') {
        alert('录屏权限被拒绝，请允许屏幕共享')
      } else {
        alert('录屏启动失败: ' + error.message)
      }
    }
  }, [])

  // 处理选择录屏区域
  const handleSelectRecordingArea = useCallback((area: { x: number, y: number, width: number, height: number }) => {
    setShowRecordingSelector(false)
    startRecordingWithArea(area)
  }, [startRecordingWithArea])

  // 处理选择整个屏幕
  const handleSelectFullScreen = useCallback(() => {
    setShowRecordingSelector(false)
    startRecordingWithArea()
  }, [startRecordingWithArea])

  const handleStopRecording = useCallback(() => {
    // 重置录屏状态
    setIsRecording(false)
    
    // 清理旧的录屏相关状态（如果存在）
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop()
      setMediaRecorder(null)
      setRecordedChunks([])
    }
  }, [mediaRecorder, isRecording])

  // 发布功能处理函数
  const handlePublish = useCallback(() => {
    setIsPresentationMode(true)
  }, [])

  // 关闭演示模式
  const handleClosePresentation = useCallback(() => {
    setIsPresentationMode(false)
  }, [])

  return (
    <ErrorBoundary>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <CameraStateProvider>
          <LoadingScreen isLoading={isLoading} progress={progress}>
            <div className="h-screen bg-background text-foreground flex flex-col">
        {/* Top Toolbar */}
        <DashboardToolbar
          activeTheme={activeTheme}
          onThemeChange={setActiveTheme}
          onSave={handleSave}
          onLoad={handleLoad}
          onClear={handleClear}
          isDarkMode={isDarkMode}
          onDarkModeToggle={toggleDarkMode}
          onPlay={handlePlay}
          onPause={handlePause}
          onStop={handleStop}
          onStartRecording={handleStartRecording}
          onStopRecording={handleStopRecording}
          isPlaying={isPlaying}
          isRecording={isRecording}
          onPublish={handlePublish}
          isFullscreen={isFullscreen}
          onToggleFullscreen={handleToggleFullscreen}
        />

        {/* Main Layout */}
        <div className="flex-1 flex overflow-hidden">
            {/* Project Panel */}
            <ProjectPanel
              elements={canvasElements}
              selectedElement={selectedElement}
              onElementSelect={(elementId) => {
                setSelectedElement(elementId)
                saveData({ selectedElement: elementId })
              }}
              onElementFocus={handleElementFocus}
              onElementDelete={handleElementDelete}
              onElementDuplicate={handleElementDuplicate}
              onElementToggleLock={handleElementToggleLock}
              onElementToggleVisible={handleElementToggleVisible}
              onElementReorder={handleElementReorder}
            />

            {/* Left Sidebar */}
            <DashboardSidebar 
              onChartSelect={setSelectedChart} 
              selectedChart={selectedChart}
              onCreateChart={handleCreateChart}
            />

            {/* Main Canvas */}
            <div className="flex-1 flex">
              <DashboardCanvas
                ref={canvasRef}
                elements={canvasElements}
                onElementsChange={handleElementsChange}
                selectedChart={selectedChart}
                selectedElement={selectedElement}
                onElementSelect={(elementId) => {
                  setSelectedElement(elementId)
                  saveData({ selectedElement: elementId })
                }}
                onElementUpdate={handleElementUpdate}
                onCanvasSettingsChange={handleCanvasSettingsChange}
                initialCanvasSettings={canvasSettings}
                onStartRecording={handleStartRecording}
                onStopRecording={handleStopRecording}
                isRecording={isRecording}
              />

              {/* Right Properties Panel */}
              <PropertiesPanel
                selectedElement={selectedElementData || null}
                activeTheme={activeTheme}
                onThemeChange={(theme) => {
                  setActiveTheme(theme)
                  saveData({ activeTheme: theme })
                }}
                onElementUpdate={handleElementUpdate}
                isDarkMode={isDarkMode}
              />
            </div>
          </div>
            </div>
          </LoadingScreen>
        </CameraStateProvider>
        
        {/* 录屏选择器 */}
        <ScreenRecordingSelector
          isOpen={showRecordingSelector}
          onClose={() => setShowRecordingSelector(false)}
          onSelectArea={handleSelectRecordingArea}
          onSelectFullScreen={handleSelectFullScreen}
        />

        {/* 演示模式 */}
        {isPresentationMode && (
          <CameraStateProvider>
            <PresentationMode
              canvasElements={canvasElements}
              canvasSettings={canvasSettings}
              onClose={handleClosePresentation}
            />
          </CameraStateProvider>
        )}
      </ThemeProvider>
    </ErrorBoundary>
  )
}
