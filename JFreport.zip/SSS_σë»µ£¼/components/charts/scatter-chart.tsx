"use client"

import { ScatterChart as RechartsScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { DEFAULT_CHART_COLORS } from "@/lib/chart-colors"
import { useCallback } from "react"
import { useSound } from "@/hooks/use-sound"

interface ScatterChartProps {
  data?: Array<{ x: number; y: number; z?: number }>
  width?: number
  height?: number
  colors?: string[]
  title?: string
  themeId?: string
  transparent?: boolean
  textColors?: {
    axis?: string
    legend?: string
    tooltip?: string
    title?: string
    label?: string
  }
  // 字体设置
  titleFontSize?: number
  titleTextColor?: string
  axisFontSize?: number
  axisTextColor?: string
  legendFontSize?: number
  legendTextColor?: string
  tooltipFontSize?: number
  tooltipTextColor?: string
  chartFontSize?: number
  chartTextColor?: string
}

const defaultData = [
  { x: 10, y: 30, z: 200 },
  { x: 20, y: 50, z: 400 },
  { x: 30, y: 40, z: 300 },
  { x: 40, y: 60, z: 500 },
  { x: 50, y: 45, z: 350 },
]

export function ScatterChart({
  data = defaultData,
  width = 400,
  height = 300,
  colors,
  title = "散点图",
  themeId = "DA001",
  transparent = false,
  textColors,
  titleFontSize,
  titleTextColor,
  axisFontSize,
  axisTextColor,
  legendFontSize,
  legendTextColor,
  tooltipFontSize,
  tooltipTextColor,
  chartFontSize,
  chartTextColor
}: ScatterChartProps) {
  const { playHover } = useSound()
  const chartColors = colors || DEFAULT_CHART_COLORS

  const containerClasses = [
    "w-full h-full cursor-move",
    !transparent && "bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-6"
  ].filter(Boolean).join(" ")

  // 鼠标进入事件处理
  const handleMouseEnter = useCallback(() => {
    playHover()
  }, [playHover])

  return (
    <div className={containerClasses} onMouseEnter={handleMouseEnter}>
      {title && !transparent && (
        <div className="mb-2">
          <h3 
            className="font-semibold tracking-tight drop-shadow-sm"
            style={{ 
              fontSize: `${titleFontSize || 14}px`,
              color: titleTextColor || textColors?.title || "#ffffff"
            }}
          >
            {title}
          </h3>
        </div>
      )}
      <div className="h-full w-full">
        <ResponsiveContainer width="100%" height={transparent ? "100%" : "100%"}>
          <RechartsScatterChart>
            {!transparent && <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" strokeOpacity={0.15} />}
            <XAxis
              type="number"
              dataKey="x"
              name="X轴"
              stroke={axisTextColor || textColors?.axis || (transparent ? "#ffffff" : chartColors[0])}
              fontSize={axisFontSize || 12}
              fontWeight={500}
              tickLine={false}
              axisLine={false}
              dy={5}
            />
            <YAxis
              type="number"
              dataKey="y"
              name="Y轴"
              stroke={axisTextColor || textColors?.axis || (transparent ? "#ffffff" : chartColors[0])}
              fontSize={axisFontSize || 12}
              fontWeight={500}
              tickLine={false}
              axisLine={false}
              dx={-5}
            />
            <Tooltip
              cursor={{ strokeDasharray: "3 3" }}
              contentStyle={{
                backgroundColor: "rgba(15, 23, 42, 0.8)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: "12px",
                boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.05)",
                backdropFilter: "blur(16px)",
                fontSize: `${tooltipFontSize || 12}px`,
                fontWeight: "500",
                color: tooltipTextColor || textColors?.tooltip || "#ffffff",
              }}
            />
            <Legend
              wrapperStyle={{
                fontSize: `${legendFontSize || 12}px`,
                fontWeight: "500",
                color: legendTextColor || textColors?.legend || (transparent ? "#ffffff" : chartColors[0]),
              }}
            />
            <Scatter
              name="数据点"
              data={data}
              fill={chartColors[0]}
              animationDuration={800}
              animationEasing="ease-out"
            />
          </RechartsScatterChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}