"use client"

// 简易热力图占位：用表格渲染色块
import React from "react"
import { getThemeById, applyThemeToChart } from "@/lib/color-themes"

interface HeatmapChartProps {
	data?: number[][]
	width?: number
	height?: number
	colors?: string[]
	title?: string
	themeId?: string
	transparent?: boolean
}

const defaultData = [
	[10, 20, 30, 40],
	[20, 10, 50, 60],
	[30, 40, 20, 10],
]

export function HeatmapChart({ data = defaultData, width = 400, height = 300, colors, title = "热力图", themeId = "DA001", transparent = false }: HeatmapChartProps) {
	const theme = getThemeById(themeId)
	const palette = colors || (theme ? applyThemeToChart(theme, "area") : ["#3B82F6", "#60A5FA", "#93C5FD", "#BFDBFE"]) // 用面积图色系

	const max = Math.max(...data.flat()) || 1

	const containerClasses = transparent ? "w-full h-full" : "w-full h-full bg-slate-900/20 backdrop-blur-md rounded-xl border border-white/10 p-4"

	return (
		<div className={containerClasses}>
			{title && !transparent && <h3 className="text-sm font-semibold text-white mb-2">{title}</h3>}
			<div className="grid" style={{ gridTemplateColumns: `repeat(${data[0]?.length || 0}, 1fr)`, gap: 4 }}>
				{data.map((row, r) =>
					row.map((v, c) => {
						const idx = Math.min(palette.length - 1, Math.floor((v / max) * (palette.length - 1)))
						return <div key={`${r}-${c}`} style={{ background: palette[idx], height: Math.max(12, (height - 40) / data.length) }} className="rounded" />
					})
				)}
			</div>
		</div>
	)
}


